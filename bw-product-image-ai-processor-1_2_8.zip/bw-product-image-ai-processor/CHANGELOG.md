# Changelog

## 1.2.8

Fixes a real bug reported from live testing: the 1.2.7 size=auto fallback
could produce a "doll-sized" subject - tiny, centered in a mostly-empty
1200x1600 canvas - instead of a usable product photo.

### Fixed
- **Remove.bg auto-fallback could return a too-small image.** `size=auto`
  (used only after a confirmed size=full credit shortfall) can fall back
  as low as Remove.bg's free preview tier, around 625x400px. Contain-mode
  compositing deliberately never upscales a source past its own
  resolution (to avoid a blurry result), so a preview-sized cutout ended
  up sitting at its tiny native size in the middle of the full canvas
  instead of filling it. Above this ran fine - the underlying image
  handling is correct - it's just this specific single downgrade case
  where the resulting AI image is too small to make a usable product
  photo. Now, when the auto-fallback result comes back under 600px in
  either dimension, it's discarded and processing falls back to Local
  Mode instead (the original photo, at full resolution, on the plain
  studio background) - never both the credit shortfall and a tiny result
  in one. The attachment log says explicitly when this happens.
  (`includes/class-bw-pip-processor.php`)

## 1.2.7

### Added
- **Remove.bg: automatic size=auto retry, only on a confirmed size=full
  credit shortfall.** `size=full` is still always tried first (best
  quality when the account can afford it). Remove.bg's monthly free
  allowance (50/month) only ever covers "preview" size - "full" always
  spends a paid credit - so an account with none left gets HTTP 402 back
  specifically for that reason. Only on that exact, unambiguous signal
  (never on a bad key, network error, or corrupt image) the same image is
  retried once with `size=auto`, which uses the best resolution Remove.bg
  can actually deliver right now, including that free monthly allowance,
  instead of failing outright. When this happens the attachment's log
  says so explicitly, so it's never silently lower quality.
  (`includes/providers/class-bw-pip-provider-removebg.php`,
  `includes/class-bw-pip-processor.php`)

## 1.2.6

Fixes a real bug reported from live testing: a genuinely successful
Remove.bg call (log said "Background removed... composited on local
studio canvas") produced an output that still showed the original,
unremoved background.

### Fixed
- **Transparent AI cutout not actually compositing.** Before copying the
  AI result onto the studio canvas, the source image had
  `imagealphablending(true)` set on it. Checked against GD's own
  documented compositing pattern (imagealphablending(false) +
  imagesavealpha(true) on the source before imagecopyresampled;
  imagealphablending(true) on the destination, which was already correct)
  - this was backwards for a source with a transparent channel. Without
  the source's alpha correctly preserved through the resample, GD can
  treat "removed" pixels as opaque, pasting the original image over the
  canvas essentially unchanged - exactly the symptom reported. Remove.bg
  is the provider this affects (it returns a transparent cutout);
  Clipdrop/Photoroom (already-opaque results) and Local Mode were not
  visibly broken by this, since an opaque source has no transparency for
  the wrong flag to mishandle - the fix is applied for all of them
  uniformly since it is harmless either way.
  (`includes/class-bw-pip-canvas.php`)

## 1.2.5

Fixes a real bug reported from live usage: gallery images consistently
logged "Skipped: Not detected as WooCommerce product image." and neither
automatic nor manual processing would touch them, while the featured
image worked normally.

### Fixed
- **Gallery images not recognized as product images.** `is_product_image()`
  relied on either a meta flag set when the product was last saved
  (`mark_product_images()`, via `save_post_product`) or the attachment's
  `post_parent` (only set for a fresh upload made directly inside that
  product's editor screen). Neither reliably covers a gallery image
  attached to a product without the product being re-saved since, or one
  reused from the Media Library rather than freshly uploaded into the
  gallery field - both common ways of building a product gallery. Before
  giving up, `is_product_image()` now also checks WooCommerce's own
  current `_thumbnail_id` / `_product_image_gallery` postmeta directly -
  the actual source of truth - and marks the image if found there. This
  fixes existing "skipped" gallery images immediately on the next
  Process Now click, not just newly added ones.
  (`includes/class-bw-pip-processor.php`)
- Product image marking now also runs on WooCommerce's
  `woocommerce_process_product_meta` action (priority 30, after
  `WC_Meta_Box_Product_Images::save`'s priority 20 on that same action),
  in addition to the existing `save_post_product` hook - a more reliable
  "the gallery has definitely been saved" signal for the classic
  product-edit screen specifically. `save_post_product` is kept as-is
  alongside it for save paths this action does not cover (REST API, the
  block-based Product Editor, programmatic updates).
  (`includes/class-bw-pip-processor.php`)

## 1.2.4

Restores manual control over backups (removed in 1.2.3) in a way that
keeps it an informed choice, and adds the tools to act on that control -
requested after 1.2.3 made backups mandatory with no way to manage them.

### Added
- **"Enable Original Image Backup" toggle is back** (default ON). 1.2.3
  made backup creation unconditional with no way to turn it off; some
  images already have their own backup kept elsewhere, so forcing a
  second copy for every image was not actually what was wanted. Turning
  it off is now a fully informed choice: the setting has an always-visible
  warning explaining exactly what it means (no recovery through the
  plugin, re-processing starts from the already-processed file), instead
  of the silent 1.2.2 behavior this is not a return to.
  (`includes/class-bw-pip-settings.php`, `includes/class-bw-pip-processor.php`,
  `admin/views/settings-page.php`)
- **"Download All Backups (ZIP)"** - builds and downloads a ZIP of every
  current backup on demand. Files are given human-readable names inside
  the ZIP (product title + original extension, e.g.
  `482-blue-embroidered-abaya.jpg`) instead of the opaque
  `482_9f2a...bin` they're stored as, so the download is actually usable
  outside the plugin. Requires the PHP `ZipArchive` extension; if it is
  not available, the button explains this and points to the backup
  folder's path (shown just above it) for an FTP/File Manager download
  instead. (`includes/class-bw-pip-backup.php`, `admin/class-bw-pip-admin.php`,
  `admin/views/settings-page.php`)
- **"Delete All Backups Now"** - immediately deletes every backup file and
  clears the related tracking data on every attachment, without touching
  already-processed images or requiring the plugin to be uninstalled.
  Confirms before running. (`includes/class-bw-pip-backup.php`,
  `admin/class-bw-pip-admin.php`, `admin/assets/js/admin.js`)
- Settings page now shows a live count and total size of the current
  backup folder, so it's clear whether downloading/clearing is worth
  doing before either action is taken. (`includes/class-bw-pip-backup.php`,
  `admin/views/settings-page.php`)

### Investigated, not changed
- **Automatic fallback when the AI provider call fails or a free-tier
  quota is hit:** already existed and works correctly - confirmed by
  tracing `class-bw-pip-processor.php`, not assumed. If the AI call fails
  for any reason (quota, network, bad response), `$source_res` is never
  set from it, and the very next block falls back to decoding the local
  working copy and composing it on the plain studio-canvas background
  (Local Mode) - the log for that image records
  "AI fallback to local studio canvas. [reason]" either way. On top of
  that automatic per-image fallback, "Enable AI Background" in Settings
  can be turned off any time (e.g. once a quota is known to be used up)
  to skip attempting the API entirely and process everything in Local
  Mode until it's turned back on - no code change was needed for either
  path.

## 1.2.3

Fixes from a second audit pass, focused on the data-safety items
intentionally left open in 1.2.2 ("Known limitations" below) plus the
still-dead `target_min_kb` setting.

### Fixed
- **"Secure Original Image Backup" could be turned off, which silently
  deleted the original with no backup anywhere:** backup creation is no
  longer optional. `BW_PIP_Backup::create_backup()` now always runs before
  an original file is ever deleted, and deletion itself now always requires
  `BW_PIP_Backup::has_valid_backup()` to be true first. This also means
  re-processing an image (e.g. turning AI on after an earlier local-only
  run) always starts from the true original instead of an already-processed
  file. (`includes/class-bw-pip-processor.php`)
- **`uninstall.php` deleted the entire backup directory unconditionally:**
  it now only does so if the new "Also Delete Backups When This Plugin Is
  Uninstalled" setting is explicitly turned on (default off). Deleting the
  plugin from Plugins → Installed Plugins now preserves your original-image
  backups unless you deliberately opt in. (`uninstall.php`,
  `includes/class-bw-pip-settings.php`, `admin/views/settings-page.php`)
- **WebP encoder failed the whole image if even the lowest tried quality
  (15) exceeded Target Max KB:** it now falls back to the smallest file
  WebP could actually produce and logs a note on the attachment that it
  exceeded the configured ceiling, instead of leaving the product with no
  processed image at all. This is a genuine edge case (typically very
  high-detail source photos — busy patterns, sequins, embroidery) rather
  than the common path. (`includes/class-bw-pip-canvas.php`,
  `includes/class-bw-pip-processor.php`)
- **Media Library list-column "Process Now" button didn't update its
  status badge:** it only updated status text in the single-attachment
  edit panel. Both locations now show "Queued" immediately after a
  successful click. (`admin/assets/js/admin.js`)

### Removed
- **`keep_backup` setting.** Backups are no longer optional (see "Fixed"
  above), so the checkbox no longer represented a real choice. Its Card 1
  UI slot now shows a plain statement that backups are always on, plus the
  new opt-in "delete on uninstall" control.
  (`includes/class-bw-pip-settings.php`, `admin/views/settings-page.php`)
- **`target_min_kb` setting.** Same category as the fields removed in
  1.2.2: the quality-search loop in `class-bw-pip-canvas.php` always picks
  the first (highest-quality) result at or under `target_max_kb`, since
  qualities are probed high to low — by construction that is already the
  best available answer, so no "minimum" could ever change the outcome.
  Verified by tracing the loop, not assumed: both branches of the old
  `if ( $size >= $target_min )` check reached the exact same `break`.
  (`includes/class-bw-pip-canvas.php`, `includes/class-bw-pip-settings.php`,
  `admin/views/settings-page.php`)

### Added
- **"Also Delete Backups When This Plugin Is Uninstalled"** setting
  (default off), with an explicit on-page warning that this is permanent.
  (`admin/views/settings-page.php`)
- Attachment log now notes when an output file exceeded `target_max_kb` via
  the last-resort fallback above, so it's visible per-image rather than
  only in aggregate. (`includes/class-bw-pip-processor.php`)

### Known limitations not changed in this pass
- No automated test suite (same reasoning as 1.2.2 — requires a real
  WordPress/MySQL/GD environment to verify against).
- `uninstall.php`'s path-safety logic is still separate from
  `includes/class-bw-pip-backup.php`'s (same reasoning as 1.2.2 — low
  regression risk was prioritized over consolidation on a live site).
- Disk usage: backups are now always created, so the backup directory will
  grow with every processed product image and is not automatically pruned.
  There is no retention/cleanup feature yet — a reasonable follow-up if
  disk space becomes a real concern.

## 1.2.2

Fixes from a technical-debt audit. No file/folder structure changes, no
hooks renamed, no settings removed that were ever user-facing.

### Fixed
- **Composition seam:** when Photoroom or Clipdrop successfully returns an
  image (both generate their own full background), it is now scaled with
  **cover-fit** to fill the 1200×1600 canvas edge to edge, instead of being
  padded onto a second, separately generated local background. Remove.bg
  (background removal only) and Local Mode are unaffected — they still use
  the original contain-fit/padding behavior, which is correct for a
  transparent cutout or an unmodified photo.
  (`includes/class-bw-pip-canvas.php`, `includes/class-bw-pip-processor.php`)
- **Manual "Process Now" timeout risk:** now routed through the same
  background queue used for automatic processing, instead of calling an AI
  provider synchronously inside the AJAX request (which could exceed PHP's
  execution-time limit on some hosts). The button now reports "Queued" and
  the admin refreshes to see the result, matching how automatic processing
  already worked. (`admin/class-bw-pip-admin.php`, `admin/assets/js/admin.js`)

### Added
- Admin notice when WooCommerce is not active, explaining that processing
  won't run until it is (previously failed silently with no explanation).
  (`bw-product-image-ai-processor.php`)
- Admin notice (site-wide, not just the settings page) when the backup
  directory is inside the public uploads folder and the server does not
  identify itself as Apache or LiteSpeed, where the existing `.htaccess`
  protection does not apply. (`includes/class-bw-pip-backup.php`,
  `admin/class-bw-pip-admin.php`)
- "Images Currently Queued" row on the System Diagnostics panel, so a stuck
  WP-Cron queue is visible instead of silent. (`admin/views/settings-page.php`)
- `README.md`, this `CHANGELOG.md`, and dev-only `composer.json` /
  `phpcs.xml.dist` (WordPress Coding Standards). None of these are loaded by
  the plugin at runtime.

### Removed
- `target_width`, `target_height`, `aspect_ratio`, `output_format` from the
  settings schema. These were always immediately overwritten back to their
  fixed values (1200, 1600, "3:4", "webp") on every save and were never
  actually configurable or read anywhere else in the codebase — dead,
  misleading config surface. The canvas size and output format are
  unchanged; they were always fixed in code
  (`includes/class-bw-pip-canvas.php`), never in this settings array.

### Known limitations not changed in this pass (see audit report)
- No automated test suite. Writing one requires an actual WordPress/MySQL/GD
  test environment to verify against; adding untested test code would not
  meet the "verified" bar, so this was intentionally left for a follow-up
  with real infrastructure available rather than guessed at.
- `uninstall.php`'s path-safety logic is still separate from
  `includes/class-bw-pip-backup.php`'s. Consolidating it would require
  loading class dependencies (and constants like `BW_PIP_VERSION`) into the
  minimal uninstall context, which carries more regression risk on a live
  site than the duplication itself does. Left as-is; flagged for a
  dedicated follow-up rather than a rushed change here.
- Default backup directory location was not changed (still inside
  `wp-content/uploads/` by default). Moving it automatically would require
  assumptions about host filesystem permissions/`open_basedir` that can't be
  verified generically — instead, visibility of the existing risk was
  improved (see "Added" above) so you can decide deliberately, e.g. via the
  existing `bw_pip_backup_dir` filter.
