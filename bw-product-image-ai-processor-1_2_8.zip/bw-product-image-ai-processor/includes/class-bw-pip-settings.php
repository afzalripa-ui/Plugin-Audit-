<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BW_PIP_Settings {

	const OPTION_KEY        = 'bw_pip_settings';
	const API_KEY_OPTION    = 'bw_pip_api_key';
	const BACKUP_DIR_OPTION = 'bw_pip_backup_dir';

	public static function init() {
		register_setting(
			'bw_pip_settings_group',
			self::OPTION_KEY,
			array(
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
			)
		);

		add_filter( 'option_page_capability_bw_pip_settings_group', array( __CLASS__, 'settings_capability' ) );
	}

	public static function settings_capability() {
		return class_exists( 'WooCommerce' ) ? 'manage_woocommerce' : 'manage_options';
	}

	public static function get_defaults() {
		return array(
			'enable_auto_process'         => 1,
			'process_products_only'       => 1,
			'enable_ai'                   => 0,
			'ai_provider'                 => 'photoroom',
			'api_key'                     => '',
			'target_max_kb'               => 200,
			'bg_color'                    => '#F7F6F2',
			'enable_backup'               => 1,
			'delete_backups_on_uninstall' => 0,
			'bg_prompt'                   => 'Create a realistic premium e-commerce product photography background. Bright natural daylight indoor setting, clean elegant off-white neutral wall, minimal premium styling, soft realistic natural shadows, no people, no text, no logo. Preserve the original product exactly.',
		);
	}

	public static function get_options() {
		$options = get_option( self::OPTION_KEY, array() );

		if ( ! is_array( $options ) ) {
			$options = array();
		}

		$options = wp_parse_args( $options, self::get_defaults() );

		// API key must never be exposed through the main settings array.
		$options['api_key'] = '';

		return $options;
	}

	public static function get( $key, $default = null ) {
		$options = self::get_options();

		return isset( $options[ $key ] ) ? $options[ $key ] : $default;
	}

	public static function get_api_key() {
		self::migrate_api_key();

		if ( defined( 'BW_PIP_API_KEY' ) && is_string( constant( 'BW_PIP_API_KEY' ) ) ) {
			$constant_key = trim( constant( 'BW_PIP_API_KEY' ) );

			if ( '' !== $constant_key ) {
				return $constant_key;
			}
		}

		return trim( (string) get_option( self::API_KEY_OPTION, '' ) );
	}

	public static function set_api_key( $key ) {
		$key = trim( (string) $key );

		delete_option( self::API_KEY_OPTION );

		if ( '' !== $key ) {
			add_option( self::API_KEY_OPTION, $key, '', 'no' );
		}
	}

	public static function clear_api_key() {
		delete_option( self::API_KEY_OPTION );
	}

	public static function migrate_api_key() {
		$settings = get_option( self::OPTION_KEY, array() );

		if ( ! is_array( $settings ) || ! array_key_exists( 'api_key', $settings ) ) {
			return;
		}

		$old_key = sanitize_text_field( (string) $settings['api_key'] );

		if ( '' !== $old_key && '' === (string) get_option( self::API_KEY_OPTION, '' ) ) {
			self::set_api_key( $old_key );
		}

		unset( $settings['api_key'] );
		update_option( self::OPTION_KEY, $settings );
	}

	public static function sanitize( $input ) {
		$input    = is_array( $input ) ? $input : array();
		$existing = self::get_options();
		$output   = $existing;

		$output['enable_auto_process']         = ! empty( $input['enable_auto_process'] ) ? 1 : 0;
		$output['process_products_only']       = ! empty( $input['process_products_only'] ) ? 1 : 0;
		$output['enable_backup']               = ! empty( $input['enable_backup'] ) ? 1 : 0;
		$output['delete_backups_on_uninstall'] = ! empty( $input['delete_backups_on_uninstall'] ) ? 1 : 0;

		if ( isset( $input['target_max_kb'] ) ) {
			$output['target_max_kb'] = absint( $input['target_max_kb'] );
		}

		// 20 KB is an unrealistically tight ceiling for a 1200x1600 photo;
		// treat anything below it as a mistake and fall back to the default.
		if ( $output['target_max_kb'] < 20 ) {
			$output['target_max_kb'] = 200;
		}

		if ( isset( $input['bg_color'] ) ) {
			$output['bg_color'] = sanitize_hex_color( $input['bg_color'] );
		}

		if ( empty( $output['bg_color'] ) ) {
			$output['bg_color'] = '#F7F6F2';
		}

		if ( current_user_can( 'manage_options' ) ) {
			$output['enable_ai'] = ! empty( $input['enable_ai'] ) ? 1 : 0;

			$allowed_providers     = array( 'photoroom', 'clipdrop', 'removebg' );
			$input_provider        = isset( $input['ai_provider'] ) ? $input['ai_provider'] : 'photoroom';
			$output['ai_provider'] = in_array( $input_provider, $allowed_providers, true ) ? $input_provider : 'photoroom';

			if ( isset( $input['bg_prompt'] ) ) {
				$output['bg_prompt'] = sanitize_textarea_field( $input['bg_prompt'] );
			}

			if ( isset( $input['api_key'] ) && '' !== trim( (string) $input['api_key'] ) ) {
				self::set_api_key( sanitize_text_field( $input['api_key'] ) );
			}
		}

		// Never store or return the saved API key inside the main settings array.
		$output['api_key'] = '';

		return $output;
	}
}