<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BW_PIP_Activator {

	public static function activate() {
		if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
			deactivate_plugins( plugin_basename( BW_PIP_PLUGIN_FILE ) );
			wp_die( esc_html__( 'BW Product Image AI Processor requires PHP 7.4 or higher.', 'bw-product-image-ai-processor' ) );
		}

		if ( ! extension_loaded( 'gd' ) || ! function_exists( 'imagewebp' ) ) {
			deactivate_plugins( plugin_basename( BW_PIP_PLUGIN_FILE ) );
			wp_die( esc_html__( 'BW Product Image AI Processor requires the PHP GD extension with WebP support (imagewebp) enabled on your server.', 'bw-product-image-ai-processor' ) );
		}

		if ( false === get_option( 'bw_pip_settings' ) ) {
			add_option( 'bw_pip_settings', BW_PIP_Settings::get_defaults() );
		}

		BW_PIP_Settings::migrate_api_key();
		BW_PIP_Backup::get_backup_dir();

		update_option( 'bw_pip_plugin_version', BW_PIP_VERSION );

		if ( class_exists( 'BW_PIP_Processor' ) ) {
			BW_PIP_Processor::maybe_schedule_marker_backfill();
		}
	}
}