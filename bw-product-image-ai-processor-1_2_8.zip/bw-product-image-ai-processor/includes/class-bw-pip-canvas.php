<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BW_PIP_Canvas {

	private static function validate_dimensions( $width, $height ) {
		$width  = (int) $width;
		$height = (int) $height;

		if ( $width <= 0 || $height <= 0 ) {
			return __( 'Invalid image dimensions.', 'bw-product-image-ai-processor' );
		}

		if ( $width > BW_PIP_MAX_DIMENSION || $height > BW_PIP_MAX_DIMENSION ) {
			return sprintf(
				/* translators: %d: maximum allowed dimension */
				__( 'Image dimensions exceed the safe processing limit of %d pixels.', 'bw-product-image-ai-processor' ),
				BW_PIP_MAX_DIMENSION
			);
		}

		if ( ( $width * $height ) > BW_PIP_MAX_PIXELS ) {
			return __( 'Image pixel count exceeds the safe GD processing limit.', 'bw-product-image-ai-processor' );
		}

		return '';
	}

	public static function get_file_decode_error( $path ) {
		if ( '' === $path || ! is_file( $path ) || is_link( $path ) || ! is_readable( $path ) ) {
			return __( 'Image file is missing or unreadable.', 'bw-product-image-ai-processor' );
		}

		clearstatcache( true, $path );

		$bytes = (int) @filesize( $path );

		if ( $bytes <= 0 ) {
			return __( 'Image file is empty.', 'bw-product-image-ai-processor' );
		}

		if ( $bytes > BW_PIP_MAX_FILE_BYTES ) {
			return sprintf(
				/* translators: %d: maximum allowed file size in MB */
				__( 'Image file is larger than the safe processing limit of %d MB.', 'bw-product-image-ai-processor' ),
				(int) ( BW_PIP_MAX_FILE_BYTES / 1024 / 1024 )
			);
		}

		$info = @getimagesize( $path );

		if ( ! $info || empty( $info[0] ) || empty( $info[1] ) ) {
			return __( 'File is not a readable image.', 'bw-product-image-ai-processor' );
		}

		return self::validate_dimensions( $info[0], $info[1] );
	}

	public static function get_binary_decode_error( $data ) {
		if ( ! is_string( $data ) || '' === $data ) {
			return __( 'Image data is empty.', 'bw-product-image-ai-processor' );
		}

		$bytes = strlen( $data );

		if ( $bytes <= 0 ) {
			return __( 'Image data is empty.', 'bw-product-image-ai-processor' );
		}

		if ( $bytes > BW_PIP_MAX_FILE_BYTES ) {
			return sprintf(
				/* translators: %d: maximum allowed file size in MB */
				__( 'Image data is larger than the safe processing limit of %d MB.', 'bw-product-image-ai-processor' ),
				(int) ( BW_PIP_MAX_FILE_BYTES / 1024 / 1024 )
			);
		}

		if ( ! function_exists( 'getimagesizefromstring' ) ) {
			return __( 'PHP getimagesizefromstring is unavailable.', 'bw-product-image-ai-processor' );
		}

		$info = @getimagesizefromstring( $data );

		if ( ! $info || empty( $info[0] ) || empty( $info[1] ) ) {
			return __( 'Received data is not a readable image.', 'bw-product-image-ai-processor' );
		}

		return self::validate_dimensions( $info[0], $info[1] );
	}

	/**
	 * Full 8-case EXIF orientation & mirroring handler.
	 */
	public static function fix_orientation( $file_path ) {
		if ( ! function_exists( 'exif_read_data' ) || ! file_exists( $file_path ) || ! is_file( $file_path ) || is_link( $file_path ) ) {
			return;
		}

		$mime = wp_check_filetype( $file_path );

		if ( empty( $mime['type'] ) || ! in_array( $mime['type'], array( 'image/jpeg', 'image/jpg' ), true ) ) {
			return;
		}

		$exif = @exif_read_data( $file_path );

		if ( empty( $exif['Orientation'] ) ) {
			return;
		}

		$orientation = (int) $exif['Orientation'];

		if ( 1 === $orientation ) {
			return;
		}

		$source = @imagecreatefromjpeg( $file_path );

		if ( ! $source ) {
			return;
		}

		switch ( $orientation ) {
			case 2:
				if ( ! imageflip( $source, IMG_FLIP_HORIZONTAL ) ) {
					imagedestroy( $source );
					return;
				}
				break;

			case 3:
				$rotated = imagerotate( $source, 180, 0 );

				if ( false === $rotated ) {
					imagedestroy( $source );
					return;
				}

				imagedestroy( $source );
				$source = $rotated;
				break;

			case 4:
				if ( ! imageflip( $source, IMG_FLIP_VERTICAL ) ) {
					imagedestroy( $source );
					return;
				}
				break;

			case 5:
				if ( ! imageflip( $source, IMG_FLIP_VERTICAL ) ) {
					imagedestroy( $source );
					return;
				}

				$rotated = imagerotate( $source, -90, 0 );

				if ( false === $rotated ) {
					imagedestroy( $source );
					return;
				}

				imagedestroy( $source );
				$source = $rotated;
				break;

			case 6:
				$rotated = imagerotate( $source, -90, 0 );

				if ( false === $rotated ) {
					imagedestroy( $source );
					return;
				}

				imagedestroy( $source );
				$source = $rotated;
				break;

			case 7:
				if ( ! imageflip( $source, IMG_FLIP_HORIZONTAL ) ) {
					imagedestroy( $source );
					return;
				}

				$rotated = imagerotate( $source, -90, 0 );

				if ( false === $rotated ) {
					imagedestroy( $source );
					return;
				}

				imagedestroy( $source );
				$source = $rotated;
				break;

			case 8:
				$rotated = imagerotate( $source, 90, 0 );

				if ( false === $rotated ) {
					imagedestroy( $source );
					return;
				}

				imagedestroy( $source );
				$source = $rotated;
				break;
		}

		if ( $source ) {
			imagejpeg( $source, $file_path, 95 );
			imagedestroy( $source );
		}
	}

	public static function create_image_resource( $file_path_or_data, $is_binary = false ) {
		if ( $is_binary ) {
			if ( '' !== self::get_binary_decode_error( $file_path_or_data ) ) {
				return false;
			}

			if ( function_exists( 'wp_raise_memory_limit' ) ) {
				wp_raise_memory_limit( 'image' );
			}

			return @imagecreatefromstring( $file_path_or_data );
		}

		if ( '' !== self::get_file_decode_error( $file_path_or_data ) ) {
			return false;
		}

		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'image' );
		}

		$info = @getimagesize( $file_path_or_data );

		if ( ! $info ) {
			$data = @file_get_contents( $file_path_or_data );

			return false !== $data ? @imagecreatefromstring( $data ) : false;
		}

		switch ( $info[2] ) {
			case IMAGETYPE_JPEG:
				return @imagecreatefromjpeg( $file_path_or_data );
			case IMAGETYPE_PNG:
				return @imagecreatefrompng( $file_path_or_data );
			case IMAGETYPE_GIF:
				return @imagecreatefromgif( $file_path_or_data );
			case IMAGETYPE_WEBP:
				return function_exists( 'imagecreatefromwebp' ) ? @imagecreatefromwebp( $file_path_or_data ) : false;
		}

		$data = @file_get_contents( $file_path_or_data );

		return false !== $data ? @imagecreatefromstring( $data ) : false;
	}

	public static function hex_to_rgb( $hex ) {
		$hex = ltrim( (string) $hex, '#' );

		if ( 3 === strlen( $hex ) ) {
			return array(
				hexdec( substr( $hex, 0, 1 ) . substr( $hex, 0, 1 ) ),
				hexdec( substr( $hex, 1, 1 ) . substr( $hex, 1, 1 ) ),
				hexdec( substr( $hex, 2, 1 ) . substr( $hex, 2, 1 ) ),
			);
		}

		if ( 6 === strlen( $hex ) ) {
			return array(
				hexdec( substr( $hex, 0, 2 ) ),
				hexdec( substr( $hex, 2, 2 ) ),
				hexdec( substr( $hex, 4, 2 ) ),
			);
		}

		return array( 247, 246, 242 );
	}

	/**
	 * Studio Canvas composition (1200x1600, 3:4) with strict WebP write validation.
	 *
	 * target_max_kb is the only size target: qualities are probed from 90
	 * down to 15 and the first (highest-quality) result at or under the
	 * ceiling is used. If even quality 15 is still over the ceiling (very
	 * high-detail source images), the smallest file WebP could actually
	 * produce is used as a last resort - marked with over_ceiling => true
	 * in the return value - rather than failing the whole image. Failure is
	 * now reserved for genuine encode errors (e.g. GD could not write a
	 * WebP file at all).
	 */
	public static function compose_and_save( $source_res, $output_file_path, $bg_color_hex = '#F7F6F2', $fill_mode = 'contain' ) {
		if ( ! is_resource( $source_res ) && ! ( is_object( $source_res ) && $source_res instanceof GdImage ) ) {
			return new WP_Error( 'invalid_image', __( 'Invalid image resource provided for composition.', 'bw-product-image-ai-processor' ) );
		}

		if ( ! function_exists( 'imagewebp' ) ) {
			return new WP_Error( 'no_webp', __( 'PHP GD imagewebp is missing on this server.', 'bw-product-image-ai-processor' ) );
		}

		$output_dir = dirname( $output_file_path );

		if ( ! is_dir( $output_dir ) || ! is_writable( $output_dir ) ) {
			return new WP_Error( 'write_failed', __( 'Output directory is missing or not writable.', 'bw-product-image-ai-processor' ) );
		}

		if ( file_exists( $output_file_path ) && ( ! is_file( $output_file_path ) || is_link( $output_file_path ) || ! is_writable( $output_file_path ) ) ) {
			return new WP_Error( 'write_failed', __( 'Unsafe or non-writable output file path.', 'bw-product-image-ai-processor' ) );
		}

		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'image' );
		}

		$canvas_w = 1200;
		$canvas_h = 1600;

		$canvas = imagecreatetruecolor( $canvas_w, $canvas_h );

		imagealphablending( $canvas, true );
		imagesavealpha( $canvas, false );

		list( $r, $g, $b ) = self::hex_to_rgb( $bg_color_hex );

		// Render soft daylight studio background gradient.
		for ( $y = 0; $y < $canvas_h; $y++ ) {
			$factor     = ( $y / $canvas_h ) * 0.04;
			$cr         = (int) max( 0, min( 255, $r * ( 1.02 - $factor ) ) );
			$cg         = (int) max( 0, min( 255, $g * ( 1.02 - $factor ) ) );
			$cb         = (int) max( 0, min( 255, $b * ( 1.02 - $factor ) ) );
			$line_color = imagecolorallocate( $canvas, $cr, $cg, $cb );
			imageline( $canvas, 0, $y, $canvas_w, $y, $line_color );
		}

		$src_w = imagesx( $source_res );
		$src_h = imagesy( $source_res );

		$fill_mode = in_array( $fill_mode, array( 'contain', 'cover' ), true ) ? $fill_mode : 'contain';

		if ( 'cover' === $fill_mode ) {
			/*
			 * Cover fit: the source already carries its own full studio
			 * background (from an AI background-replacement provider), so
			 * it must fill the entire 1200x1600 canvas edge to edge rather
			 * than being padded onto a second, independently generated
			 * background - padding it would show a visible seam where the
			 * two different backgrounds meet. Scale up to the larger of the
			 * two ratios so the canvas is fully covered, and let any
			 * overflow be clipped by imagecopyresampled() against the
			 * destination canvas bounds (standard GD "cover" technique).
			 */
			$scale = max( $canvas_w / $src_w, $canvas_h / $src_h );
		} else {
			$max_w = 1080;
			$max_h = 1472;

			$scale_w = $max_w / $src_w;
			$scale_h = $max_h / $src_h;

			// No-upscale blur guard: never stretch smaller images beyond 1.0.
			$scale = min( 1.0, min( $scale_w, $scale_h ) );
		}

		$new_w = (int) round( $src_w * $scale );
		$new_h = (int) round( $src_h * $scale );
		$dst_x = (int) round( ( $canvas_w - $new_w ) / 2 );
		$dst_y = (int) round( ( $canvas_h - $new_h ) / 2 );

		/*
		 * The destination canvas already has imagealphablending(true) set
		 * above (line 324), which is what makes a transparent source
		 * correctly blend against the canvas's painted background rather
		 * than overwrite it. The SOURCE side needs the opposite pair -
		 * imagealphablending(false) + imagesavealpha(true) - so GD reads
		 * and carries its raw per-pixel alpha through the resample instead
		 * of treating it as already-blended/opaque. Without this, a
		 * transparent AI cutout (Remove.bg) can render as if its
		 * "removed" pixels were fully opaque, showing the original
		 * background completely unchanged - this is not needed for an
		 * already-opaque source (Clipdrop/Photoroom cover-fit, Local Mode)
		 * but is harmless for one either way.
		 */
		imagealphablending( $source_res, false );
		imagesavealpha( $source_res, true );
		imagecopyresampled( $canvas, $source_res, $dst_x, $dst_y, 0, 0, $new_w, $new_h, $src_w, $src_h );

		$target_max = max( 20, (int) BW_PIP_Settings::get( 'target_max_kb', 200 ) ) * 1024;

		$temp_file = dirname( $output_file_path ) . '/' . wp_basename( $output_file_path ) . '.tmp-' . wp_generate_password( 8, false ) . '.webp';

		$probe_qualities = array( 90, 85, 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30, 25, 20, 15 );
		$chosen_quality  = 0;
		$found           = false;
		$over_ceiling    = false;
		$last_quality    = 0;
		$last_size       = 0;

		foreach ( $probe_qualities as $quality ) {
			if ( @imagewebp( $canvas, $temp_file, $quality ) ) {
				clearstatcache( true, $temp_file );

				$size = (int) @filesize( $temp_file );

				if ( $size > 0 ) {
					// Track the last successful encode as a last-resort fallback.
					// Qualities run high to low, so by the time the loop ends this
					// is the smallest file GD was actually able to produce.
					$last_quality = $quality;
					$last_size    = $size;

					if ( $size <= $target_max ) {
						$chosen_quality = $quality;
						$found          = true;
						break;
					}
				}
			}
		}

		if ( ! $found && $last_quality > 0 && $last_size > 0 && file_exists( $temp_file ) ) {
			// Even the lowest probed quality is still over the configured ceiling.
			// This happens on very high-detail/high-entropy source images (busy
			// patterns, sequins, embroidery). Rather than leaving the product
			// with no processed image at all, keep the smallest file WebP could
			// actually produce and flag it so the admin can see it exceeded
			// target_max_kb, instead of failing the whole image outright.
			$chosen_quality = $last_quality;
			$found          = true;
			$over_ceiling   = true;
		}

		imagedestroy( $canvas );

		if ( ! $found ) {
			if ( file_exists( $temp_file ) ) {
				@unlink( $temp_file );
			}

			return new WP_Error(
				'webp_encode_failed',
				__( 'Unable to produce a valid WebP file at any quality level (the source image may be corrupted or unsupported).', 'bw-product-image-ai-processor' )
			);
		}

		if ( ! rename( $temp_file, $output_file_path ) ) {
			if ( file_exists( $temp_file ) ) {
				@unlink( $temp_file );
			}

			return new WP_Error( 'write_failed', __( 'Filesystem validation failed: WebP file could not be written.', 'bw-product-image-ai-processor' ) );
		}

		clearstatcache( true, $output_file_path );

		if ( ! file_exists( $output_file_path ) || (int) @filesize( $output_file_path ) <= 0 ) {
			return new WP_Error( 'write_failed', __( 'Filesystem validation failed: WebP file could not be verified.', 'bw-product-image-ai-processor' ) );
		}

		return array(
			'file_path'    => $output_file_path,
			'file_size'    => (int) @filesize( $output_file_path ),
			'width'        => $canvas_w,
			'height'       => $canvas_h,
			'quality'      => $chosen_quality,
			'over_ceiling' => $over_ceiling,
		);
	}
}