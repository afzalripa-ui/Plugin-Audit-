<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BW_PIP_Queue {

	const ACTION_HOOK = 'bw_pip_process_image_async';
	const LOCK_TTL    = 900;

	public static function init() {
		add_action( self::ACTION_HOOK, array( __CLASS__, 'handle_async_action' ), 10, 1 );
	}

	public static function schedule_image( $attachment_id ) {
		$attachment_id = absint( $attachment_id );

		if ( ! $attachment_id ) {
			return;
		}

		$lock_key = 'bw_pip_lock_' . $attachment_id;

		if ( get_transient( $lock_key ) ) {
			return;
		}

		if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_schedule_single_action' ) ) {
			if ( as_has_scheduled_action( self::ACTION_HOOK, array( $attachment_id ) ) ) {
				return;
			}

			set_transient( $lock_key, 1, self::LOCK_TTL );

			update_post_meta( $attachment_id, '_bw_pip_status', 'pending' );
			update_post_meta( $attachment_id, '_bw_pip_log', __( 'Queued for background processing.', 'bw-product-image-ai-processor' ) );

			$action_id = as_schedule_single_action( time() + 2, self::ACTION_HOOK, array( $attachment_id ) );

			if ( ! $action_id ) {
				delete_transient( $lock_key );

				update_post_meta( $attachment_id, '_bw_pip_status', 'failed' );
				update_post_meta( $attachment_id, '_bw_pip_log', __( 'Queue error: Action Scheduler could not create the image processing job.', 'bw-product-image-ai-processor' ) );
			}

			return;
		}

		if ( wp_next_scheduled( self::ACTION_HOOK, array( $attachment_id ) ) ) {
			return;
		}

		set_transient( $lock_key, 1, self::LOCK_TTL );

		update_post_meta( $attachment_id, '_bw_pip_status', 'pending' );
		update_post_meta( $attachment_id, '_bw_pip_log', __( 'Queued for background processing.', 'bw-product-image-ai-processor' ) );

		$scheduled = wp_schedule_single_event( time() + 2, self::ACTION_HOOK, array( $attachment_id ) );

		if ( false === $scheduled ) {
			delete_transient( $lock_key );

			update_post_meta( $attachment_id, '_bw_pip_status', 'failed' );
			update_post_meta( $attachment_id, '_bw_pip_log', __( 'Queue error: WordPress cron could not create the image processing job.', 'bw-product-image-ai-processor' ) );
		}
	}

	public static function handle_async_action( $attachment_id ) {
		$attachment_id = absint( $attachment_id );
		$lock_key      = 'bw_pip_lock_' . $attachment_id;

		if ( ! $attachment_id ) {
			delete_transient( $lock_key );

			return;
		}

		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 180 );
		}

		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'image' );
		}

		BW_PIP_Processor::process_attachment( $attachment_id );

		delete_transient( $lock_key );
	}
}