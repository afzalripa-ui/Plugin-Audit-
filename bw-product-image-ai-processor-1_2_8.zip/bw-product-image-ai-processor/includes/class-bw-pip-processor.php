<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BW_PIP_Processor {

	const BACKFILL_HOOK    = 'bw_pip_backfill_product_markers';
	const BACKFILL_VERSION = 1;
	const BACKFILL_BATCH   = 50;

	private static $is_processing = array();

	public static function init() {
		add_filter( 'wp_generate_attachment_metadata', array( __CLASS__, 'on_generate_metadata_enqueue' ), 10, 2 );
		add_action( 'save_post_product', array( __CLASS__, 'on_product_save' ), 20, 2 );
		// WooCommerce saves the gallery/thumbnail fields on this action
		// (WC_Meta_Box_Product_Images::save runs on it at priority 20), which
		// is a more reliable "product images are now saved" signal than
		// save_post_product for the classic product-edit screen. Kept
		// alongside save_post_product (not instead of it) since that one
		// still covers save paths this action does not (REST API, the
		// block-based Product Editor, programmatic updates).
		add_action( 'woocommerce_process_product_meta', array( __CLASS__, 'on_product_meta_processed' ), 30 );
		add_action( self::BACKFILL_HOOK, array( __CLASS__, 'run_marker_backfill_batch' ) );
	}

	private static function acquire_processing_lock( $attachment_id ) {
		$attachment_id = absint( $attachment_id );
		$key           = 'bw_pip_processing_lock_' . $attachment_id;
		$now           = time();
		$ttl           = 15 * MINUTE_IN_SECONDS;
		$existing      = get_option( $key, 0 );

		if ( $existing && ( $now - (int) $existing ) < $ttl ) {
			return false;
		}

		if ( $existing ) {
			delete_option( $key );
		}

		if ( add_option( $key, $now, '', 'no' ) ) {
			return true;
		}

		$existing = get_option( $key, 0 );

		if ( $existing && ( $now - (int) $existing ) < $ttl ) {
			return false;
		}

		return false;
	}

	private static function release_processing_lock( $attachment_id ) {
		delete_option( 'bw_pip_processing_lock_' . absint( $attachment_id ) );
	}

	private static function fail_process( $attachment_id, $message ) {
		update_post_meta( $attachment_id, '_bw_pip_status', 'failed' );
		update_post_meta( $attachment_id, '_bw_pip_log', $message );

		return false;
	}

	public static function get_product_image_ids( $post_id ) {
		$post_id = absint( $post_id );
		$images  = array();

		$thumb_id = get_post_thumbnail_id( $post_id );

		if ( $thumb_id ) {
			$images[] = absint( $thumb_id );
		}

		$gallery = get_post_meta( $post_id, '_product_image_gallery', true );

		if ( ! empty( $gallery ) ) {
			$images = array_merge( $images, array_filter( array_map( 'absint', explode( ',', $gallery ) ) ) );
		}

		return array_values( array_unique( $images ) );
	}

	private static function find_product_owning_attachment( $attachment_id, $exclude_product_id = 0 ) {
		global $wpdb;

		$attachment_id      = absint( $attachment_id );
		$exclude_product_id = absint( $exclude_product_id );

		if ( ! $attachment_id ) {
			return 0;
		}

		$thumbnail_product = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT p.ID
				FROM {$wpdb->posts} AS p
				INNER JOIN {$wpdb->postmeta} AS pm ON pm.post_id = p.ID
				WHERE p.post_type = 'product'
				AND p.ID <> %d
				AND pm.meta_key = '_thumbnail_id'
				AND pm.meta_value = %s
				LIMIT 1",
				$exclude_product_id,
				(string) $attachment_id
			)
		);

		if ( ! empty( $thumbnail_product ) ) {
			return absint( $thumbnail_product );
		}

		$gallery_pattern = '(^|,)' . $attachment_id . '(,|$)';

		$gallery_product = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT p.ID
				FROM {$wpdb->posts} AS p
				INNER JOIN {$wpdb->postmeta} AS pm ON pm.post_id = p.ID
				WHERE p.post_type = 'product'
				AND p.ID <> %d
				AND pm.meta_key = '_product_image_gallery'
				AND pm.meta_value REGEXP %s
				LIMIT 1",
				$exclude_product_id,
				$gallery_pattern
			)
		);

		return absint( $gallery_product );
	}

	private static function attachment_used_by_other_product( $attachment_id, $exclude_product_id = 0 ) {
		return self::find_product_owning_attachment( $attachment_id, $exclude_product_id ) > 0;
	}

	public static function mark_product_images( $post_id ) {
		$post_id = absint( $post_id );

		if ( ! $post_id ) {
			return;
		}

		$new_ids = self::get_product_image_ids( $post_id );
		$old_ids = get_post_meta( $post_id, '_bw_pip_product_image_ids', true );

		if ( ! is_array( $old_ids ) ) {
			$old_ids = array();
		}

		$old_ids = array_filter( array_map( 'absint', $old_ids ) );

		foreach ( $old_ids as $old_id ) {
			if ( ! in_array( $old_id, $new_ids, true ) && ! self::attachment_used_by_other_product( $old_id, $post_id ) ) {
				delete_post_meta( $old_id, '_bw_pip_product_image' );
			}
		}

		foreach ( $new_ids as $new_id ) {
			update_post_meta( $new_id, '_bw_pip_product_image', '1' );
		}

		update_post_meta( $post_id, '_bw_pip_product_image_ids', $new_ids );
	}

	public static function maybe_schedule_marker_backfill() {
		if ( (int) get_option( 'bw_pip_marker_backfill_done_version', 0 ) >= self::BACKFILL_VERSION ) {
			return;
		}

		if ( get_transient( 'bw_pip_marker_backfill_schedule_lock' ) ) {
			return;
		}

		set_transient( 'bw_pip_marker_backfill_schedule_lock', 1, 10 * MINUTE_IN_SECONDS );

		self::schedule_marker_backfill_batch();
	}

	private static function schedule_marker_backfill_batch() {
		if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_schedule_single_action' ) ) {
			if ( ! as_has_scheduled_action( self::BACKFILL_HOOK ) ) {
				as_schedule_single_action( time() + 1, self::BACKFILL_HOOK );
			}

			return;
		}

		if ( ! wp_next_scheduled( self::BACKFILL_HOOK ) ) {
			wp_schedule_single_event( time() + 1, self::BACKFILL_HOOK );
		}
	}

	public static function run_marker_backfill_batch() {
		if ( (int) get_option( 'bw_pip_marker_backfill_done_version', 0 ) >= self::BACKFILL_VERSION ) {
			return;
		}

		if ( get_transient( 'bw_pip_marker_backfill_running' ) ) {
			return;
		}

		set_transient( 'bw_pip_marker_backfill_running', 1, 5 * MINUTE_IN_SECONDS );

		global $wpdb;

		$cursor = absint( get_option( 'bw_pip_marker_backfill_cursor', 0 ) );

		$product_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID
				FROM {$wpdb->posts}
				WHERE post_type = %s
				AND ID > %d
				ORDER BY ID ASC
				LIMIT %d",
				'product',
				$cursor,
				self::BACKFILL_BATCH
			)
		);

		if ( empty( $product_ids ) ) {
			update_option( 'bw_pip_marker_backfill_done_version', self::BACKFILL_VERSION );
			delete_option( 'bw_pip_marker_backfill_cursor' );
			delete_transient( 'bw_pip_marker_backfill_running' );
			delete_transient( 'bw_pip_marker_backfill_schedule_lock' );

			return;
		}

		foreach ( $product_ids as $product_id ) {
			self::mark_product_images( absint( $product_id ) );
			$cursor = max( $cursor, absint( $product_id ) );
		}

		update_option( 'bw_pip_marker_backfill_cursor', $cursor );

		if ( count( $product_ids ) < self::BACKFILL_BATCH ) {
			update_option( 'bw_pip_marker_backfill_done_version', self::BACKFILL_VERSION );
			delete_option( 'bw_pip_marker_backfill_cursor' );
			delete_transient( 'bw_pip_marker_backfill_schedule_lock' );
		} else {
			self::schedule_marker_backfill_batch();
		}

		delete_transient( 'bw_pip_marker_backfill_running' );
	}

	public static function is_product_image( $attachment_id, $post_id = 0 ) {
		$attachment_id = absint( $attachment_id );

		if ( ! $attachment_id ) {
			return false;
		}

		if ( '1' === get_post_meta( $attachment_id, '_bw_pip_product_image', true ) ) {
			return true;
		}

		if ( ! $post_id ) {
			$post_id = wp_get_post_parent_id( $attachment_id );
		}

		if ( $post_id && 'product' === get_post_type( $post_id ) ) {
			return true;
		}

		if ( ! empty( $_REQUEST['post_id'] ) ) {
			$request_post_id = absint( $_REQUEST['post_id'] );

			if (
				$request_post_id
				&& 'product' === get_post_type( $request_post_id )
				&& current_user_can( 'edit_post', $request_post_id )
			) {
				return true;
			}
		}

		/*
		 * Last resort: the checks above depend on the _bw_pip_product_image
		 * meta flag (set when a product is saved) or post_parent (only set
		 * for a fresh upload made directly in that product's editor screen).
		 * Neither catches a gallery image that was attached to a product
		 * without the product being re-saved since, or one reused from the
		 * Media Library whose post_parent was never the product. Before
		 * giving up, check WooCommerce's own current gallery/thumbnail data
		 * directly - it's the actual source of truth and always current,
		 * regardless of which save path (classic editor, block-based
		 * Product Editor, REST API, import) set it.
		 */
		$owning_product = self::find_product_owning_attachment( $attachment_id );

		if ( $owning_product ) {
			update_post_meta( $attachment_id, '_bw_pip_product_image', '1' );

			return true;
		}

		return false;
	}

	public static function on_generate_metadata_enqueue( $metadata, $attachment_id ) {
		if ( ! BW_PIP_Settings::get( 'enable_auto_process', 1 ) ) {
			return $metadata;
		}

		$status = get_post_meta( $attachment_id, '_bw_pip_status', true );

		if ( in_array( $status, array( 'completed', 'processing', 'pending', 'restored' ), true ) ) {
			return $metadata;
		}

		if ( BW_PIP_Settings::get( 'process_products_only', 1 ) && ! self::is_product_image( $attachment_id ) ) {
			update_post_meta( $attachment_id, '_bw_pip_status', 'skipped' );
			update_post_meta( $attachment_id, '_bw_pip_log', __( 'Skipped: Not detected as WooCommerce product image.', 'bw-product-image-ai-processor' ) );

			return $metadata;
		}

		BW_PIP_Queue::schedule_image( $attachment_id );

		return $metadata;
	}

	public static function on_product_save( $post_id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		self::mark_product_images( $post_id );

		if ( ! BW_PIP_Settings::get( 'enable_auto_process', 1 ) ) {
			return;
		}

		$image_ids = get_post_meta( $post_id, '_bw_pip_product_image_ids', true );

		if ( empty( $image_ids ) || ! is_array( $image_ids ) ) {
			return;
		}

		foreach ( $image_ids as $image_id ) {
			$image_id = absint( $image_id );

			if ( ! $image_id ) {
				continue;
			}

			$status = get_post_meta( $image_id, '_bw_pip_status', true );

			if ( in_array( $status, array( 'completed', 'processing', 'restored' ), true ) ) {
				continue;
			}

			BW_PIP_Queue::schedule_image( $image_id );
		}
	}

	/**
	 * Thin wrapper for the woocommerce_process_product_meta hook, which
	 * only passes a product ID (not a post object) - reuses on_product_save()
	 * rather than duplicating its marking/scheduling logic.
	 */
	public static function on_product_meta_processed( $post_id ) {
		$post_id = absint( $post_id );

		if ( ! $post_id ) {
			return;
		}

		$post = get_post( $post_id );

		if ( $post ) {
			self::on_product_save( $post_id, $post );
		}
	}

	public static function process_attachment( $attachment_id ) {
		$attachment_id = absint( $attachment_id );

		if ( ! $attachment_id ) {
			return false;
		}

		if ( ! self::acquire_processing_lock( $attachment_id ) ) {
			return false;
		}

		$working_copy  = '';
		$previous_copy = '';
		$target_path   = '';
		$current_file  = '';

		try {
			if ( ! empty( self::$is_processing[ $attachment_id ] ) ) {
				return false;
			}

			self::$is_processing[ $attachment_id ] = true;

			if ( ! wp_attachment_is_image( $attachment_id ) ) {
				return self::fail_process( $attachment_id, __( 'Attachment is not an image.', 'bw-product-image-ai-processor' ) );
			}

			if ( BW_PIP_Settings::get( 'process_products_only', 1 ) && ! self::is_product_image( $attachment_id ) ) {
				update_post_meta( $attachment_id, '_bw_pip_status', 'skipped' );
				update_post_meta( $attachment_id, '_bw_pip_log', __( 'Skipped: Not detected as WooCommerce product image.', 'bw-product-image-ai-processor' ) );

				return false;
			}

			$current_file = BW_PIP_Backup::normalize_path( get_attached_file( $attachment_id ) );

			if (
				'' === $current_file
				|| ! BW_PIP_Backup::is_safe_upload_path( $current_file )
				|| ! file_exists( $current_file )
				|| ! is_file( $current_file )
				|| is_link( $current_file )
			) {
				return self::fail_process( $attachment_id, __( 'Attached file not found or unsafe.', 'bw-product-image-ai-processor' ) );
			}

			update_post_meta( $attachment_id, '_bw_pip_status', 'processing' );

			$source_input_file = $current_file;
			$original_source   = get_post_meta( $attachment_id, '_bw_pip_original_file', true );

			if ( BW_PIP_Backup::has_valid_backup( $attachment_id ) ) {
				$backup_path       = get_post_meta( $attachment_id, '_bw_pip_backup_path', true );
				$source_input_file = BW_PIP_Backup::normalize_path( $backup_path );
			}

			// Backup creation is opt-out via the "Enable Original Image Backup"
			// setting (default on). This is an informed choice now, not a
			// silent trap: the settings page clearly warns what turning it off
			// means, and the admin can download/manage backups from there too.
			if ( BW_PIP_Settings::get( 'enable_backup', 1 ) ) {
				$backup_created = BW_PIP_Backup::create_backup( $attachment_id, $source_input_file );

				if ( ! $backup_created || ! file_exists( $backup_created ) ) {
					return self::fail_process( $attachment_id, __( 'Security Abort: Backup creation failed. Original image preserved untouched.', 'bw-product-image-ai-processor' ) );
				}
			}

			$decode_error = BW_PIP_Canvas::get_file_decode_error( $source_input_file );

			if ( '' !== $decode_error ) {
				return self::fail_process( $attachment_id, $decode_error );
			}

			$base_dir = dirname( $current_file );

			if ( ! is_dir( $base_dir ) || ! is_writable( $base_dir ) ) {
				return self::fail_process( $attachment_id, __( 'Upload directory is missing or not writable.', 'bw-product-image-ai-processor' ) );
			}

			$image_info   = @getimagesize( $source_input_file );
			$detected_ext = '.jpg';

			if ( ! empty( $image_info[2] ) ) {
				switch ( $image_info[2] ) {
					case IMAGETYPE_JPEG:
						$detected_ext = '.jpg';
						break;
					case IMAGETYPE_PNG:
						$detected_ext = '.png';
						break;
					case IMAGETYPE_WEBP:
						$detected_ext = '.webp';
						break;
					case IMAGETYPE_GIF:
						$detected_ext = '.gif';
						break;
				}
			} elseif ( ! empty( $original_source ) ) {
				$fallback_ext = strtolower( pathinfo( $original_source, PATHINFO_EXTENSION ) );

				if ( in_array( $fallback_ext, array( 'jpg', 'jpeg', 'png', 'webp', 'gif' ), true ) ) {
					$detected_ext = '.' . $fallback_ext;
				}
			}

			do {
				$working_copy = $base_dir . '/.bw-pip-work-' . $attachment_id . '-' . wp_generate_password( 10, false ) . $detected_ext;
			} while ( file_exists( $working_copy ) );

			if ( ! copy( $source_input_file, $working_copy ) ) {
				return self::fail_process( $attachment_id, __( 'Security Abort: Temporary working copy could not be created. Original image and backup preserved untouched.', 'bw-product-image-ai-processor' ) );
			}

			if ( ! BW_PIP_Backup::is_safe_upload_path( $working_copy ) ) {
				return self::fail_process( $attachment_id, __( 'Temporary working copy path is unsafe.', 'bw-product-image-ai-processor' ) );
			}

			BW_PIP_Canvas::fix_orientation( $working_copy );

			$enable_ai   = (bool) BW_PIP_Settings::get( 'enable_ai', 0 );
			$api_key     = BW_PIP_Settings::get_api_key();
			$provider_id = BW_PIP_Settings::get( 'ai_provider', 'photoroom' );
			$prompt      = BW_PIP_Settings::get( 'bg_prompt', '' );
			$bg_color    = BW_PIP_Settings::get( 'bg_color', '#F7F6F2' );

			$source_res        = null;
			$log_notes         = '';
			$composition_mode  = 'contain';

			if ( $enable_ai && '' !== $api_key ) {
				$provider = null;

				switch ( $provider_id ) {
					case 'photoroom':
						$provider = new BW_PIP_Provider_Photoroom( $api_key );
						break;
					case 'clipdrop':
						$provider = new BW_PIP_Provider_Clipdrop( $api_key );
						break;
					case 'removebg':
						$provider = new BW_PIP_Provider_Removebg( $api_key );
						break;
				}

				if ( $provider ) {
					$ai_result = $provider->process_image( $working_copy, $prompt );

					if ( ! empty( $ai_result['success'] ) && ! empty( $ai_result['image_data'] ) ) {
						$binary_error = BW_PIP_Canvas::get_binary_decode_error( $ai_result['image_data'] );

						if ( '' === $binary_error ) {
							$source_res = BW_PIP_Canvas::create_image_resource( $ai_result['image_data'], true );
						}

						if ( $source_res ) {
							if ( 'removebg' === $provider_id ) {
								$too_small = false;

								if ( ! empty( $ai_result['downgraded'] ) ) {
									$src_w = imagesx( $source_res );
									$src_h = imagesy( $source_res );

									/*
									 * Remove.bg's size=auto downgrade (only triggered when
									 * the account has no full-size credit left) can return
									 * an image as small as its free "preview" tier
									 * (~625x400px). "Contain" mode deliberately never
									 * upscales past a source's own resolution, to avoid a
									 * blurry result - but that means a preview-sized image
									 * would sit tiny in the middle of the 1200x1600 canvas
									 * instead of filling it (reported directly: looked
									 * "doll-sized"). Below this size it no longer reads as
									 * a usable product photo, so it's discarded in favor of
									 * Local Mode (the original photo at full resolution)
									 * instead.
									 */
									if ( $src_w < 600 || $src_h < 600 ) {
										$too_small = true;
									}
								}

								if ( $too_small ) {
									imagedestroy( $source_res );
									$source_res = null;
									$log_notes  = __( 'AI fallback to local studio canvas. Remove.bg\'s auto-selected resolution (no paid credit left for full size) was too small to composite well, so the original photo was used instead.', 'bw-product-image-ai-processor' );
								} else {
									$log_notes = __( 'Background removed with Remove.bg API and composited on local studio canvas.', 'bw-product-image-ai-processor' );

									if ( ! empty( $ai_result['downgraded'] ) ) {
										$log_notes .= ' ' . __( 'Note: full resolution needed a paid credit your Remove.bg account did not have, so this ran at Remove.bg\'s auto-selected resolution instead (still real AI background removal, just not full-size).', 'bw-product-image-ai-processor' );
									}
								}
							} elseif ( 'clipdrop' === $provider_id ) {
								$log_notes        = __( 'Processed with Clipdrop Replace Background API.', 'bw-product-image-ai-processor' );
								$composition_mode = 'cover';
							} else {
								$log_notes        = __( 'Processed with PhotoRoom AI API.', 'bw-product-image-ai-processor' );
								$composition_mode = 'cover';
							}
						} else {
							$error     = '' !== $binary_error ? $binary_error : __( 'AI response could not be decoded.', 'bw-product-image-ai-processor' );
							$log_notes = sprintf( __( 'AI fallback to local studio canvas. %s', 'bw-product-image-ai-processor' ), $error );
						}
					} else {
						$error     = ! empty( $ai_result['error'] ) ? $ai_result['error'] : 'unknown error';
						$log_notes = sprintf( __( 'AI fallback to local studio canvas. %s', 'bw-product-image-ai-processor' ), $error );
					}
				}
			} else {
				$log_notes = __( 'Processed with Smart Studio Canvas (Local Mode). Existing background preserved.', 'bw-product-image-ai-processor' );
			}

			if ( ! $source_res ) {
				$decode_error = BW_PIP_Canvas::get_file_decode_error( $working_copy );

				if ( '' !== $decode_error ) {
					return self::fail_process( $attachment_id, $decode_error );
				}

				$source_res = BW_PIP_Canvas::create_image_resource( $working_copy, false );
			}

			if ( file_exists( $working_copy ) ) {
				@unlink( $working_copy );
				$working_copy = '';
			}

			if ( ! $source_res ) {
				return self::fail_process( $attachment_id, __( 'Could not decode image resource.', 'bw-product-image-ai-processor' ) );
			}

			$base_reference = ! empty( $original_source ) ? $original_source : $current_file;
			$basename       = wp_basename( $base_reference );
			$clean_basename = pathinfo( $basename, PATHINFO_FILENAME );
			$clean_basename = preg_replace( '/-bw-1200x1600$/', '', $clean_basename );
			$clean_basename = sanitize_file_name( $clean_basename );

			if ( '' === $clean_basename ) {
				$clean_basename = 'image';
			}

			$target_path = $base_dir . '/' . $clean_basename . '-bw-1200x1600.webp';

			if ( $target_path === $current_file && file_exists( $current_file ) ) {
				do {
					$previous_copy = $base_dir . '/.bw-pip-prev-' . $attachment_id . '-' . wp_generate_password( 10, false ) . '.webp';
				} while ( file_exists( $previous_copy ) );

				if ( ! copy( $current_file, $previous_copy ) ) {
					$previous_copy = '';

					return self::fail_process( $attachment_id, __( 'Could not create safe previous-file copy before overwrite.', 'bw-product-image-ai-processor' ) );
				}
			}

			$comp_result = BW_PIP_Canvas::compose_and_save( $source_res, $target_path, $bg_color, $composition_mode );

			imagedestroy( $source_res );

			if ( is_wp_error( $comp_result ) || ! file_exists( $target_path ) || (int) @filesize( $target_path ) <= 0 ) {
				if ( $target_path === $current_file && $previous_copy && file_exists( $previous_copy ) ) {
					@rename( $previous_copy, $target_path );
					$previous_copy = '';
				}

				$err = is_wp_error( $comp_result ) ? $comp_result->get_error_message() : __( 'WebP filesystem write validation failed.', 'bw-product-image-ai-processor' );

				return self::fail_process( $attachment_id, $err );
			}

			$old_meta = wp_get_attachment_metadata( $attachment_id );

			remove_filter( 'wp_generate_attachment_metadata', array( __CLASS__, 'on_generate_metadata_enqueue' ), 10 );

			require_once ABSPATH . 'wp-admin/includes/image.php';

			$new_meta = wp_generate_attachment_metadata( $attachment_id, $target_path );

			add_filter( 'wp_generate_attachment_metadata', array( __CLASS__, 'on_generate_metadata_enqueue' ), 10, 2 );

			if ( ! is_array( $new_meta ) || empty( $new_meta['file'] ) ) {
				if ( $target_path === $current_file && $previous_copy && file_exists( $previous_copy ) ) {
					@rename( $previous_copy, $target_path );
					$previous_copy = '';
				} elseif (
					$target_path !== $current_file
					&& BW_PIP_Backup::is_safe_upload_path( $target_path )
					&& file_exists( $target_path )
					&& is_file( $target_path )
					&& ! is_link( $target_path )
				) {
					@unlink( $target_path );
				}

				return self::fail_process( $attachment_id, __( 'Metadata generation failed. Original file preserved.', 'bw-product-image-ai-processor' ) );
			}

			update_attached_file( $attachment_id, $target_path );

			wp_update_post(
				array(
					'ID'             => $attachment_id,
					'post_mime_type' => 'image/webp',
				)
			);

			wp_update_attachment_metadata( $attachment_id, $new_meta );

			if (
				$target_path !== $current_file
				&& BW_PIP_Backup::is_safe_upload_path( $current_file )
				&& ! BW_PIP_Backup::is_path_inside_backup_dir( $current_file )
				&& file_exists( $current_file )
				&& is_file( $current_file )
				&& ! is_link( $current_file )
			) {
				$can_unlink = false;

				if ( BW_PIP_Settings::get( 'enable_backup', 1 ) ) {
					$can_unlink = BW_PIP_Backup::has_valid_backup( $attachment_id );
				} else {
					$can_unlink = file_exists( $target_path ) && (int) @filesize( $target_path ) > 0;
				}

				if ( $can_unlink ) {
					@unlink( $current_file );
				}
			}

			$new_files = array( wp_basename( $target_path ) );

			if ( ! empty( $new_meta['sizes'] ) && is_array( $new_meta['sizes'] ) ) {
				foreach ( $new_meta['sizes'] as $size ) {
					if ( ! empty( $size['file'] ) ) {
						$new_files[] = wp_basename( $size['file'] );
					}
				}
			}

			if ( ! empty( $old_meta['sizes'] ) && is_array( $old_meta['sizes'] ) ) {
				foreach ( $old_meta['sizes'] as $size ) {
					if ( empty( $size['file'] ) ) {
						continue;
					}

					$thumb_name = wp_basename( $size['file'] );

					if ( '' === $thumb_name || false !== strpos( $thumb_name, '..' ) || in_array( $thumb_name, $new_files, true ) ) {
						continue;
					}

					$thumb_file = $base_dir . '/' . $thumb_name;

					if (
						BW_PIP_Backup::is_safe_upload_path( $thumb_file )
						&& ! BW_PIP_Backup::is_path_inside_backup_dir( $thumb_file )
						&& file_exists( $thumb_file )
						&& is_file( $thumb_file )
						&& ! is_link( $thumb_file )
						&& $thumb_file !== $target_path
					) {
						@unlink( $thumb_file );
					}
				}
			}

			$filesize_kb = round( $comp_result['file_size'] / 1024, 1 );

			$size_note = sprintf( __( 'Output: 1200x1600 (3:4) WebP, Size: %s KB.', 'bw-product-image-ai-processor' ), $filesize_kb );

			if ( ! empty( $comp_result['over_ceiling'] ) ) {
				$size_note .= ' ' . sprintf(
					/* translators: %d: configured max KB */
					__( 'Note: this exceeds the configured Target Max KB (%d KB) - the source image was too detailed to compress further at any tried quality. Consider raising Target Max KB if this recurs.', 'bw-product-image-ai-processor' ),
					(int) BW_PIP_Settings::get( 'target_max_kb', 200 )
				);
			}

			update_post_meta( $attachment_id, '_bw_pip_status', 'completed' );
			update_post_meta( $attachment_id, '_bw_pip_filesize', $filesize_kb . ' KB' );
			update_post_meta( $attachment_id, '_bw_pip_quality', $comp_result['quality'] );
			update_post_meta(
				$attachment_id,
				'_bw_pip_log',
				$log_notes . ' ' . $size_note
			);

			return true;
		} catch ( Throwable $e ) {
			if ( $target_path === $current_file && $previous_copy && file_exists( $previous_copy ) ) {
				@rename( $previous_copy, $target_path );
				$previous_copy = '';
			} elseif (
				$target_path
				&& $target_path !== $current_file
				&& BW_PIP_Backup::is_safe_upload_path( $target_path )
				&& file_exists( $target_path )
				&& is_file( $target_path )
				&& ! is_link( $target_path )
			) {
				@unlink( $target_path );
			}

			update_post_meta( $attachment_id, '_bw_pip_status', 'failed' );
			update_post_meta( $attachment_id, '_bw_pip_log', sprintf( __( 'Processing aborted: %s', 'bw-product-image-ai-processor' ), $e->getMessage() ) );

			return false;
		} finally {
			if ( ! empty( $working_copy ) && file_exists( $working_copy ) ) {
				@unlink( $working_copy );
			}

			if ( ! empty( $previous_copy ) && file_exists( $previous_copy ) ) {
				@unlink( $previous_copy );
			}

			unset( self::$is_processing[ $attachment_id ] );
			self::release_processing_lock( $attachment_id );
		}
	}
}