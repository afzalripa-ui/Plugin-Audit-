<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BW_PIP_Provider_Clipdrop implements BW_PIP_Provider_Interface {

	private $api_key;

	public function __construct( $api_key ) {
		$this->api_key = trim( (string) $api_key );
	}

	/**
	 * Clipdrop Replace Background accepts PNG/JPG/WEBP up to 2048px on either
	 * side and 20 MB. Prepare a disposable API copy when the source exceeds
	 * either limit so the original working image remains untouched.
	 */
	private function prepare_api_input( $file_path ) {
		$info = @getimagesize( $file_path );

		if ( ! $info || empty( $info[0] ) || empty( $info[1] ) || empty( $info[2] ) ) {
			return new WP_Error( 'clipdrop_invalid_image', 'Could not read the source image dimensions/type.' );
		}

		clearstatcache( true, $file_path );

		$file_size = (int) @filesize( $file_path );

		if ( $file_size <= 0 ) {
			return new WP_Error( 'clipdrop_invalid_file', 'Source image file is empty or unreadable.' );
		}

		$mime_type = 'image/jpeg';

		switch ( $info[2] ) {
			case IMAGETYPE_PNG:
				$mime_type = 'image/png';
				break;
			case IMAGETYPE_WEBP:
				$mime_type = 'image/webp';
				break;
			case IMAGETYPE_JPEG:
			default:
				$mime_type = 'image/jpeg';
				break;
		}

		$max_dimension = 2048;
		$max_bytes     = 20 * 1024 * 1024;
		$needs_resize  = max( (int) $info[0], (int) $info[1] ) > $max_dimension;

		if ( ! $needs_resize && $file_size <= $max_bytes ) {
			return array(
				'path'    => $file_path,
				'cleanup' => false,
				'mime'    => $mime_type,
			);
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';

		$editor = wp_get_image_editor( $file_path );

		if ( is_wp_error( $editor ) ) {
			return new WP_Error( 'clipdrop_editor_unavailable', $editor->get_error_message() );
		}

		if ( $needs_resize ) {
			$scale  = $max_dimension / max( (int) $info[0], (int) $info[1] );
			$new_w  = max( 1, (int) round( $info[0] * $scale ) );
			$new_h  = max( 1, (int) round( $info[1] * $scale ) );
			$resize = $editor->resize( $new_w, $new_h, false );

			if ( is_wp_error( $resize ) ) {
				return new WP_Error( 'clipdrop_resize_failed', $resize->get_error_message() );
			}
		}

		$editor->set_quality( 90 );

		$temp_path = wp_tempnam( 'bw-clipdrop-' . wp_basename( $file_path ) );

		if ( ! $temp_path ) {
			return new WP_Error( 'clipdrop_temp_failed', 'Could not create a temporary Clipdrop input file.' );
		}

		$saved = $editor->save( $temp_path, $mime_type );

		if ( is_wp_error( $saved ) || empty( $saved['path'] ) || ! file_exists( $saved['path'] ) || (int) @filesize( $saved['path'] ) <= 0 ) {
			if ( file_exists( $temp_path ) ) {
				@unlink( $temp_path );
			}

			$error = is_wp_error( $saved ) ? $saved->get_error_message() : 'Temporary Clipdrop input could not be written.';

			return new WP_Error( 'clipdrop_save_failed', $error );
		}

		$prepared_path = $saved['path'];

		if ( $prepared_path !== $temp_path && file_exists( $temp_path ) ) {
			@unlink( $temp_path );
		}

		if ( (int) @filesize( $prepared_path ) > $max_bytes ) {
			if ( in_array( $mime_type, array( 'image/jpeg', 'image/webp' ), true ) ) {
				$editor->set_quality( 80 );

				$saved_retry = $editor->save( $prepared_path, $mime_type );

				if ( ! is_wp_error( $saved_retry ) && ! empty( $saved_retry['path'] ) ) {
					$prepared_path = $saved_retry['path'];
				}
			}
		}

		if ( (int) @filesize( $prepared_path ) > $max_bytes ) {
			@unlink( $prepared_path );

			return new WP_Error( 'clipdrop_input_too_large', 'The prepared Clipdrop input is still larger than the provider limit.' );
		}

		return array(
			'path'    => $prepared_path,
			'cleanup' => true,
			'mime'    => $mime_type,
		);
	}

	public function process_image( $file_path, $prompt, $options = array() ) {
		if ( empty( $this->api_key ) ) {
			return array(
				'success' => false,
				'error'   => 'Clipdrop API Key is empty.',
			);
		}

		if ( '' === $file_path || ! is_file( $file_path ) || is_link( $file_path ) || ! is_readable( $file_path ) ) {
			return array(
				'success' => false,
				'error'   => 'Source image file does not exist or is not readable.',
			);
		}

		$prepared = $this->prepare_api_input( $file_path );

		if ( is_wp_error( $prepared ) ) {
			return array(
				'success' => false,
				'error'   => $prepared->get_error_message(),
			);
		}

		$api_file  = $prepared['path'];
		$mime_type = $prepared['mime'];
		$cleanup   = ! empty( $prepared['cleanup'] );

		try {
			$file_data = @file_get_contents( $api_file );

			if ( false === $file_data ) {
				return array(
					'success' => false,
					'error'   => 'Could not read the prepared Clipdrop input file.',
				);
			}

			if ( strlen( $file_data ) > 20 * 1024 * 1024 ) {
				return array(
					'success' => false,
					'error'   => 'Prepared Clipdrop input is still too large to upload.',
				);
			}

			$boundary = wp_generate_password( 24, false );
			$filename = wp_basename( $api_file );

			$headers = array(
				'x-api-key'    => $this->api_key,
				'content-type' => 'multipart/form-data; boundary=' . $boundary,
				'accept'       => 'image/png',
			);

			$body  = '--' . $boundary . "\r\n";
			$body .= 'Content-Disposition: form-data; name="image_file"; filename="' . $filename . '"' . "\r\n";
			$body .= 'Content-Type: ' . $mime_type . "\r\n\r\n";
			$body .= $file_data . "\r\n";

			/*
			 * Current plugin behavior:
			 *
			 * Clipdrop is used as Replace Background. If the saved prompt is empty,
			 * an empty prompt field is still sent. If the provider rejects the
			 * request, the processor logs the API error and falls back to local
			 * studio canvas mode.
			 */
			$body .= '--' . $boundary . "\r\n";
			$body .= 'Content-Disposition: form-data; name="prompt"' . "\r\n\r\n";
			$body .= (string) $prompt . "\r\n";

			$body .= '--' . $boundary . "--\r\n";

			$response = wp_remote_post(
				'https://clipdrop-api.co/replace-background/v1',
				array(
					'method'    => 'POST',
					'timeout'   => 50,
					'headers'   => $headers,
					'body'      => $body,
					'sslverify' => true,
				)
			);

			if ( is_wp_error( $response ) ) {
				return array(
					'success' => false,
					'error'   => $response->get_error_message(),
				);
			}

			$status_code = wp_remote_retrieve_response_code( $response );
			$image_data  = wp_remote_retrieve_body( $response );

			if ( 200 !== $status_code ) {
				$err_msg = 'Clipdrop API error HTTP ' . $status_code;
				$json    = json_decode( $image_data, true );

				if ( ! empty( $json['error'] ) ) {
					$err_msg .= ': ' . $json['error'];
				}

				return array(
					'success' => false,
					'error'   => $err_msg,
				);
			}

			if ( '' === trim( (string) $image_data ) ) {
				return array(
					'success' => false,
					'error'   => 'Clipdrop API returned an empty image response.',
				);
			}

			return array(
				'success'    => true,
				'image_data' => $image_data,
			);
		} finally {
			if ( $cleanup && file_exists( $api_file ) ) {
				@unlink( $api_file );
			}
		}
	}
}