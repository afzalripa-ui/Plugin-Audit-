<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BW_PIP_Provider_Removebg implements BW_PIP_Provider_Interface {

	private $api_key;

	public function __construct( $api_key ) {
		$this->api_key = trim( (string) $api_key );
	}

	public function process_image( $file_path, $prompt, $options = array() ) {
		if ( empty( $this->api_key ) ) {
			return array(
				'success' => false,
				'error'   => 'Remove.bg API Key is empty.',
			);
		}

		if ( '' === $file_path || ! is_file( $file_path ) || is_link( $file_path ) || ! is_readable( $file_path ) ) {
			return array(
				'success' => false,
				'error'   => 'Source image file does not exist or is not readable.',
			);
		}

		clearstatcache( true, $file_path );

		$file_size = (int) @filesize( $file_path );

		if ( $file_size <= 0 ) {
			return array(
				'success' => false,
				'error'   => 'Source image file is empty.',
			);
		}

		if ( $file_size > 12 * 1024 * 1024 ) {
			return array(
				'success' => false,
				'error'   => 'Source image is too large for Remove.bg upload.',
			);
		}

		$info = @getimagesize( $file_path );

		if ( ! $info || empty( $info[0] ) || empty( $info[1] ) ) {
			return array(
				'success' => false,
				'error'   => 'Source file is not a readable image.',
			);
		}

		$filetype  = wp_check_filetype( $file_path );
		$mime_type = ! empty( $filetype['type'] ) ? $filetype['type'] : 'image/jpeg';
		$filename  = wp_basename( $file_path );

		$file_contents = @file_get_contents( $file_path );

		if ( false === $file_contents ) {
			return array(
				'success' => false,
				'error'   => 'Could not read the source image file.',
			);
		}

		/*
		 * Try full resolution first - best quality, and the right choice
		 * whenever the account has credit for it. Remove.bg's monthly free
		 * allowance (50/month) only ever covers "preview" size; "full"
		 * always spends a paid credit regardless of that allowance, so an
		 * account with no paid/bonus credit left gets HTTP 402 here
		 * specifically - a clear, unambiguous signal, not "something is
		 * wrong". Only on that exact signal (never on other errors: bad
		 * key, network issue, corrupt image) retry once with size=auto,
		 * which uses the best resolution the account can actually afford
		 * right now - including that free monthly allowance - instead of
		 * failing the image outright.
		 */
		$result = $this->call_api( $file_contents, $filename, $mime_type, 'full' );

		if ( ! empty( $result['success'] ) ) {
			return $result;
		}

		if ( isset( $result['status_code'] ) && 402 === (int) $result['status_code'] ) {
			$retry = $this->call_api( $file_contents, $filename, $mime_type, 'auto' );

			if ( ! empty( $retry['success'] ) ) {
				$retry['downgraded'] = true;
			}

			return $retry;
		}

		return $result;
	}

	private function call_api( $file_contents, $filename, $mime_type, $size ) {
		$boundary = wp_generate_password( 24, false );

		$headers = array(
			'X-Api-Key'    => $this->api_key,
			'Content-Type' => 'multipart/form-data; boundary=' . $boundary,
			'Accept'       => 'image/png, application/json',
		);

		// Remove.bg is background removal only. It does not use the prompt field.
		$body  = '--' . $boundary . "\r\n";
		$body .= 'Content-Disposition: form-data; name="image_file"; filename="' . $filename . '"' . "\r\n";
		$body .= 'Content-Type: ' . $mime_type . "\r\n\r\n";
		$body .= $file_contents . "\r\n";

		$body .= '--' . $boundary . "\r\n";
		$body .= 'Content-Disposition: form-data; name="size"' . "\r\n\r\n";
		$body .= $size . "\r\n";

		$body .= '--' . $boundary . "--\r\n";

		$response = wp_remote_post(
			'https://api.remove.bg/v1.0/removebg',
			array(
				'method'    => 'POST',
				'timeout'   => 45,
				'headers'   => $headers,
				'body'      => $body,
				'sslverify' => true,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'error'   => $response->get_error_message(),
			);
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		$image_data  = wp_remote_retrieve_body( $response );

		if ( 200 !== $status_code ) {
			$err_msg = 'Remove.bg API error HTTP ' . $status_code;
			$json    = json_decode( $image_data, true );

			if ( ! empty( $json['errors'][0]['title'] ) ) {
				$err_msg .= ': ' . $json['errors'][0]['title'];
			}

			return array(
				'success'     => false,
				'error'       => $err_msg,
				'status_code' => $status_code,
			);
		}

		if ( '' === trim( (string) $image_data ) ) {
			return array(
				'success' => false,
				'error'   => 'Remove.bg API returned an empty image response.',
			);
		}

		return array(
			'success'    => true,
			'image_data' => $image_data,
			'size_used'  => $size,
		);
	}
}