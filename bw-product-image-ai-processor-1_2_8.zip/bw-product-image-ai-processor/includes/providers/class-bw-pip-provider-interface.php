<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface BW_PIP_Provider_Interface {

	/**
	 * Process image background via external AI API.
	 *
	 * @param string $file_path Local path to input image.
	 * @param string $prompt    Background generation prompt.
	 * @param array  $options   Extra parameters.
	 *
	 * @return array Array containing:
	 *               - success    bool
	 *               - image_data string binary
	 *               - error      string
	 */
	public function process_image( $file_path, $prompt, $options = array() );
}