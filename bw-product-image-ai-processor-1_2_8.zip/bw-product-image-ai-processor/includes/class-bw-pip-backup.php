<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BW_PIP_Backup {

	public static function init() {
		add_action( 'delete_attachment', array( __CLASS__, 'delete_backup' ) );
	}

	public static function normalize_path( $path ) {
		return wp_normalize_path( (string) $path );
	}

	private static function starts_with( $haystack, $needle ) {
		$haystack = (string) $haystack;
		$needle   = (string) $needle;

		return '' !== $needle && 0 === strpos( $haystack, $needle );
	}

	private static function is_under_dir( $path, $dir ) {
		$path = self::normalize_path( $path );
		$dir  = trailingslashit( self::normalize_path( $dir ) );

		return self::starts_with( $path, $dir );
	}

	private static function get_folder_salt() {
		$salt = get_option( 'bw_pip_backup_salt' );

		if ( ! is_string( $salt ) || ! preg_match( '/^[A-Za-z0-9]{24}$/', $salt ) ) {
			$salt = wp_generate_password( 24, false );
			update_option( 'bw_pip_backup_salt', $salt );
		}

		return $salt;
	}

	private static function get_default_backup_dir_path() {
		$upload_dir = wp_upload_dir();

		return $upload_dir['basedir'] . '/bw-image-backups-' . self::get_folder_salt();
	}

	private static function get_backup_dir_path() {
		$default = self::get_default_backup_dir_path();
		$dir     = apply_filters( 'bw_pip_backup_dir', $default );

		if ( empty( $dir ) ) {
			$dir = $default;
		}

		return self::normalize_path( $dir );
	}

	private static function update_stored_backup_dir( $dir ) {
		$stored = get_option( BW_PIP_Settings::BACKUP_DIR_OPTION, '' );

		if ( $stored !== $dir ) {
			delete_option( BW_PIP_Settings::BACKUP_DIR_OPTION );
			add_option( BW_PIP_Settings::BACKUP_DIR_OPTION, $dir, '', 'no' );
		}
	}

	private static function get_marker_file_path( $dir ) {
		return trailingslashit( self::normalize_path( $dir ) ) . '.bw-pip-backup-root';
	}

	private static function is_valid_backup_marker( $dir, $expected_salt = '' ) {
		$marker = self::get_marker_file_path( $dir );

		if ( ! file_exists( $marker ) || is_link( $marker ) || ! is_file( $marker ) || ! is_readable( $marker ) ) {
			return false;
		}

		$raw = @file_get_contents( $marker );

		if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
			return false;
		}

		$data = json_decode( $raw, true );

		if ( ! is_array( $data ) ) {
			return false;
		}

		if ( empty( $data['plugin'] ) || 'bw-product-image-ai-processor' !== $data['plugin'] ) {
			return false;
		}

		if ( empty( $data['salt'] ) || ! is_string( $data['salt'] ) ) {
			return false;
		}

		if ( '' === $expected_salt ) {
			$expected_salt = self::get_folder_salt();
		}

		if ( ! is_string( $expected_salt ) || ! preg_match( '/^[A-Za-z0-9]{24}$/', $expected_salt ) ) {
			return false;
		}

		return hash_equals( $expected_salt, $data['salt'] );
	}

	private static function write_backup_marker( $dir ) {
		$marker = self::get_marker_file_path( $dir );

		if ( file_exists( $marker ) ) {
			return self::is_valid_backup_marker( $dir );
		}

		$salt    = self::get_folder_salt();
		$content = wp_json_encode(
			array(
				'plugin'  => 'bw-product-image-ai-processor',
				'version' => BW_PIP_VERSION,
				'salt'    => $salt,
			)
		);

		return false !== @file_put_contents( $marker, $content );
	}

	public static function get_backup_dir() {
		$dir = self::get_backup_dir_path();

		if ( ! file_exists( $dir ) ) {
			$mkdir_ok = wp_mkdir_p( $dir );

			if ( ! $mkdir_ok && ! is_dir( $dir ) ) {
				error_log( 'BW_PIP_Backup: could not create backup directory: ' . $dir . ' - verify directory permissions.' );
			}
		}

		if ( is_dir( $dir ) ) {
			$htaccess = "# Protect Original Backups on Apache & LiteSpeed (Nginx requires a server-level rule - see docs)\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder deny,allow\nDeny from all\n</IfModule>\n";

			$htaccess_path = $dir . '/.htaccess';
			$index_path    = $dir . '/index.php';

			if ( ! file_exists( $htaccess_path ) ) {
				$htaccess_ok = @file_put_contents( $htaccess_path, $htaccess );

				if ( false === $htaccess_ok ) {
					error_log( 'BW_PIP_Backup: could not write protection file (.htaccess) to ' . $dir . ' - verify directory permissions.' );
				}
			}

			if ( ! file_exists( $index_path ) ) {
				$index_ok = @file_put_contents(
					$index_path,
					"<?php\n// Silence is golden.\nexit;\n"
				);

				if ( false === $index_ok ) {
					error_log( 'BW_PIP_Backup: could not write protection file (index.php) to ' . $dir . ' - verify directory permissions.' );
				}
			}

			self::write_backup_marker( $dir );
		}

		self::update_stored_backup_dir( $dir );

		return $dir;
	}

	/**
	 * Whether the backup directory sits inside the public uploads folder
	 * on a server that does not identify itself as Apache or LiteSpeed -
	 * the two server types the .htaccess protection in get_backup_dir()
	 * actually works on. Used only to decide whether to show an admin
	 * warning; never used to change where anything is read from or
	 * written to.
	 */
	public static function is_backup_dir_unverified_on_this_server() {
		$upload_dir = wp_upload_dir();

		if ( empty( $upload_dir['basedir'] ) ) {
			return false;
		}

		$backup_dir = self::get_backup_dir_path();
		$uploads    = trailingslashit( self::normalize_path( $upload_dir['basedir'] ) );

		if ( 0 !== strpos( $backup_dir, $uploads ) ) {
			return false;
		}

		$server_software = isset( $_SERVER['SERVER_SOFTWARE'] ) ? strtolower( (string) $_SERVER['SERVER_SOFTWARE'] ) : '';

		return false === strpos( $server_software, 'apache' ) && false === strpos( $server_software, 'litespeed' );
	}

	public static function is_safe_upload_path( $path ) {
		$path = self::normalize_path( $path );

		if ( '' === $path || is_link( $path ) ) {
			return false;
		}

		if ( function_exists( 'wp_is_stream' ) && wp_is_stream( $path ) ) {
			return false;
		}

		$upload_dir = wp_upload_dir();
		$real_base  = realpath( $upload_dir['basedir'] );

		if ( ! $real_base ) {
			return false;
		}

		$real_base = self::normalize_path( $real_base );

		if ( file_exists( $path ) ) {
			$real_path = realpath( $path );

			return $real_path && self::is_under_dir( self::normalize_path( $real_path ), $real_base );
		}

		$dir      = dirname( $path );
		$real_dir = realpath( $dir );

		if ( ! $real_dir ) {
			return false;
		}

		if ( ! self::is_under_dir( self::normalize_path( $real_dir ), $real_base ) ) {
			return false;
		}

		$basename = wp_basename( $path );

		return '' !== $basename && false === strpos( $basename, '..' );
	}

	private static function is_under_backup_dir( $path ) {
		$path       = self::normalize_path( $path );
		$backup_dir = self::get_backup_dir_path();

		if ( '' === $path || '' === $backup_dir ) {
			return false;
		}

		if ( self::starts_with( $path, trailingslashit( $backup_dir ) ) ) {
			return true;
		}

		$real_backup = realpath( $backup_dir );

		if ( ! $real_backup ) {
			return false;
		}

		$real = file_exists( $path ) ? realpath( $path ) : realpath( dirname( $path ) );

		return $real && self::is_under_dir( self::normalize_path( $real ), self::normalize_path( $real_backup ) );
	}

	public static function is_path_inside_backup_dir( $path ) {
		return self::is_under_backup_dir( $path );
	}

	public static function is_safe_restore_target_path( $path ) {
		if ( ! self::is_safe_upload_path( $path ) ) {
			return false;
		}

		if ( self::is_under_backup_dir( $path ) ) {
			return false;
		}

		if ( file_exists( $path ) && ( ! is_file( $path ) || is_link( $path ) || ! is_writable( $path ) ) ) {
			return false;
		}

		return true;
	}

	private static function is_allowed_image_mime( $mime ) {
		$mime = sanitize_mime_type( (string) $mime );

		return '' !== $mime && 0 === strpos( $mime, 'image/' );
	}

	private static function is_allowed_image_file( $real_file, $attachment_id ) {
		$post_mime = get_post_mime_type( $attachment_id );

		if ( self::is_allowed_image_mime( $post_mime ) ) {
			return true;
		}

		$info = @getimagesize( $real_file );

		if ( ! $info || empty( $info[2] ) ) {
			return false;
		}

		return in_array(
			(int) $info[2],
			array( IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP, IMAGETYPE_GIF ),
			true
		);
	}

	public static function get_file_hash( $path ) {
		if ( '' === $path || ! is_file( $path ) || is_link( $path ) || ! is_readable( $path ) ) {
			return '';
		}

		if ( function_exists( 'hash_file' ) ) {
			$hash = @hash_file( 'sha256', $path );

			if ( is_string( $hash ) && '' !== $hash ) {
				return strtolower( $hash );
			}
		}

		$hash = @md5_file( $path );

		return is_string( $hash ) ? strtolower( $hash ) : '';
	}

	public static function is_valid_backup_path( $path, $attachment_id ) {
		$path          = self::normalize_path( $path );
		$attachment_id = absint( $attachment_id );

		if ( '' === $path || ! $attachment_id || ! is_file( $path ) || is_link( $path ) ) {
			return false;
		}

		$backup_dir = self::get_backup_dir_path();
		$real_dir   = realpath( $backup_dir );
		$real_path  = realpath( $path );

		if ( ! $real_dir || ! $real_path ) {
			return false;
		}

		if ( ! self::is_under_dir( self::normalize_path( $real_path ), self::normalize_path( $real_dir ) ) ) {
			return false;
		}

		$filename = wp_basename( $real_path );

		return (bool) preg_match( '/^' . $attachment_id . '_[a-f0-9]{32}\.bin$/i', $filename );
	}

	public static function has_valid_backup( $attachment_id ) {
		$backup_path = get_post_meta( $attachment_id, '_bw_pip_backup_path', true );

		return ! empty( $backup_path )
			&& self::is_valid_backup_path( $backup_path, $attachment_id )
			&& file_exists( $backup_path )
			&& is_readable( $backup_path );
	}

	private static function backup_dir_ready( $dir ) {
		return is_dir( $dir )
			&& is_writable( $dir )
			&& file_exists( $dir . '/.htaccess' )
			&& file_exists( $dir . '/index.php' )
			&& self::is_valid_backup_marker( $dir );
	}

	public static function create_backup( $attachment_id, $file_path ) {
		$attachment_id = absint( $attachment_id );

		if ( ! $attachment_id || 'attachment' !== get_post_type( $attachment_id ) ) {
			return false;
		}

		$existing_backup = get_post_meta( $attachment_id, '_bw_pip_backup_path', true );

		if ( ! empty( $existing_backup ) && self::is_valid_backup_path( $existing_backup, $attachment_id ) ) {
			clearstatcache( true, $existing_backup );

			if ( file_exists( $existing_backup ) && (int) @filesize( $existing_backup ) > 0 ) {
				$stored_hash   = get_post_meta( $attachment_id, '_bw_pip_backup_hash', true );
				$existing_hash = self::get_file_hash( $existing_backup );

				if ( '' === $stored_hash || ( '' !== $existing_hash && hash_equals( $stored_hash, $existing_hash ) ) ) {
					return $existing_backup;
				}
			}
		}

		if ( empty( $file_path ) || is_link( $file_path ) || ! is_file( $file_path ) || ! is_readable( $file_path ) ) {
			return false;
		}

		$file_path = self::normalize_path( $file_path );

		if ( ! self::is_safe_upload_path( $file_path ) ) {
			return false;
		}

		$real_file = realpath( $file_path );

		if ( ! $real_file || ! self::is_allowed_image_file( $real_file, $attachment_id ) ) {
			return false;
		}

		$real_file = self::normalize_path( $real_file );

		clearstatcache( true, $real_file );

		if ( (int) @filesize( $real_file ) <= 0 ) {
			return false;
		}

		$backup_dir = self::get_backup_dir();

		if ( ! self::backup_dir_ready( $backup_dir ) ) {
			return false;
		}

		$file_hash = wp_hash( $attachment_id . '_' . $real_file . '_' . wp_salt() );
		$target    = $backup_dir . '/' . $attachment_id . '_' . $file_hash . '.bin';

		if ( file_exists( $target ) ) {
			if ( ! is_file( $target ) || is_link( $target ) ) {
				return false;
			}

			@unlink( $target );
		}

		$source_hash = self::get_file_hash( $real_file );

		if ( '' === $source_hash ) {
			return false;
		}

		$tmp = tempnam( $backup_dir, 'bw-pip-backup-' );

		if ( ! $tmp ) {
			return false;
		}

		if ( ! copy( $real_file, $tmp ) ) {
			@unlink( $tmp );
			return false;
		}

		clearstatcache( true, $tmp );

		if ( ! file_exists( $tmp ) || (int) @filesize( $tmp ) <= 0 ) {
			@unlink( $tmp );
			return false;
		}

		$tmp_hash = self::get_file_hash( $tmp );

		if ( '' === $tmp_hash || ! hash_equals( $source_hash, $tmp_hash ) ) {
			@unlink( $tmp );
			return false;
		}

		if ( file_exists( $target ) ) {
			if ( ! is_file( $target ) || is_link( $target ) ) {
				@unlink( $tmp );
				return false;
			}

			@unlink( $target );
		}

		if ( ! rename( $tmp, $target ) ) {
			@unlink( $tmp );
			return false;
		}

		clearstatcache( true, $target );

		if ( ! file_exists( $target ) || (int) @filesize( $target ) <= 0 ) {
			return false;
		}

		$final_hash = self::get_file_hash( $target );

		if ( '' === $final_hash || ! hash_equals( $source_hash, $final_hash ) ) {
			@unlink( $target );
			return false;
		}

		update_post_meta( $attachment_id, '_bw_pip_backup_path', $target );
		update_post_meta( $attachment_id, '_bw_pip_original_file', $file_path );
		update_post_meta( $attachment_id, '_bw_pip_original_mime', get_post_mime_type( $attachment_id ) );
		update_post_meta( $attachment_id, '_bw_pip_backup_hash', $source_hash );

		return $target;
	}

	public static function restore_backup( $attachment_id ) {
		$attachment_id = absint( $attachment_id );

		if ( ! $attachment_id || 'attachment' !== get_post_type( $attachment_id ) ) {
			return new WP_Error( 'invalid_attachment', __( 'Invalid attachment.', 'bw-product-image-ai-processor' ) );
		}

		if ( ! self::has_valid_backup( $attachment_id ) ) {
			return new WP_Error( 'no_backup', __( 'Original backup file not found on disk.', 'bw-product-image-ai-processor' ) );
		}

		$backup_path  = get_post_meta( $attachment_id, '_bw_pip_backup_path', true );
		$current_file = self::normalize_path( get_attached_file( $attachment_id ) );
		$target       = get_post_meta( $attachment_id, '_bw_pip_original_file', true );

		if ( empty( $target ) ) {
			$target = $current_file;
		}

		$target = self::normalize_path( $target );

		if ( '' === $target || ! self::is_safe_restore_target_path( $target ) ) {
			return new WP_Error( 'invalid_restore_target', __( 'Restore target path is invalid or unsafe.', 'bw-product-image-ai-processor' ) );
		}

		$target_dir = dirname( $target );

		if ( ! is_dir( $target_dir ) || ! is_writable( $target_dir ) ) {
			return new WP_Error( 'restore_target_dir_unwritable', __( 'Restore target directory is not writable.', 'bw-product-image-ai-processor' ) );
		}

		if ( file_exists( $target ) && ( ! is_file( $target ) || is_link( $target ) || ! is_writable( $target ) ) ) {
			return new WP_Error( 'restore_target_unwritable', __( 'Restore target file is not writable.', 'bw-product-image-ai-processor' ) );
		}

		clearstatcache( true, $backup_path );

		$backup_size = (int) @filesize( $backup_path );

		if ( $backup_size <= 0 ) {
			return new WP_Error( 'restore_backup_invalid', __( 'The original backup file is empty or invalid.', 'bw-product-image-ai-processor' ) );
		}

		$stored_hash = get_post_meta( $attachment_id, '_bw_pip_backup_hash', true );

		if ( ! empty( $stored_hash ) ) {
			$backup_hash = self::get_file_hash( $backup_path );

			if ( '' === $backup_hash || ! hash_equals( $stored_hash, $backup_hash ) ) {
				return new WP_Error( 'restore_hash_mismatch', __( 'Backup integrity verification failed.', 'bw-product-image-ai-processor' ) );
			}
		}

		$tmp = tempnam( $target_dir, 'bw-pip-restore-' );

		if ( ! $tmp ) {
			return new WP_Error( 'restore_tmp_failed', __( 'Could not create temporary restore file.', 'bw-product-image-ai-processor' ) );
		}

		if ( ! copy( $backup_path, $tmp ) ) {
			@unlink( $tmp );

			return new WP_Error( 'restore_copy_failed', __( 'Could not copy backup file.', 'bw-product-image-ai-processor' ) );
		}

		clearstatcache( true, $tmp );

		if ( ! file_exists( $tmp ) || (int) @filesize( $tmp ) !== $backup_size ) {
			@unlink( $tmp );

			return new WP_Error( 'restore_copy_invalid', __( 'Temporary restore copy failed verification.', 'bw-product-image-ai-processor' ) );
		}

		if ( ! empty( $stored_hash ) ) {
			$tmp_hash = self::get_file_hash( $tmp );

			if ( '' === $tmp_hash || ! hash_equals( $stored_hash, $tmp_hash ) ) {
				@unlink( $tmp );

				return new WP_Error( 'restore_tmp_hash_mismatch', __( 'Temporary restore copy failed integrity verification.', 'bw-product-image-ai-processor' ) );
			}
		}

		if ( ! rename( $tmp, $target ) ) {
			@unlink( $tmp );

			return new WP_Error( 'restore_finalize_failed', __( 'Could not finalize restored file.', 'bw-product-image-ai-processor' ) );
		}

		clearstatcache( true, $target );

		if ( ! file_exists( $target ) || (int) @filesize( $target ) !== $backup_size ) {
			return new WP_Error( 'restore_final_invalid', __( 'Restored file failed final verification.', 'bw-product-image-ai-processor' ) );
		}

		if (
			'' !== $current_file
			&& $current_file !== $target
			&& self::is_safe_upload_path( $current_file )
			&& ! self::is_under_backup_dir( $current_file )
			&& file_exists( $current_file )
			&& is_file( $current_file )
			&& ! is_link( $current_file )
		) {
			@unlink( $current_file );
		}

		$meta = wp_get_attachment_metadata( $attachment_id );

		if ( ! empty( $meta['sizes'] ) && is_array( $meta['sizes'] ) ) {
			$thumb_base_dir = dirname( $current_file );

			if ( '' === $current_file || ! self::is_safe_upload_path( $thumb_base_dir ) ) {
				$thumb_base_dir = dirname( $target );
			}

			foreach ( $meta['sizes'] as $size ) {
				if ( empty( $size['file'] ) ) {
					continue;
				}

				$thumb_name = wp_basename( $size['file'] );

				if ( '' === $thumb_name || false !== strpos( $thumb_name, '..' ) ) {
					continue;
				}

				$thumb_file = $thumb_base_dir . '/' . $thumb_name;

				if (
					self::is_safe_upload_path( $thumb_file )
					&& ! self::is_under_backup_dir( $thumb_file )
					&& file_exists( $thumb_file )
					&& is_file( $thumb_file )
					&& ! is_link( $thumb_file )
				) {
					@unlink( $thumb_file );
				}
			}
		}

		update_attached_file( $attachment_id, $target );

		$original_mime = sanitize_mime_type( get_post_meta( $attachment_id, '_bw_pip_original_mime', true ) );

		if ( self::is_allowed_image_mime( $original_mime ) ) {
			wp_update_post(
				array(
					'ID'             => $attachment_id,
					'post_mime_type' => $original_mime,
				)
			);
		}

		remove_filter( 'wp_generate_attachment_metadata', array( 'BW_PIP_Processor', 'on_generate_metadata_enqueue' ), 10 );

		require_once ABSPATH . 'wp-admin/includes/image.php';

		$metadata = wp_generate_attachment_metadata( $attachment_id, $target );

		if ( is_array( $metadata ) ) {
			wp_update_attachment_metadata( $attachment_id, $metadata );
		} else {
			wp_update_attachment_metadata( $attachment_id, array() );
		}

		add_filter( 'wp_generate_attachment_metadata', array( 'BW_PIP_Processor', 'on_generate_metadata_enqueue' ), 10, 2 );

		update_post_meta( $attachment_id, '_bw_pip_status', 'restored' );
		update_post_meta( $attachment_id, '_bw_pip_log', __( 'Restored to original image.', 'bw-product-image-ai-processor' ) );

		return true;
	}

	public static function delete_backup( $attachment_id ) {
		$attachment_id = absint( $attachment_id );

		if ( ! $attachment_id || 'attachment' !== get_post_type( $attachment_id ) ) {
			return;
		}

		$backup_path = get_post_meta( $attachment_id, '_bw_pip_backup_path', true );

		if (
			! empty( $backup_path )
			&& self::is_valid_backup_path( $backup_path, $attachment_id )
			&& file_exists( $backup_path )
			&& is_file( $backup_path )
			&& ! is_link( $backup_path )
		) {
			@unlink( $backup_path );
		}
	}

	/**
	 * Lists every valid "<id>_<hash>.bin" backup file directly inside the
	 * verified backup directory. Shared by get_backup_dir_stats(),
	 * get_all_backups_for_export() and delete_all_backups() so the
	 * scan/validation logic lives in exactly one place.
	 *
	 * @return array<string,int> absolute file path => file size in bytes
	 */
	private static function list_backup_files() {
		$dir = self::get_backup_dir_path();

		$files = array();

		if ( '' === $dir || ! is_dir( $dir ) ) {
			return $files;
		}

		$real_dir = realpath( $dir );

		if ( ! $real_dir || ! self::is_valid_backup_marker( $real_dir ) ) {
			return $files;
		}

		$items = @scandir( $real_dir );

		if ( ! is_array( $items ) ) {
			return $files;
		}

		foreach ( $items as $item ) {
			if ( ! preg_match( '/^\d+_[a-f0-9]{32}\.bin$/i', $item ) ) {
				continue;
			}

			$path = trailingslashit( $real_dir ) . $item;

			if ( is_file( $path ) && ! is_link( $path ) ) {
				$files[ $path ] = max( 0, (int) @filesize( $path ) );
			}
		}

		return $files;
	}

	/**
	 * Lightweight count/size of the current backup directory, for display
	 * on the Settings page so an admin can see whether backups are worth
	 * downloading/clearing before doing either.
	 *
	 * @return array{file_count:int, total_bytes:int, dir:string}
	 */
	public static function get_backup_dir_stats() {
		$files = self::list_backup_files();

		return array(
			'file_count'  => count( $files ),
			'total_bytes' => array_sum( $files ),
			'dir'         => self::get_backup_dir_path(),
		);
	}

	private static function extension_from_mime( $mime ) {
		switch ( sanitize_mime_type( (string) $mime ) ) {
			case 'image/jpeg':
				return '.jpg';
			case 'image/png':
				return '.png';
			case 'image/webp':
				return '.webp';
			case 'image/gif':
				return '.gif';
			default:
				return '.bin';
		}
	}

	/**
	 * Backup files are stored on disk as an opaque "<id>_<hash>.bin" name,
	 * which is meaningless outside this plugin. For the "Download All
	 * Backups" ZIP, this builds a human-readable name per file instead -
	 * the attachment's title and its original file extension where known -
	 * so what an admin downloads to keep elsewhere is actually usable,
	 * not a folder of unlabeled .bin files.
	 *
	 * @return array<int,array{path:string, zip_name:string}>
	 */
	public static function get_all_backups_for_export() {
		$files  = self::list_backup_files();
		$export = array();
		$used   = array();

		foreach ( $files as $path => $size ) {
			$filename      = wp_basename( $path );
			$attachment_id = 0;

			if ( preg_match( '/^(\d+)_[a-f0-9]{32}\.bin$/i', $filename, $m ) ) {
				$attachment_id = absint( $m[1] );
			}

			$zip_name = $filename;

			if ( $attachment_id ) {
				$ext   = self::extension_from_mime( get_post_meta( $attachment_id, '_bw_pip_original_mime', true ) );
				$title = sanitize_file_name( (string) get_the_title( $attachment_id ) );

				if ( '' === $title ) {
					$original = get_post_meta( $attachment_id, '_bw_pip_original_file', true );
					$title    = $original ? sanitize_file_name( pathinfo( $original, PATHINFO_FILENAME ) ) : ( 'image-' . $attachment_id );
				}

				$zip_name = $attachment_id . '-' . $title . $ext;
			}

			// Guard against two attachments producing the same friendly name.
			$base = $zip_name;
			$i    = 2;

			while ( isset( $used[ $zip_name ] ) ) {
				$zip_name = preg_replace( '/(\.[a-z0-9]+)?$/i', '-' . $i . '$1', $base, 1 );
				++$i;
			}

			$used[ $zip_name ] = true;

			$export[] = array(
				'path'     => $path,
				'zip_name' => $zip_name,
			);
		}

		return $export;
	}

	/**
	 * Deletes every backup file in the backup directory and clears
	 * backup-related postmeta from every attachment that has it, so
	 * has_valid_backup() (and the "Restore Original" button it controls)
	 * correctly reflect that no backups remain. This is an explicit,
	 * confirmed, admin-triggered bulk action - never run automatically.
	 *
	 * @return array{deleted_files:int, cleared_attachments:int, bytes_freed:int}
	 */
	public static function delete_all_backups() {
		$files = self::list_backup_files();

		$deleted_files = 0;
		$bytes_freed   = 0;

		foreach ( $files as $path => $size ) {
			if ( @unlink( $path ) ) {
				++$deleted_files;
				$bytes_freed += $size;
			}
		}

		$cleared_attachments = 0;

		$attachment_ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array(
					array(
						'key'     => '_bw_pip_backup_path',
						'compare' => 'EXISTS',
					),
				),
			)
		);

		foreach ( $attachment_ids as $attachment_id ) {
			delete_post_meta( $attachment_id, '_bw_pip_backup_path' );
			delete_post_meta( $attachment_id, '_bw_pip_backup_hash' );
			delete_post_meta( $attachment_id, '_bw_pip_original_file' );
			delete_post_meta( $attachment_id, '_bw_pip_original_mime' );
			++$cleared_attachments;
		}

		return array(
			'deleted_files'       => $deleted_files,
			'cleared_attachments' => $cleared_attachments,
			'bytes_freed'         => $bytes_freed,
		);
	}
}