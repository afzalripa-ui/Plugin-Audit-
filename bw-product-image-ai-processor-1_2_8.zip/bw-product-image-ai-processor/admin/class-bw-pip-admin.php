<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BW_PIP_Admin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_filter( 'manage_media_columns', array( __CLASS__, 'add_media_columns' ) );
		add_action( 'manage_media_custom_column', array( __CLASS__, 'render_media_columns' ), 10, 2 );
		add_filter( 'attachment_fields_to_edit', array( __CLASS__, 'add_attachment_fields' ), 10, 2 );
		add_action( 'wp_ajax_bw_pip_manual_process', array( __CLASS__, 'ajax_manual_process' ) );
		add_action( 'wp_ajax_bw_pip_restore_backup', array( __CLASS__, 'ajax_restore_backup' ) );
		add_action( 'wp_ajax_bw_pip_delete_all_backups', array( __CLASS__, 'ajax_delete_all_backups' ) );
		add_action( 'admin_post_bw_pip_download_all_backups', array( __CLASS__, 'handle_download_all_backups' ) );
		add_action( 'admin_post_bw_pip_save_api_key', array( __CLASS__, 'handle_api_key_save' ) );
		add_action( 'admin_notices', array( __CLASS__, 'maybe_render_backup_protection_notice' ) );
	}

	private static function menu_capability() {
		return BW_PIP_Settings::settings_capability();
	}

	private static function user_can_manage_image( $attachment_id ) {
		$attachment_id = absint( $attachment_id );

		if ( ! $attachment_id || ! current_user_can( 'edit_post', $attachment_id ) ) {
			return false;
		}

		return current_user_can( 'manage_options' ) || current_user_can( self::menu_capability() );
	}

	public static function add_admin_menu() {
		$capability = self::menu_capability();

		add_menu_page(
			__( 'Bongo World Image Processor', 'bw-product-image-ai-processor' ),
			__( 'Bongo World', 'bw-product-image-ai-processor' ),
			$capability,
			'bongo-world-settings',
			array( __CLASS__, 'render_settings_page' ),
			'dashicons-camera-alt',
			58
		);

		add_submenu_page(
			'bongo-world-settings',
			__( 'Image Processor Settings', 'bw-product-image-ai-processor' ),
			__( 'Image Processor', 'bw-product-image-ai-processor' ),
			$capability,
			'bongo-world-settings',
			array( __CLASS__, 'render_settings_page' )
		);
	}

	public static function enqueue_assets( $hook ) {
		$allowed_hooks = array(
			'toplevel_page_bongo-world-settings',
			'upload.php',
			'post.php',
			'post-new.php',
		);

		if ( ! in_array( $hook, $allowed_hooks, true ) ) {
			return;
		}

		if ( in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

			if ( ! $screen || empty( $screen->post_type ) || 'product' !== $screen->post_type ) {
				return;
			}
		}

		wp_enqueue_style( 'bw-pip-admin-css', BW_PIP_PLUGIN_URL . 'admin/assets/css/admin.css', array(), BW_PIP_VERSION );
		wp_enqueue_script( 'bw-pip-admin-js', BW_PIP_PLUGIN_URL . 'admin/assets/js/admin.js', array( 'jquery' ), BW_PIP_VERSION, true );

		wp_localize_script(
			'bw-pip-admin-js',
			'bwPipAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'bw_pip_admin_nonce' ),
				'i18n'    => array(
					'processing' => __( 'Processing...', 'bw-product-image-ai-processor' ),
					'restoring'  => __( 'Restoring original...', 'bw-product-image-ai-processor' ),
					'success'    => __( 'Success!', 'bw-product-image-ai-processor' ),
					'failed'     => __( 'Action failed. Check logs.', 'bw-product-image-ai-processor' ),
				),
			)
		);
	}

	public static function render_settings_page() {
		if ( ! current_user_can( self::menu_capability() ) && ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'bw-product-image-ai-processor' ) );
		}

		include BW_PIP_PLUGIN_DIR . 'admin/views/settings-page.php';
	}

	public static function maybe_render_backup_protection_notice() {
		if ( ! current_user_can( self::menu_capability() ) ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( $screen && 'toplevel_page_bongo-world-settings' === $screen->id ) {
			return;
		}

		if ( ! BW_PIP_Backup::is_backup_dir_unverified_on_this_server() ) {
			return;
		}

		echo '<div class="notice notice-warning is-dismissible"><p>' .
			esc_html__( 'BW Product Image AI Processor: your original image backups are stored inside the public uploads folder and this server does not identify itself as Apache or LiteSpeed, so the .htaccess protection may not apply here. See the Bongo World settings page for details and an Nginx rule you can add.', 'bw-product-image-ai-processor' ) .
			'</p></div>';
	}

	public static function add_media_columns( $columns ) {
		$columns['bw_pip_status'] = __( 'BW Image Status', 'bw-product-image-ai-processor' );

		return $columns;
	}

	public static function render_media_columns( $column_name, $post_id ) {
		if ( 'bw_pip_status' !== $column_name ) {
			return;
		}

		$status   = get_post_meta( $post_id, '_bw_pip_status', true );
		$log      = get_post_meta( $post_id, '_bw_pip_log', true );
		$filesize = get_post_meta( $post_id, '_bw_pip_filesize', true );

		if ( empty( $status ) ) {
			$status = 'unprocessed';
		}

		$badge_class = 'bw-badge-' . esc_attr( $status );

		echo '<div class="bw-status-wrap" id="bw-status-' . esc_attr( $post_id ) . '">';
		echo '<span class="bw-badge ' . esc_attr( $badge_class ) . '">' . esc_html( ucfirst( $status ) ) . '</span>';

		if ( ! empty( $filesize ) ) {
			echo '<div class="bw-filesize-info">' . esc_html( $filesize ) . '</div>';
		}

		if ( ! empty( $log ) ) {
			echo '<div class="bw-log-info" title="' . esc_attr( $log ) . '">' . esc_html( wp_trim_words( $log, 5 ) ) . '</div>';
		}

		echo '<div class="bw-action-links">';
		echo '<button type="button" class="button button-small bw-btn-process" data-id="' . esc_attr( $post_id ) . '">' . esc_html__( 'Process Now', 'bw-product-image-ai-processor' ) . '</button> ';

		if ( BW_PIP_Backup::has_valid_backup( $post_id ) ) {
			echo '<button type="button" class="button button-small bw-btn-restore" data-id="' . esc_attr( $post_id ) . '">' . esc_html__( 'Restore Original', 'bw-product-image-ai-processor' ) . '</button>';
		}

		echo '</div>';
		echo '</div>';
	}

	public static function add_attachment_fields( $form_fields, $post ) {
		$status = get_post_meta( $post->ID, '_bw_pip_status', true );
		$log    = get_post_meta( $post->ID, '_bw_pip_log', true );

		if ( empty( $status ) ) {
			$status = 'unprocessed';
		}

		$html  = '<div class="bw-attachment-panel">';
		$html .= '<p><strong>' . esc_html__( 'Status:', 'bw-product-image-ai-processor' ) . '</strong> ' . esc_html( ucfirst( $status ) ) . '</p>';

		if ( ! empty( $log ) ) {
			$html .= '<p class="description">' . esc_html( $log ) . '</p>';
		}

		$html .= '<button type="button" class="button bw-btn-process" data-id="' . esc_attr( $post->ID ) . '">' . esc_html__( 'Process with BW Image Processor', 'bw-product-image-ai-processor' ) . '</button> ';

		if ( BW_PIP_Backup::has_valid_backup( $post->ID ) ) {
			$html .= '<button type="button" class="button bw-btn-restore" data-id="' . esc_attr( $post->ID ) . '">' . esc_html__( 'Restore Original', 'bw-product-image-ai-processor' ) . '</button>';
		}

		$html .= '</div>';

		$form_fields['bw_pip_status_box'] = array(
			'label' => __( 'BW AI Processor', 'bw-product-image-ai-processor' ),
			'input' => 'html',
			'html'  => $html,
		);

		return $form_fields;
	}

	public static function ajax_manual_process() {
		check_ajax_referer( 'bw_pip_admin_nonce', 'nonce' );

		$attachment_id = ! empty( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;

		if ( ! $attachment_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid attachment ID.', 'bw-product-image-ai-processor' ) ) );
		}

		if ( ! self::user_can_manage_image( $attachment_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check: You do not have permission to process this image.', 'bw-product-image-ai-processor' ) ) );
		}

		/*
		 * Routed through the same background queue used for automatic
		 * processing instead of calling BW_PIP_Processor::process_attachment()
		 * directly inside this AJAX request. A manual trigger can invoke an
		 * AI provider call that takes up to ~50 seconds; running that
		 * synchronously here risked the request being aborted by the PHP or
		 * host execution-time limit (commonly 30s on shared hosting) before
		 * it could finish, with no clear error shown to the admin.
		 */
		BW_PIP_Queue::schedule_image( $attachment_id );

		$status = get_post_meta( $attachment_id, '_bw_pip_status', true );

		if ( 'failed' === $status ) {
			$log = get_post_meta( $attachment_id, '_bw_pip_log', true );

			wp_send_json_error(
				array(
					'message' => ! empty( $log ) ? $log : __( 'Could not queue this image for processing.', 'bw-product-image-ai-processor' ),
				)
			);
		}

		wp_send_json_success(
			array(
				'message' => __( 'Queued for background processing. Refresh this page in a few seconds to see the result.', 'bw-product-image-ai-processor' ),
				'status'  => 'pending',
			)
		);
	}

	public static function ajax_restore_backup() {
		check_ajax_referer( 'bw_pip_admin_nonce', 'nonce' );

		$attachment_id = ! empty( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;

		if ( ! $attachment_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid attachment ID.', 'bw-product-image-ai-processor' ) ) );
		}

		if ( ! self::user_can_manage_image( $attachment_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check: You do not have permission to restore this image.', 'bw-product-image-ai-processor' ) ) );
		}

		$result = BW_PIP_Backup::restore_backup( $attachment_id );

		if ( true === $result ) {
			wp_send_json_success(
				array(
					'message' => __( 'Original image restored successfully.', 'bw-product-image-ai-processor' ),
					'status'  => 'restored',
				)
			);
		}

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_error( array( 'message' => __( 'Restore failed.', 'bw-product-image-ai-processor' ) ) );
	}

	public static function ajax_delete_all_backups() {
		check_ajax_referer( 'bw_pip_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check: You do not have permission to delete backups.', 'bw-product-image-ai-processor' ) ) );
		}

		$result = BW_PIP_Backup::delete_all_backups();

		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: 1: number of files deleted, 2: freed space, e.g. "12.3 MB" */
					__( 'Deleted %1$d backup file(s), freeing %2$s.', 'bw-product-image-ai-processor' ),
					(int) $result['deleted_files'],
					size_format( (int) $result['bytes_freed'] )
				),
			)
		);
	}

	public static function handle_download_all_backups() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to download backups.', 'bw-product-image-ai-processor' ) );
		}

		check_admin_referer( 'bw_pip_download_all_backups' );

		if ( ! class_exists( 'ZipArchive' ) ) {
			wp_die( esc_html__( 'The PHP ZipArchive extension is not available on this server, so backups cannot be zipped here. Download the backup folder directly via FTP or your host\'s File Manager instead - its path is shown further up this page.', 'bw-product-image-ai-processor' ) );
		}

		$files = BW_PIP_Backup::get_all_backups_for_export();

		if ( empty( $files ) ) {
			wp_die( esc_html__( 'There are no backup files to download right now.', 'bw-product-image-ai-processor' ) );
		}

		$zip_path = wp_tempnam( 'bw-pip-backups' );

		// wp_tempnam() creates the file with a generic extension; start from
		// a clean, unused path with our own .zip suffix instead of reusing it.
		if ( $zip_path ) {
			@unlink( $zip_path );
		}

		$zip_path .= '.zip';

		$zip = new ZipArchive();

		if ( true !== $zip->open( $zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			wp_die( esc_html__( 'Could not create the ZIP archive on this server.', 'bw-product-image-ai-processor' ) );
		}

		foreach ( $files as $file ) {
			$zip->addFile( $file['path'], $file['zip_name'] );
		}

		$zip->close();

		clearstatcache( true, $zip_path );

		if ( ! file_exists( $zip_path ) || (int) @filesize( $zip_path ) <= 0 ) {
			wp_die( esc_html__( 'The ZIP archive could not be built.', 'bw-product-image-ai-processor' ) );
		}

		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="bw-image-backups-' . gmdate( 'Y-m-d' ) . '.zip"' );
		header( 'Content-Length: ' . (string) filesize( $zip_path ) );

		readfile( $zip_path ); // phpcs:ignore

		@unlink( $zip_path );
		exit;
	}

	public static function handle_api_key_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage API keys.', 'bw-product-image-ai-processor' ) );
		}

		check_admin_referer( 'bw_pip_save_api_key' );

		$redirect = admin_url( 'admin.php?page=bongo-world-settings' );

		if ( defined( 'BW_PIP_API_KEY' ) && '' !== trim( (string) constant( 'BW_PIP_API_KEY' ) ) ) {
			wp_safe_redirect( add_query_arg( 'bw_api_notice', 'constant', $redirect ) );
			exit;
		}

		if ( ! empty( $_POST['bw_clear_api_key'] ) ) {
			BW_PIP_Settings::clear_api_key();

			wp_safe_redirect( add_query_arg( 'bw_api_notice', 'cleared', $redirect ) );
			exit;
		}

		$key = isset( $_POST['bw_api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['bw_api_key'] ) ) : '';

		if ( '' !== $key ) {
			BW_PIP_Settings::set_api_key( $key );

			wp_safe_redirect( add_query_arg( 'bw_api_notice', 'updated', $redirect ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'bw_api_notice', 'unchanged', $redirect ) );
		exit;
	}
}