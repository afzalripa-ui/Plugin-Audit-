/**
 * Bongo World Image Processor Admin Scripts
 */
(function($) {
	'use strict';

	$(document).ready(function() {

		// Manual Process Image Click Handler
		$(document).on('click', '.bw-btn-process', function(e) {
			e.preventDefault();

			var $btn = $(this);
			var attachmentId = $btn.data('id');
			var originalText = $btn.text();

			if (!attachmentId || $btn.prop('disabled')) {
				return;
			}

			$btn.prop('disabled', true).text(bwPipAdmin.i18n.processing);

			$.ajax({
				url: bwPipAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'bw_pip_manual_process',
					attachment_id: attachmentId,
					nonce: bwPipAdmin.nonce
				},
				success: function(response) {
					if (response.success) {
						// The server now queues this for background processing
						// rather than finishing it inline, so the result is not
						// ready yet - do not reload or claim it is "Completed".
						alert(response.data.message || bwPipAdmin.i18n.success);
						$btn.prop('disabled', false).text(originalText);

						var $panel = $btn.closest('.bw-attachment-panel');

						if ($panel.length) {
							$panel.find('strong').parent().html('<strong>Status:</strong> Queued');
						}

						// Media Library list/grid column uses a different wrapper
						// than the single-attachment edit panel above - update its
						// badge too so both locations reflect "Queued" right away.
						var $statusWrap = $btn.closest('.bw-status-wrap');

						if ($statusWrap.length) {
							$statusWrap.find('.bw-badge')
								.attr('class', 'bw-badge bw-badge-processing')
								.text('Queued');
						}
					} else {
						alert(response.data.message || bwPipAdmin.i18n.failed);
						$btn.prop('disabled', false).text(originalText);
					}
				},
				error: function() {
					alert(bwPipAdmin.i18n.failed);
					$btn.prop('disabled', false).text(originalText);
				}
			});
		});

		// Restore Backup Click Handler
		$(document).on('click', '.bw-btn-restore', function(e) {
			e.preventDefault();

			if (!confirm('Are you sure you want to restore the original uploaded image?')) {
				return;
			}

			var $btn = $(this);
			var attachmentId = $btn.data('id');
			var originalText = $btn.text();

			if (!attachmentId || $btn.prop('disabled')) {
				return;
			}

			$btn.prop('disabled', true).text(bwPipAdmin.i18n.restoring);

			$.ajax({
				url: bwPipAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'bw_pip_restore_backup',
					attachment_id: attachmentId,
					nonce: bwPipAdmin.nonce
				},
				success: function(response) {
					if (response.success) {
						alert(response.data.message || bwPipAdmin.i18n.success);

						if (window.location.href.indexOf('upload.php') !== -1) {
							window.location.reload();
						} else {
							$btn.prop('disabled', false).text(originalText);

							var $statusBox = $btn.closest('.bw-attachment-panel');

							if ($statusBox.length) {
								$statusBox.find('strong').parent().html('<strong>Status:</strong> Restored');
							}
						}
					} else {
						alert(response.data.message || bwPipAdmin.i18n.failed);
						$btn.prop('disabled', false).text(originalText);
					}
				},
				error: function() {
					alert(bwPipAdmin.i18n.failed);
					$btn.prop('disabled', false).text(originalText);
				}
			});
		});

		// Delete All Backups Click Handler (Settings page)
		$(document).on('click', '#bw-delete-all-backups', function(e) {
			e.preventDefault();

			if (!confirm('Delete ALL original-image backups now? This cannot be undone here - make sure you have downloaded a copy first if you want to keep one.')) {
				return;
			}

			var $btn = $(this);
			var originalText = $btn.text();
			var $result = $('#bw-delete-all-backups-result');

			if ($btn.prop('disabled')) {
				return;
			}

			$btn.prop('disabled', true).text(bwPipAdmin.i18n.processing);
			$result.text('');

			$.ajax({
				url: bwPipAdmin.ajaxUrl,
				type: 'POST',
				data: {
					action: 'bw_pip_delete_all_backups',
					nonce: bwPipAdmin.nonce
				},
				success: function(response) {
					$btn.prop('disabled', false).text(originalText);
					$result.text((response.data && response.data.message) || (response.success ? bwPipAdmin.i18n.success : bwPipAdmin.i18n.failed));
				},
				error: function() {
					$btn.prop('disabled', false).text(originalText);
					$result.text(bwPipAdmin.i18n.failed);
				}
			});
		});
	});
})(jQuery);