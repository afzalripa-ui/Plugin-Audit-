<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$options         = BW_PIP_Settings::get_options();
$can_manage_ai   = current_user_can( 'manage_options' );
$upload_dir      = wp_upload_dir();
$backup_dir      = BW_PIP_Backup::get_backup_dir();
$backup_dir_norm = BW_PIP_Backup::normalize_path( $backup_dir );
$uploads_norm    = BW_PIP_Backup::normalize_path( $upload_dir['basedir'] );
$in_uploads      = 0 === strpos( $backup_dir_norm, trailingslashit( $uploads_norm ) );
$marker_exists   = file_exists( $backup_dir . '/.bw-pip-backup-root' );
$backup_writable = is_dir( $backup_dir ) && is_writable( $backup_dir );

$has_constant_key = defined( 'BW_PIP_API_KEY' ) && '' !== trim( (string) constant( 'BW_PIP_API_KEY' ) );
$has_saved_key    = '' !== (string) get_option( BW_PIP_Settings::API_KEY_OPTION, '' );

global $wpdb;
$pending_queue_count = (int) $wpdb->get_var(
	$wpdb->prepare(
		"SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s",
		'_bw_pip_status',
		'pending'
	)
);
?>
<div class="wrap bw-settings-container">
	<div class="bw-settings-header">
		<div class="bw-header-branding">
			<h1><?php esc_html_e( 'Bongo World Product Image AI Processor', 'bw-product-image-ai-processor' ); ?></h1>
			<p class="bw-tagline"><?php esc_html_e( 'Automated 3:4 Studio Composition (1200x1600), Realistic Daylight Backgrounds & WebP Optimizer.', 'bw-product-image-ai-processor' ); ?></p>
		</div>
		<div class="bw-header-badge">v<?php echo esc_html( BW_PIP_VERSION ); ?></div>
	</div>

	<?php settings_errors(); ?>

	<?php if ( $can_manage_ai && isset( $_GET['bw_api_notice'] ) ) : ?>
		<?php
		$api_notice = sanitize_key( wp_unslash( $_GET['bw_api_notice'] ) );

		if ( 'updated' === $api_notice ) {
			echo '<div class="notice notice-success"><p>' . esc_html__( 'API key updated.', 'bw-product-image-ai-processor' ) . '</p></div>';
		} elseif ( 'cleared' === $api_notice ) {
			echo '<div class="notice notice-success"><p>' . esc_html__( 'API key cleared.', 'bw-product-image-ai-processor' ) . '</p></div>';
		} elseif ( 'unchanged' === $api_notice ) {
			echo '<div class="notice notice-info"><p>' . esc_html__( 'API key left unchanged.', 'bw-product-image-ai-processor' ) . '</p></div>';
		} elseif ( 'constant' === $api_notice ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'API key is defined by the BW_PIP_API_KEY constant and cannot be changed from the admin.', 'bw-product-image-ai-processor' ) . '</p></div>';
		}
		?>
	<?php endif; ?>

	<form method="post" action="options.php" class="bw-settings-form">
		<?php settings_fields( 'bw_pip_settings_group' ); ?>

		<div class="bw-cards-grid">
			<!-- CARD 1: Automation & Processing Scope -->
			<div class="bw-card">
				<div class="bw-card-header">
					<h2><?php esc_html_e( '1. Automation & Processing Scope', 'bw-product-image-ai-processor' ); ?></h2>
				</div>
				<div class="bw-card-body">
					<div class="bw-field-row">
						<label class="bw-switch-label">
							<input type="checkbox" name="bw_pip_settings[enable_auto_process]" value="1" <?php checked( 1, $options['enable_auto_process'] ); ?>>
							<strong><?php esc_html_e( 'Enable Automatic Processing on Upload', 'bw-product-image-ai-processor' ); ?></strong>
						</label>
						<p class="description"><?php esc_html_e( 'Automatically resize to 1200x1600 (3:4), optimize WebP and format newly uploaded images.', 'bw-product-image-ai-processor' ); ?></p>
					</div>

					<div class="bw-field-row">
						<label class="bw-switch-label">
							<input type="checkbox" name="bw_pip_settings[process_products_only]" value="1" <?php checked( 1, $options['process_products_only'] ); ?>>
							<strong><?php esc_html_e( 'Process WooCommerce Product Images Only', 'bw-product-image-ai-processor' ); ?></strong>
						</label>
						<p class="description"><?php esc_html_e( 'Recommended ON. Leaves regular blog and page media un-altered.', 'bw-product-image-ai-processor' ); ?></p>
					</div>

					<div class="bw-field-row">
						<label class="bw-switch-label">
							<input type="checkbox" name="bw_pip_settings[enable_backup]" value="1" <?php checked( 1, $options['enable_backup'] ); ?> id="bw_enable_backup">
							<strong><?php esc_html_e( 'Enable Original Image Backup', 'bw-product-image-ai-processor' ); ?></strong>
						</label>
						<p class="description"><?php esc_html_e( 'Keeps a verified, protected copy of each processed image\'s true original, so you can restore it or safely re-process it later.', 'bw-product-image-ai-processor' ); ?></p>
						<div class="bw-warning">
							<p><?php esc_html_e( 'If you turn this off: the original of a processed image is not recoverable through this plugin, and a later re-process starts from the already-processed file rather than the true original. Only turn this off if you already keep your own copy of these images elsewhere.', 'bw-product-image-ai-processor' ); ?></p>
						</div>
					</div>

					<div class="bw-field-row">
						<strong><?php esc_html_e( 'Backup Storage', 'bw-product-image-ai-processor' ); ?></strong>
						<p class="description">
							<?php
							$bw_backup_stats = BW_PIP_Backup::get_backup_dir_stats();
							printf(
								/* translators: 1: number of files, 2: total size, e.g. "12.3 MB" */
								esc_html__( 'Currently storing %1$d backup file(s), using %2$s.', 'bw-product-image-ai-processor' ),
								(int) $bw_backup_stats['file_count'],
								esc_html( size_format( (int) $bw_backup_stats['total_bytes'] ) )
							);
							?>
						</p>
						<p>
							<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=bw_pip_download_all_backups' ), 'bw_pip_download_all_backups' ) ); ?>"><?php esc_html_e( 'Download All Backups (ZIP)', 'bw-product-image-ai-processor' ); ?></a>
							<button type="button" class="button" id="bw-delete-all-backups"><?php esc_html_e( 'Delete All Backups Now', 'bw-product-image-ai-processor' ); ?></button>
							<span id="bw-delete-all-backups-result" class="description"></span>
						</p>
						<div class="bw-warning">
							<p><?php esc_html_e( 'Deleting backups here is immediate and cannot be undone through this plugin. Download them first if you want a copy kept elsewhere - anything you have already saved yourself is then safe to delete here to free up hosting space, without uninstalling the plugin.', 'bw-product-image-ai-processor' ); ?></p>
						</div>
					</div>

					<div class="bw-field-row">
						<label class="bw-switch-label">
							<input type="checkbox" name="bw_pip_settings[delete_backups_on_uninstall]" value="1" <?php checked( 1, $options['delete_backups_on_uninstall'] ); ?>>
							<strong><?php esc_html_e( 'Also Delete Backups When This Plugin Is Uninstalled', 'bw-product-image-ai-processor' ); ?></strong>
						</label>
						<div class="bw-warning">
							<p><?php esc_html_e( 'Off by default. Leave this OFF to keep your original-image backups safe even if the plugin is later deleted from Plugins. Only turn this ON if you specifically want the backups permanently erased along with the plugin - this cannot be undone.', 'bw-product-image-ai-processor' ); ?></p>
						</div>
					</div>
				</div>
			</div>

			<?php if ( $can_manage_ai ) : ?>
				<!-- CARD 2: AI Background Provider Engine -->
				<div class="bw-card">
					<div class="bw-card-header">
						<h2><?php esc_html_e( '2. AI Background Provider Engine', 'bw-product-image-ai-processor' ); ?></h2>
					</div>
					<div class="bw-card-body">
						<div class="bw-field-row">
							<label class="bw-switch-label">
								<input type="checkbox" name="bw_pip_settings[enable_ai]" value="1" <?php checked( 1, $options['enable_ai'] ); ?> id="bw_enable_ai">
								<strong><?php esc_html_e( 'Enable Cloud AI Background Processing', 'bw-product-image-ai-processor' ); ?></strong>
							</label>
							<p class="description"><?php esc_html_e( 'If disabled or if API fails, the plugin uses its built-in Smart Studio Canvas (Local Mode) with zero cost.', 'bw-product-image-ai-processor' ); ?></p>
						</div>

						<div class="bw-field-row">
							<label for="bw_ai_provider"><strong><?php esc_html_e( 'AI Provider', 'bw-product-image-ai-processor' ); ?></strong></label>
							<select name="bw_pip_settings[ai_provider]" id="bw_ai_provider" class="regular-text">
								<option value="photoroom" <?php selected( 'photoroom', $options['ai_provider'] ); ?>>Photoroom API (AI Backgrounds)</option>
								<option value="clipdrop" <?php selected( 'clipdrop', $options['ai_provider'] ); ?>>Clipdrop API by Stability AI</option>
								<option value="removebg" <?php selected( 'removebg', $options['ai_provider'] ); ?>>Remove.bg API (Background Removal)</option>
							</select>
							<p class="description">
								<?php esc_html_e( 'Remove.bg is a background-removal provider only. It does not use the background prompt.', 'bw-product-image-ai-processor' ); ?><br>
								<?php esc_html_e( 'Clipdrop is used as Replace Background. If the prompt is empty, an empty prompt is sent according to the current plugin behavior.', 'bw-product-image-ai-processor' ); ?>
							</p>
						</div>

						<div class="bw-field-row">
							<label for="bw_bg_prompt"><strong><?php esc_html_e( 'AI Background Generation Prompt', 'bw-product-image-ai-processor' ); ?></strong></label>
							<textarea name="bw_pip_settings[bg_prompt]" id="bw_bg_prompt" rows="4" class="large-text"><?php echo esc_textarea( $options['bg_prompt'] ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Instructs the AI to build realistic daylight indoor setting without altering clothing texture/colors.', 'bw-product-image-ai-processor' ); ?></p>
						</div>
					</div>
				</div>
			<?php endif; ?>

			<!-- CARD 3: Canvas Specifications & Optimization -->
			<div class="bw-card">
				<div class="bw-card-header">
					<h2><?php esc_html_e( '3. Canvas & Image Specifications', 'bw-product-image-ai-processor' ); ?></h2>
				</div>
				<div class="bw-card-body">
					<div class="bw-specs-preview">
						<div class="bw-spec-item">
							<span class="label"><?php esc_html_e( 'Dimensions:', 'bw-product-image-ai-processor' ); ?></span>
							<span class="val">1200 × 1600 px</span>
						</div>
						<div class="bw-spec-item">
							<span class="label"><?php esc_html_e( 'Aspect Ratio:', 'bw-product-image-ai-processor' ); ?></span>
							<span class="val">3:4 (Portrait Fashion)</span>
						</div>
						<div class="bw-spec-item">
							<span class="label"><?php esc_html_e( 'Format:', 'bw-product-image-ai-processor' ); ?></span>
							<span class="val">WebP (Optimized)</span>
						</div>
					</div>

					<div class="bw-field-row">
						<label for="bw_bg_color"><strong><?php esc_html_e( 'Daylight Studio Background Tone', 'bw-product-image-ai-processor' ); ?></strong></label>
						<input type="text" name="bw_pip_settings[bg_color]" id="bw_bg_color" value="<?php echo esc_attr( $options['bg_color'] ); ?>" class="regular-text" placeholder="#F7F6F2">
						<p class="description"><?php esc_html_e( 'Default is #F7F6F2 (warm off-white daylight wall tone, perfect for Modest Fashion).', 'bw-product-image-ai-processor' ); ?></p>
					</div>

					<div class="bw-field-row">
						<label for="bw_max_kb"><strong><?php esc_html_e( 'Target Max Size (KB)', 'bw-product-image-ai-processor' ); ?></strong></label>
						<input type="number" name="bw_pip_settings[target_max_kb]" id="bw_max_kb" value="<?php echo esc_attr( $options['target_max_kb'] ); ?>" class="small-text">
						<p class="description"><?php esc_html_e( 'Hard ceiling for the output WebP file size. The plugin always picks the highest quality that still fits under this limit.', 'bw-product-image-ai-processor' ); ?></p>
					</div>
				</div>
			</div>

			<!-- CARD 4: System Diagnostics -->
			<div class="bw-card">
				<div class="bw-card-header">
					<h2><?php esc_html_e( '4. System Diagnostics & Compatibility', 'bw-product-image-ai-processor' ); ?></h2>
				</div>
				<div class="bw-card-body">
					<ul class="bw-diag-list">
						<li>
							<span class="diag-label"><?php esc_html_e( 'PHP WebP Support (imagewebp):', 'bw-product-image-ai-processor' ); ?></span>
							<span class="diag-val <?php echo function_exists( 'imagewebp' ) ? 'ok' : 'bad'; ?>">
								<?php echo function_exists( 'imagewebp' ) ? esc_html__( 'Available', 'bw-product-image-ai-processor' ) : esc_html__( 'Not Available', 'bw-product-image-ai-processor' ); ?>
							</span>
						</li>
						<li>
							<span class="diag-label"><?php esc_html_e( 'EXIF Extension:', 'bw-product-image-ai-processor' ); ?></span>
							<span class="diag-val <?php echo function_exists( 'exif_read_data' ) ? 'ok' : 'bad'; ?>">
								<?php echo function_exists( 'exif_read_data' ) ? esc_html__( 'Available', 'bw-product-image-ai-processor' ) : esc_html__( 'Warning: Orientation auto-detect disabled', 'bw-product-image-ai-processor' ); ?>
							</span>
						</li>
						<li>
							<span class="diag-label"><?php esc_html_e( 'Async Processing:', 'bw-product-image-ai-processor' ); ?></span>
							<span class="diag-val <?php echo function_exists( 'as_schedule_single_action' ) ? 'ok' : 'bad'; ?>">
								<?php
								if ( function_exists( 'as_schedule_single_action' ) ) {
									esc_html_e( 'Action Scheduler Available', 'bw-product-image-ai-processor' );
								} elseif ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
									esc_html_e( 'WordPress cron disabled - manual queue runs may be needed', 'bw-product-image-ai-processor' );
								} else {
									esc_html_e( 'WordPress cron fallback', 'bw-product-image-ai-processor' );
								}
								?>
							</span>
						</li>
						<li>
							<span class="diag-label"><?php esc_html_e( 'Images Currently Queued:', 'bw-product-image-ai-processor' ); ?></span>
							<span class="diag-val <?php echo 0 === $pending_queue_count ? 'ok' : ''; ?>"><?php echo esc_html( $pending_queue_count ); ?></span>
						</li>
						<li>
							<span class="diag-label"><?php esc_html_e( 'Memory Limit:', 'bw-product-image-ai-processor' ); ?></span>
							<span class="diag-val ok"><?php echo esc_html( ini_get( 'memory_limit' ) ); ?></span>
						</li>
						<li>
							<span class="diag-label"><?php esc_html_e( 'Backup Directory:', 'bw-product-image-ai-processor' ); ?></span>
							<span class="diag-val ok"><code><?php echo esc_html( $backup_dir ); ?></code></span>
						</li>
						<li>
							<span class="diag-label"><?php esc_html_e( 'Backup Directory Writable:', 'bw-product-image-ai-processor' ); ?></span>
							<span class="diag-val <?php echo $backup_writable ? 'ok' : 'bad'; ?>">
								<?php echo $backup_writable ? esc_html__( 'Yes', 'bw-product-image-ai-processor' ) : esc_html__( 'No', 'bw-product-image-ai-processor' ); ?>
							</span>
						</li>
						<li>
							<span class="diag-label"><?php esc_html_e( 'Backup Marker File:', 'bw-product-image-ai-processor' ); ?></span>
							<span class="diag-val <?php echo $marker_exists ? 'ok' : 'bad'; ?>">
								<?php echo $marker_exists ? esc_html__( 'Present', 'bw-product-image-ai-processor' ) : esc_html__( 'Missing', 'bw-product-image-ai-processor' ); ?>
							</span>
						</li>
					</ul>

					<?php if ( $in_uploads ) : ?>
						<div class="bw-warning">
							<p>
								<?php esc_html_e( 'The backup directory is inside the public uploads folder. The .htaccess file protects Apache/LiteSpeed only. If this site runs on Nginx, add an explicit deny rule for this directory.', 'bw-product-image-ai-processor' ); ?>
							</p>
							<p>
								<?php esc_html_e( 'Example Nginx rule:', 'bw-product-image-ai-processor' ); ?><br>
								<code>location ~* <?php echo esc_html( '/wp-content/uploads/' . basename( $backup_dir ) ); ?> { deny all; }</code>
							</p>
							<p>
								<?php esc_html_e( 'For stronger protection, use the bw_pip_backup_dir filter to move backups outside the public document root.', 'bw-product-image-ai-processor' ); ?>
							</p>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<div class="bw-submit-wrap">
			<?php submit_button( __( 'Save Processor Settings', 'bw-product-image-ai-processor' ), 'primary', 'submit', false, array( 'class' => 'bw-submit-btn' ) ); ?>
		</div>
	</form>

	<?php if ( $can_manage_ai ) : ?>
		<div class="bw-card bw-api-key-card">
			<div class="bw-card-header">
				<h2><?php esc_html_e( '5. API Key Management', 'bw-product-image-ai-processor' ); ?></h2>
			</div>
			<div class="bw-card-body">
				<p>
					<?php esc_html_e( 'Current API key status:', 'bw-product-image-ai-processor' ); ?>
					<strong>
						<?php
						if ( $has_constant_key ) {
							esc_html_e( 'Defined by BW_PIP_API_KEY constant', 'bw-product-image-ai-processor' );
						} elseif ( $has_saved_key ) {
							esc_html_e( 'Saved securely in database', 'bw-product-image-ai-processor' );
						} else {
							esc_html_e( 'Not set', 'bw-product-image-ai-processor' );
						}
						?>
					</strong>
				</p>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="bw_pip_save_api_key">
					<?php wp_nonce_field( 'bw_pip_save_api_key' ); ?>

					<div class="bw-field-row">
						<label for="bw_api_key_input"><strong><?php esc_html_e( 'New API Key', 'bw-product-image-ai-processor' ); ?></strong></label>
						<input type="password" name="bw_api_key" id="bw_api_key_input" value="" class="large-text" autocomplete="new-password" <?php disabled( $has_constant_key ); ?>>
						<p class="description"><?php esc_html_e( 'Leave blank to keep the current saved key. The stored key is never displayed.', 'bw-product-image-ai-processor' ); ?></p>
					</div>

					<div class="bw-field-row">
						<label class="bw-switch-label">
							<input type="checkbox" name="bw_clear_api_key" value="1" <?php disabled( $has_constant_key ); ?>>
							<strong><?php esc_html_e( 'Clear saved API key', 'bw-product-image-ai-processor' ); ?></strong>
						</label>
					</div>

					<div class="bw-field-row">
						<?php submit_button( __( 'Save API Key', 'bw-product-image-ai-processor' ), 'secondary', 'submit_api_key', false ); ?>
					</div>
				</form>
			</div>
		</div>
	<?php endif; ?>
</div>