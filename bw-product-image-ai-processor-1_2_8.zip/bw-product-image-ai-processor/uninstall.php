<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

function bw_pip_uninstall_normalize_dir( $path ) {
	return wp_normalize_path( untrailingslashit( (string) $path ) );
}

function bw_pip_uninstall_marker_state( $dir, $salt ) {
	$dir    = bw_pip_uninstall_normalize_dir( $dir );
	$marker = $dir . '/.bw-pip-backup-root';

	if ( ! file_exists( $marker ) ) {
		return 'missing';
	}

	if ( is_link( $marker ) || ! is_file( $marker ) || ! is_readable( $marker ) ) {
		return 'invalid';
	}

	$raw = @file_get_contents( $marker );

	if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
		return 'invalid';
	}

	$data = json_decode( $raw, true );

	if ( ! is_array( $data ) ) {
		return 'invalid';
	}

	if ( empty( $data['plugin'] ) || 'bw-product-image-ai-processor' !== $data['plugin'] ) {
		return 'invalid';
	}

	if ( ! is_string( $salt ) || ! preg_match( '/^[A-Za-z0-9]{24}$/', $salt ) ) {
		return 'invalid';
	}

	if ( empty( $data['salt'] ) || ! is_string( $data['salt'] ) ) {
		return 'invalid';
	}

	return hash_equals( $salt, $data['salt'] ) ? 'valid' : 'invalid';
}

function bw_pip_uninstall_delete_tree_safe( $dir, $root_slash ) {
	if ( ! is_dir( $dir ) ) {
		return;
	}

	$items = scandir( $dir );

	if ( ! is_array( $items ) ) {
		return;
	}

	foreach ( $items as $item ) {
		if ( '.' === $item || '..' === $item ) {
			continue;
		}

		$path = $dir . '/' . $item;

		if ( is_link( $path ) ) {
			@unlink( $path );
			continue;
		}

		if ( is_dir( $path ) ) {
			$real = realpath( $path );

			if ( ! $real ) {
				continue;
			}

			$real_norm = bw_pip_uninstall_normalize_dir( $real );

			if ( 0 !== strpos( $real_norm, $root_slash ) ) {
				continue;
			}

			bw_pip_uninstall_delete_tree_safe( $real_norm, $root_slash );
			@rmdir( $real_norm );
		} else {
			$real = realpath( $path );

			if ( ! $real ) {
				continue;
			}

			$real_norm = bw_pip_uninstall_normalize_dir( $real );

			if ( 0 !== strpos( $real_norm, $root_slash ) ) {
				continue;
			}

			@unlink( $real_norm );
		}
	}
}

function bw_pip_uninstall_delete_backup_candidate( $dir, $legacy_default, $salt ) {
	$dir = bw_pip_uninstall_normalize_dir( $dir );

	if ( '' === $dir ) {
		return;
	}

	if ( is_link( $dir ) ) {
		@unlink( $dir );
		return;
	}

	if ( ! is_dir( $dir ) ) {
		return;
	}

	$upload_dir = wp_upload_dir();
	$protected  = array(
		bw_pip_uninstall_normalize_dir( ABSPATH ),
		bw_pip_uninstall_normalize_dir( WP_CONTENT_DIR ),
	);

	if ( ! empty( $upload_dir['basedir'] ) ) {
		$protected[] = bw_pip_uninstall_normalize_dir( $upload_dir['basedir'] );
	}

	if ( in_array( $dir, $protected, true ) ) {
		return;
	}

	$marker_state = bw_pip_uninstall_marker_state( $dir, $salt );

	if ( 'valid' !== $marker_state ) {
		if ( ! $legacy_default || 'missing' !== $marker_state ) {
			return;
		}

		$basename = basename( $dir );

		if ( ! preg_match( '/^bw-image-backups-[A-Za-z0-9]{24}$/', $basename ) ) {
			return;
		}

		$real_default = realpath( $dir );

		if ( ! $real_default ) {
			return;
		}

		if ( ! empty( $upload_dir['basedir'] ) ) {
			$real_base = realpath( $upload_dir['basedir'] );

			if ( ! $real_base ) {
				return;
			}

			$real_default_norm = bw_pip_uninstall_normalize_dir( $real_default );
			$real_base_norm    = bw_pip_uninstall_normalize_dir( $real_base );

			if ( 0 !== strpos( $real_default_norm, $real_base_norm . '/' ) ) {
				return;
			}
		}
	}

	$real_root = realpath( $dir );

	if ( ! $real_root ) {
		return;
	}

	$real_root_norm = bw_pip_uninstall_normalize_dir( $real_root );

	if ( in_array( $real_root_norm, $protected, true ) ) {
		return;
	}

	$root_slash = trailingslashit( $real_root_norm );

	bw_pip_uninstall_delete_tree_safe( $real_root_norm, $root_slash );
	@rmdir( $real_root_norm );
}

global $wpdb;

if ( function_exists( 'as_unschedule_all_actions' ) ) {
	as_unschedule_all_actions( 'bw_pip_process_image_async' );
	as_unschedule_all_actions( 'bw_pip_backfill_product_markers' );
}

if ( function_exists( 'wp_clear_scheduled_hook' ) ) {
	wp_clear_scheduled_hook( 'bw_pip_process_image_async' );
	wp_clear_scheduled_hook( 'bw_pip_backfill_product_markers' );
}

$stored_salt       = get_option( 'bw_pip_backup_salt', '' );
$stored_custom_dir = get_option( 'bw_pip_backup_dir', '' );
$upload_dir        = wp_upload_dir();

// Backups are only deleted here if the admin explicitly opted in via the
// "Also Delete Backups When This Plugin Is Uninstalled" setting. Default
// is off, so original product images stay recoverable even after a full
// plugin removal.
$stored_settings         = get_option( 'bw_pip_settings', array() );
$delete_backups_opted_in = is_array( $stored_settings ) && ! empty( $stored_settings['delete_backups_on_uninstall'] );

$candidate_map = array();

if ( is_string( $stored_salt ) && preg_match( '/^[A-Za-z0-9]{24}$/', $stored_salt ) && ! empty( $upload_dir['basedir'] ) ) {
	$default_dir = bw_pip_uninstall_normalize_dir( $upload_dir['basedir'] . '/bw-image-backups-' . $stored_salt );

	if ( '' !== $default_dir ) {
		$candidate_map[ $default_dir ] = array(
			'dir'    => $default_dir,
			'legacy' => true,
		);
	}
}

if ( ! empty( $stored_custom_dir ) ) {
	$custom_dir = bw_pip_uninstall_normalize_dir( $stored_custom_dir );

	if ( '' !== $custom_dir ) {
		if ( isset( $candidate_map[ $custom_dir ] ) ) {
			$candidate_map[ $custom_dir ]['legacy'] = true;
		} else {
			$candidate_map[ $custom_dir ] = array(
				'dir'    => $custom_dir,
				'legacy' => false,
			);
		}
	}
}

if ( $delete_backups_opted_in ) {
	foreach ( $candidate_map as $candidate ) {
		bw_pip_uninstall_delete_backup_candidate( $candidate['dir'], $candidate['legacy'], $stored_salt );
	}
}

delete_option( 'bw_pip_settings' );
delete_option( 'bw_pip_api_key' );
delete_option( 'bw_pip_backup_salt' );
delete_option( 'bw_pip_backup_dir' );
delete_option( 'bw_pip_plugin_version' );
delete_option( 'bw_pip_marker_backfill_done_version' );
delete_option( 'bw_pip_marker_backfill_cursor' );

delete_transient( 'bw_pip_marker_backfill_running' );
delete_transient( 'bw_pip_marker_backfill_schedule_lock' );

$meta_keys = array(
	'_bw_pip_status',
	'_bw_pip_log',
	'_bw_pip_filesize',
	'_bw_pip_quality',
	'_bw_pip_backup_path',
	'_bw_pip_original_file',
	'_bw_pip_original_mime',
	'_bw_pip_backup_hash',
	'_bw_pip_product_image',
	'_bw_pip_product_image_ids',
);

$placeholders = implode( ',', array_fill( 0, count( $meta_keys ), '%s' ) );

$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->postmeta} WHERE meta_key IN ($placeholders)",
		$meta_keys
	)
);

$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
		$wpdb->esc_like( 'bw_pip_processing_lock_' ) . '%'
	)
);

$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
		$wpdb->esc_like( '_transient_bw_pip_lock_' ) . '%'
	)
);

$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
		$wpdb->esc_like( '_transient_timeout_bw_pip_lock_' ) . '%'
	)
);

$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
		$wpdb->esc_like( '_transient_bw_pip_marker_backfill' ) . '%'
	)
);

$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
		$wpdb->esc_like( '_transient_timeout_bw_pip_marker_backfill' ) . '%'
	)
);