# BW Product Image AI Processor

WordPress + WooCommerce plugin for Bongo World. Automatically converts product
images to a 1200×1600 (3:4) studio-style WebP canvas, with optional AI
background replacement/removal, EXIF orientation correction, secure original
backups, and restore.

## Requirements

- WordPress 5.8+
- PHP 7.4+
- WooCommerce (active) — the plugin only processes images attached to
  `product` posts; without WooCommerce active it will load but do nothing,
  and now shows an admin notice explaining why.
- PHP GD extension with WebP support (`imagewebp`)

## How processing is triggered

- **Automatic:** on new attachment upload (`wp_generate_attachment_metadata`)
  and on product save (`save_post_product`), images are queued via
  `BW_PIP_Queue` (Action Scheduler if available, WP-Cron fallback) and
  processed in the background by `BW_PIP_Processor::process_attachment()`.
- **Manual:** the "Process Now" button in the Media Library / product editor
  also goes through the same background queue (as of 1.2.2) rather than
  running inline, so an AI provider call can't time out the request.

## AI providers

Configured in Settings → AI Background Provider Engine. Three options:

| Provider | What it does | Composition |
|---|---|---|
| Photoroom | Generates a new full studio background | Cover-fit (fills the 1200×1600 canvas edge to edge) |
| Clipdrop | Replace Background | Cover-fit |
| Remove.bg | Background removal only (transparent cutout) | Contain-fit, composited onto the locally generated gradient background |

If AI is disabled, or a provider call fails, the plugin falls back to
**Local Mode**: the existing (unmodified) image background is padded onto
the local studio gradient canvas (contain-fit).

## Backups

Originals are copied, hash-verified, and stored in a per-site salted folder
inside `wp-content/uploads/` by default (`bw_pip_backup_dir` filter can move
it). This folder is protected via `.htaccess` (Apache/LiteSpeed only — see
the settings page for an Nginx rule) plus a `.bin` extension and hashed
filenames. Restore is verified against the stored SHA-256 hash before it
overwrites anything.

## Settings storage

- `bw_pip_settings` (option): general behavior toggles, target file-size
  range, background color, background prompt. The API key is **never**
  stored in this array.
- `bw_pip_api_key` (option, `autoload=no`): the AI provider API key, or set
  it via the `BW_PIP_API_KEY` PHP constant instead (takes priority and can't
  be changed from the admin UI).

Canvas size (1200×1600, 3:4) and output format (WebP) are fixed — they are
not user-configurable and are not stored as settings.

## Development

No build step. `composer.json` / `phpcs.xml.dist` are included for coding
standards only (dev-time, not loaded at runtime).

See `CHANGELOG.md` for version history.
