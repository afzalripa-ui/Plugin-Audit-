<?php
/**
 * Plugin Name:       BW Product Image AI Processor
 * Description:       Enterprise-grade automatic 3:4 studio canvas sizing (1200x1600), realistic daylight backgrounds, EXIF correction, secure backup/restore, marker-based product image detection, and WebP compression for Bongo World.
 * Version:           1.2.8
 * Author:            Bongo World
 * Text Domain:       bw-product-image-ai-processor
 * Requires at least: 5.8
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BW_PIP_VERSION', '1.2.8' );
define( 'BW_PIP_PLUGIN_FILE', __FILE__ );
define( 'BW_PIP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BW_PIP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

define( 'BW_PIP_MAX_FILE_BYTES', 64 * 1024 * 1024 );
define( 'BW_PIP_MAX_DIMENSION', 8000 );
define( 'BW_PIP_MAX_PIXELS', 40000000 );

require_once BW_PIP_PLUGIN_DIR . 'includes/class-bw-pip-settings.php';
require_once BW_PIP_PLUGIN_DIR . 'includes/class-bw-pip-backup.php';
require_once BW_PIP_PLUGIN_DIR . 'includes/class-bw-pip-canvas.php';

require_once BW_PIP_PLUGIN_DIR . 'includes/providers/class-bw-pip-provider-interface.php';
require_once BW_PIP_PLUGIN_DIR . 'includes/providers/class-bw-pip-provider-photoroom.php';
require_once BW_PIP_PLUGIN_DIR . 'includes/providers/class-bw-pip-provider-clipdrop.php';
require_once BW_PIP_PLUGIN_DIR . 'includes/providers/class-bw-pip-provider-removebg.php';

require_once BW_PIP_PLUGIN_DIR . 'includes/class-bw-pip-processor.php';
require_once BW_PIP_PLUGIN_DIR . 'includes/class-bw-pip-queue.php';
require_once BW_PIP_PLUGIN_DIR . 'includes/class-bw-pip-activator.php';

if ( is_admin() ) {
	require_once BW_PIP_PLUGIN_DIR . 'admin/class-bw-pip-admin.php';
}

register_activation_hook( __FILE__, array( 'BW_PIP_Activator', 'activate' ) );

function bw_pip_init() {
	BW_PIP_Settings::init();
	BW_PIP_Settings::migrate_api_key();

	BW_PIP_Backup::init();
	BW_PIP_Processor::init();
	BW_PIP_Queue::init();

	if ( is_admin() && class_exists( 'BW_PIP_Admin' ) ) {
		BW_PIP_Admin::init();
	}

	if ( is_admin() && ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'bw_pip_woocommerce_missing_notice' );
	}

	$old_version = get_option( 'bw_pip_plugin_version', '' );

	if ( $old_version !== BW_PIP_VERSION ) {
		update_option( 'bw_pip_plugin_version', BW_PIP_VERSION );

		if ( class_exists( 'BW_PIP_Processor' ) ) {
			BW_PIP_Processor::maybe_schedule_marker_backfill();
		}
	}
}

add_action( 'plugins_loaded', 'bw_pip_init' );

function bw_pip_woocommerce_missing_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	echo '<div class="notice notice-warning is-dismissible"><p>' .
		esc_html__( 'BW Product Image AI Processor is built for WooCommerce product images and requires WooCommerce to be active. Automatic and manual image processing will not run until WooCommerce is installed and activated.', 'bw-product-image-ai-processor' ) .
		'</p></div>';
}