# Bongo World AI Product Generator - milestone 1 (Admin UI + services), v0.1.0

Install: upload the ZIP in Plugins > Add New > Upload, activate (WooCommerce must be active).
Menu: "Bongo World AI" -> AI Product Generator, AI Providers, Generation History, Settings, Diagnostics, About.
No API key is needed to open and navigate every page, or to use Free / Manual JSON mode.
API keys (later): define('BW_AIPG_API_KEY_PROFILE_<PROFILE_ID>', '...'); in wp-config.php. The exact name is shown on the provider edit screen.

STATUS: written but NOT tested on a live WordPress/WooCommerce site and PHP was never lint-checked.
See the About page inside the plugin for the implemented / not implemented list.

TRY WITHOUT ANY AI / API KEY
1. Bongo World AI > AI Product Generator > fill: Product Type "Buk Kuci Hijab", Color "Black", Size "Free Size",
   Fabric "Premium Georgette", Design "Buk Kuci with Chin Cover", Style "Ready-to-wear Instant Hijab",
   Age Group "Adult / Teenager", Occasion "School, Madrasa, Daily Wear".
2. Tab 4 (Free / Manual JSON Mode): paste the contents of samples/sample-buk-kuci-hijab.json -> Import & Validate.
   (This sample is hand-written to match the schema. It is NOT AI output.)
3. Review tab 5 and 6, then "Save as Draft". Set price/category yourself in tab 2 first.
