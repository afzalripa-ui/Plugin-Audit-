<?php
namespace BongoWorld\AIProductGenerator\Security;

defined( 'ABSPATH' ) || exit;

final class NonceManager {
	const AJAX_ACTION = 'bwaipg_ajax';

	public static function create(): string {
		return wp_create_nonce( self::AJAX_ACTION );
	}

	public static function verify_ajax(): bool {
		return false !== check_ajax_referer( self::AJAX_ACTION, '_wpnonce', false );
	}
}
