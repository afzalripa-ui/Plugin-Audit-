<?php
namespace BongoWorld\AIProductGenerator\Security;

defined( 'ABSPATH' ) || exit;

/** SSRF guard for admin-configured endpoints. */
final class UrlGuard {
	/** @return array{ok:bool,message:string} */
	public static function validate( string $url ): array {
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return self::fail( 'Invalid URL.' );
		}
		if ( 'https' !== strtolower( $parts['scheme'] ) ) {
			return self::fail( 'Only HTTPS endpoints are allowed.' );
		}
		if ( isset( $parts['user'] ) || isset( $parts['pass'] ) ) {
			return self::fail( 'Credentials inside the URL are not allowed.' );
		}
		$port = isset( $parts['port'] ) ? (int) $parts['port'] : 443;
		if ( 443 !== $port && ! in_array( $port, (array) apply_filters( 'bwaipg_allowed_ports', array() ), true ) ) {
			return self::fail( 'Only port 443 is allowed.' );
		}
		$ips = self::resolve( $parts['host'] );
		if ( empty( $ips ) ) {
			return self::fail( 'Host could not be resolved.' );
		}
		foreach ( $ips as $ip ) {
			if ( false === filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				return self::fail( 'Private, loopback or reserved addresses are blocked.' );
			}
		}
		return array( 'ok' => true, 'message' => '' );
	}

	private static function resolve( string $host ): array {
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return array( $host );
		}
		$ips = array();
		$v4  = gethostbynamel( $host );
		if ( is_array( $v4 ) ) {
			$ips = $v4;
		}
		if ( function_exists( 'dns_get_record' ) ) {
			$v6 = @dns_get_record( $host, DNS_AAAA ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			if ( is_array( $v6 ) ) {
				foreach ( $v6 as $rec ) {
					if ( ! empty( $rec['ipv6'] ) ) {
						$ips[] = $rec['ipv6'];
					}
				}
			}
		}
		return $ips;
	}

	private static function fail( string $msg ): array {
		return array( 'ok' => false, 'message' => $msg );
	}
}
