<?php
namespace BongoWorld\AIProductGenerator\Security;

defined( 'ABSPATH' ) || exit;

/**
 * V1: API keys come ONLY from wp-config.php constants or environment variables.
 * Pattern: BW_AIPG_API_KEY_PROFILE_{PROFILE_ID}.
 * The key is never returned to the browser; UI may only ask is_configured().
 */
final class KeyProvider {
	public static function constant_name( string $profile_id ): string {
		return 'BW_AIPG_API_KEY_PROFILE_' . strtoupper( preg_replace( '/[^A-Za-z0-9]/', '_', $profile_id ) );
	}

	public static function get( string $profile_id ): ?string {
		$name = self::constant_name( $profile_id );
		if ( defined( $name ) && is_string( constant( $name ) ) && '' !== constant( $name ) ) {
			return constant( $name );
		}
		$env = getenv( $name );
		return ( false !== $env && '' !== $env ) ? $env : null;
	}

	public static function is_configured( string $profile_id ): bool {
		return null !== self::get( $profile_id );
	}
}
