<?php
namespace BongoWorld\AIProductGenerator\Security;

use BongoWorld\AIProductGenerator\Includes\Capabilities;

defined( 'ABSPATH' ) || exit;

final class PermissionManager {
	public static function can_generate(): bool {
		return current_user_can( Capabilities::GENERATE );
	}
	public static function can_save(): bool {
		return current_user_can( Capabilities::SAVE );
	}
	public static function can_publish(): bool {
		return current_user_can( Capabilities::PUBLISH );
	}
	public static function can_manage(): bool {
		return current_user_can( Capabilities::MANAGE );
	}
}
