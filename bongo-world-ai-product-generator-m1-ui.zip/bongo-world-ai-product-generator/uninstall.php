<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
global $wpdb;
// Delete ONLY plugin-owned options, transients and the history table.
// Never products, media, categories, tags, global attributes, Rank Math data or store settings.
$patterns = array( 'bwaipg\_%', '\_transient\_bwaipg\_%', '\_transient\_timeout\_bwaipg\_%' );
foreach ( $patterns as $like ) {
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) ); // phpcs:ignore
}
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}bwaipg_generations" ); // phpcs:ignore
