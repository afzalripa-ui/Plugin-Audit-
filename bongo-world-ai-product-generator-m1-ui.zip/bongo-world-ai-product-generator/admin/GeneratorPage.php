<?php
namespace BongoWorld\AIProductGenerator\Admin;

use BongoWorld\AIProductGenerator\AI\ProviderRepository;
use BongoWorld\AIProductGenerator\Includes\Capabilities;
use BongoWorld\AIProductGenerator\Includes\Rules;
use BongoWorld\AIProductGenerator\Includes\Settings;
use BongoWorld\AIProductGenerator\Security\KeyProvider;
use BongoWorld\AIProductGenerator\Security\PermissionManager;

defined( 'ABSPATH' ) || exit;

final class GeneratorPage {
	public function render(): void {
		if ( ! current_user_can( Capabilities::GENERATE ) ) {
			Ui::deny();
		}
		$profiles = ( new ProviderRepository() )->all();
		$active   = (string) Settings::get( 'active_profile', 'manual' );
		if ( 'manual' !== $active && ! isset( $profiles[ $active ] ) ) {
			$active = 'manual';
		}
		$can_publish  = PermissionManager::can_publish();
		$tabs         = array(
			'info'     => __( '1. Product Information', 'bongo-world-ai-product-generator' ),
			'store'    => __( '2. Store Information', 'bongo-world-ai-product-generator' ),
			'images'   => __( '3. Product Images', 'bongo-world-ai-product-generator' ),
			'provider' => __( '4. Provider & Generate', 'bongo-world-ai-product-generator' ),
			'result'   => __( '5. AI Result', 'bongo-world-ai-product-generator' ),
			'validate' => __( '6. Validation & Save', 'bongo-world-ai-product-generator' ),
		);
		$placeholders = array(
			'color'     => 'Black',
			'size'      => 'Free Size',
			'fabric'    => 'Premium Georgette',
			'design'    => 'Buk Kuci with Chin Cover',
			'style'     => 'Ready-to-wear Instant Hijab',
			'age_group' => 'Adult / Teenager',
			'occasion'  => 'School, Madrasa, Daily Wear',
		);
		$cats         = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
		$by_parent    = array();
		if ( ! is_wp_error( $cats ) ) {
			foreach ( $cats as $c ) {
				$by_parent[ (int) $c->parent ][] = $c;
			}
		}
		$walk    = function ( $parent, $depth ) use ( &$walk, $by_parent ) {
			if ( empty( $by_parent[ $parent ] ) ) {
				return;
			}
			foreach ( $by_parent[ $parent ] as $c ) {
				echo '<option value="' . esc_attr( (string) $c->term_id ) . '">' . esc_html( str_repeat( '— ', $depth ) . $c->name ) . '</option>';
				$walk( (int) $c->term_id, $depth + 1 );
			}
		};
		$classes = ( function_exists( 'WC' ) && WC()->shipping() ) ? WC()->shipping()->get_shipping_classes() : array();
		?>
		<div class="wrap bwaipg-wrap" id="bwaipg-generator">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'AI Product Generator', 'bongo-world-ai-product-generator' ); ?></h1>
			<hr class="wp-header-end">
			<?php Ui::render_flash(); ?>
			<div id="bwaipg-notices" role="status" aria-live="polite"></div>
			<noscript><div class="notice notice-error"><p><?php esc_html_e( 'JavaScript is required for this page.', 'bongo-world-ai-product-generator' ); ?></p></div></noscript>
			<p class="bwaipg-lead"><?php esc_html_e( 'AI proposes, code validates, you approve. Price, stock, category and shipping are always yours. Nothing is published without your click.', 'bongo-world-ai-product-generator' ); ?></p>

			<div class="bwaipg-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Generator steps', 'bongo-world-ai-product-generator' ); ?>">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<button type="button" role="tab" class="bwaipg-tab" id="bwaipg-tab-<?php echo esc_attr( $key ); ?>" data-tab="<?php echo esc_attr( $key ); ?>" aria-controls="bwaipg-panel-<?php echo esc_attr( $key ); ?>" aria-selected="false"><?php echo esc_html( $label ); ?></button>
				<?php endforeach; ?>
			</div>

			<!-- 1. Product Information -->
			<div class="bwaipg-panel" id="bwaipg-panel-info" data-panel="info" role="tabpanel" aria-labelledby="bwaipg-tab-info">
				<h2><?php esc_html_e( 'Product Information', 'bongo-world-ai-product-generator' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Facts you type here are treated as USER_PROVIDED. The AI may rewrite wording but may not change these facts.', 'bongo-world-ai-product-generator' ); ?></p>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="bwaipg-product-type"><?php esc_html_e( 'Product Type', 'bongo-world-ai-product-generator' ); ?></label></th>
						<td>
							<input type="text" id="bwaipg-product-type" class="regular-text" list="bwaipg-types" placeholder="Buk Kuci Hijab" autocomplete="off">
							<datalist id="bwaipg-types">
								<?php foreach ( array_keys( Settings::type_codes() ) as $type_label ) : ?>
									<option value="<?php echo esc_attr( (string) $type_label ); ?>"></option>
								<?php endforeach; ?>
							</datalist>
						</td>
					</tr>
					<?php foreach ( Rules::ATTRIBUTES as $key => $label ) : ?>
						<tr>
							<th scope="row"><label for="bwaipg-attr-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
							<td><input type="text" id="bwaipg-attr-<?php echo esc_attr( $key ); ?>" class="regular-text" placeholder="<?php echo esc_attr( $placeholders[ $key ] ?? '' ); ?>"></td>
						</tr>
					<?php endforeach; ?>
					<tr>
						<th scope="row"><label for="bwaipg-notes"><?php esc_html_e( 'Notes (optional)', 'bongo-world-ai-product-generator' ); ?></label></th>
						<td>
							<textarea id="bwaipg-notes" rows="4" class="large-text"></textarea>
							<p class="description"><?php esc_html_e( 'Treated as plain product data only. Instructions typed here are never obeyed.', 'bongo-world-ai-product-generator' ); ?></p>
						</td>
					</tr>
				</table>
				<p><button type="button" class="button button-primary bwaipg-goto" data-tab="store"><?php esc_html_e( 'Next: Store Information', 'bongo-world-ai-product-generator' ); ?> →</button></p>
			</div>

			<!-- 2. Store Information -->
			<div class="bwaipg-panel" id="bwaipg-panel-store" data-panel="store" role="tabpanel" aria-labelledby="bwaipg-tab-store" hidden>
				<h2><?php esc_html_e( 'Store Information', 'bongo-world-ai-product-generator' ); ?></h2>
				<p class="description"><?php esc_html_e( 'These values are never sent to the AI and the AI can never set them. Blank means "leave untouched".', 'bongo-world-ai-product-generator' ); ?></p>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="bwaipg-regular-price"><?php esc_html_e( 'Regular Price', 'bongo-world-ai-product-generator' ); ?></label></th><td><input type="text" id="bwaipg-regular-price" class="small-text" inputmode="decimal"> <span class="description"><?php esc_html_e( 'Bangla digits are accepted.', 'bongo-world-ai-product-generator' ); ?></span></td></tr>
					<tr><th scope="row"><label for="bwaipg-sale-price"><?php esc_html_e( 'Sale Price', 'bongo-world-ai-product-generator' ); ?></label></th><td><input type="text" id="bwaipg-sale-price" class="small-text" inputmode="decimal"></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Manage Stock', 'bongo-world-ai-product-generator' ); ?></th><td><label><input type="checkbox" id="bwaipg-manage-stock"> <?php esc_html_e( 'Track stock quantity', 'bongo-world-ai-product-generator' ); ?></label></td></tr>
					<tr><th scope="row"><label for="bwaipg-stock-qty"><?php esc_html_e( 'Stock Quantity', 'bongo-world-ai-product-generator' ); ?></label></th><td><input type="text" id="bwaipg-stock-qty" class="small-text" inputmode="numeric"></td></tr>
					<tr><th scope="row"><label for="bwaipg-stock-status"><?php esc_html_e( 'Stock Status', 'bongo-world-ai-product-generator' ); ?></label></th><td>
						<select id="bwaipg-stock-status">
							<option value=""><?php esc_html_e( '— leave default —', 'bongo-world-ai-product-generator' ); ?></option>
							<option value="instock"><?php esc_html_e( 'In stock', 'bongo-world-ai-product-generator' ); ?></option>
							<option value="outofstock"><?php esc_html_e( 'Out of stock', 'bongo-world-ai-product-generator' ); ?></option>
							<option value="onbackorder"><?php esc_html_e( 'On backorder', 'bongo-world-ai-product-generator' ); ?></option>
						</select>
					</td></tr>
					<tr><th scope="row"><label for="bwaipg-categories"><?php esc_html_e( 'Category', 'bongo-world-ai-product-generator' ); ?></label></th><td>
						<select id="bwaipg-categories" multiple size="8" class="bwaipg-multi"><?php $walk( 0, 0 ); ?></select>
						<p class="description"><?php esc_html_e( 'Existing categories only. Hold Ctrl/Cmd to select several.', 'bongo-world-ai-product-generator' ); ?></p>
					</td></tr>
					<tr><th scope="row"><label for="bwaipg-shipping-class"><?php esc_html_e( 'Shipping Class', 'bongo-world-ai-product-generator' ); ?></label></th><td>
						<select id="bwaipg-shipping-class">
							<option value="0"><?php esc_html_e( '— none —', 'bongo-world-ai-product-generator' ); ?></option>
							<?php foreach ( (array) $classes as $sc ) : ?>
								<option value="<?php echo esc_attr( (string) $sc->term_id ); ?>"><?php echo esc_html( $sc->name ); ?></option>
							<?php endforeach; ?>
						</select>
					</td></tr>
					<tr><th scope="row"><label for="bwaipg-weight"><?php esc_html_e( 'Weight', 'bongo-world-ai-product-generator' ); ?></label></th><td><input type="text" id="bwaipg-weight" class="small-text" inputmode="decimal"></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Dimensions (L × W × H)', 'bongo-world-ai-product-generator' ); ?></th><td>
						<input type="text" id="bwaipg-length" class="small-text" inputmode="decimal" aria-label="<?php esc_attr_e( 'Length', 'bongo-world-ai-product-generator' ); ?>"> ×
						<input type="text" id="bwaipg-width" class="small-text" inputmode="decimal" aria-label="<?php esc_attr_e( 'Width', 'bongo-world-ai-product-generator' ); ?>"> ×
						<input type="text" id="bwaipg-height" class="small-text" inputmode="decimal" aria-label="<?php esc_attr_e( 'Height', 'bongo-world-ai-product-generator' ); ?>">
					</td></tr>
				</table>
				<p><button type="button" class="button button-primary bwaipg-goto" data-tab="images"><?php esc_html_e( 'Next: Product Images', 'bongo-world-ai-product-generator' ); ?> →</button></p>
			</div>

			<!-- 3. Product Images -->
			<div class="bwaipg-panel" id="bwaipg-panel-images" data-panel="images" role="tabpanel" aria-labelledby="bwaipg-tab-images" hidden>
				<h2><?php esc_html_e( 'Product Images (5 fixed slots)', 'bongo-world-ai-product-generator' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Optional. Main = featured image, the other four = gallery in this exact order. Image metadata in this build is template-based (AI vision analysis is not available yet) and is applied only to the images you select here.', 'bongo-world-ai-product-generator' ); ?></p>
				<div class="bwaipg-slots">
					<?php foreach ( Rules::IMAGE_SLOTS as $slot => $label ) : ?>
						<div class="bwaipg-slot" data-slot="<?php echo esc_attr( $slot ); ?>">
							<strong><?php echo esc_html( $label ); ?></strong>
							<div class="bwaipg-slot-box"><img class="bwaipg-slot-preview" src="" alt="" hidden></div>
							<input type="hidden" class="bwaipg-slot-id" value="0">
							<button type="button" class="button bwaipg-slot-select"><?php esc_html_e( 'Select image', 'bongo-world-ai-product-generator' ); ?></button>
							<button type="button" class="button-link button-link-delete bwaipg-slot-remove" hidden><?php esc_html_e( 'Remove', 'bongo-world-ai-product-generator' ); ?></button>
						</div>
					<?php endforeach; ?>
				</div>
				<p><button type="button" class="button button-primary bwaipg-goto" data-tab="provider"><?php esc_html_e( 'Next: Provider & Generate', 'bongo-world-ai-product-generator' ); ?> →</button></p>
			</div>

			<!-- 4. Provider & Generate -->
			<div class="bwaipg-panel" id="bwaipg-panel-provider" data-panel="provider" role="tabpanel" aria-labelledby="bwaipg-tab-provider" hidden>
				<h2><?php esc_html_e( 'Provider & Generate', 'bongo-world-ai-product-generator' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="bwaipg-provider-select"><?php esc_html_e( 'Active AI Provider', 'bongo-world-ai-product-generator' ); ?></label></th>
						<td>
							<select id="bwaipg-provider-select">
								<option value="manual" <?php selected( $active, 'manual' ); ?>><?php esc_html_e( 'Free / Manual JSON Mode (no API key)', 'bongo-world-ai-product-generator' ); ?></option>
								<?php foreach ( $profiles as $pid => $prof ) : ?>
									<?php
									$configured = KeyProvider::is_configured( (string) $pid );
									$enabled    = ( 'enabled' === ( $prof['status'] ?? '' ) );
									$state      = ! $enabled ? __( 'Disabled', 'bongo-world-ai-product-generator' ) : ( $configured ? __( 'Configured', 'bongo-world-ai-product-generator' ) : __( 'Not Configured', 'bongo-world-ai-product-generator' ) );
									$info       = $prof['display_name'] . ' · ' . ( 'custom_rest' === $prof['connection_type'] ? 'Custom REST' : 'OpenAI-compatible' ) . ' · ' . $prof['model'] . ' · ' . $state;
									?>
									<option value="<?php echo esc_attr( (string) $pid ); ?>" data-info="<?php echo esc_attr( $info ); ?>" <?php selected( $active, (string) $pid ); ?> <?php disabled( ! ( $enabled && $configured ) ); ?>><?php echo esc_html( $prof['display_name'] . ' — ' . $state ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description" id="bwaipg-provider-info"></p>
							<p class="description"><?php esc_html_e( 'Changing the provider only affects future generations. Existing products are never touched.', 'bongo-world-ai-product-generator' ); ?></p>
						</td>
					</tr>
				</table>

				<div class="bwaipg-card bwaipg-mode-free">
					<h3><?php esc_html_e( 'Free / Manual JSON Mode', 'bongo-world-ai-product-generator' ); ?></h3>
					<p><button type="button" class="button" id="bwaipg-copy-prompt"><?php esc_html_e( 'Copy Bongo World Prompt', 'bongo-world-ai-product-generator' ); ?></button></p>
					<textarea id="bwaipg-prompt-out" class="large-text code" rows="6" readonly hidden aria-label="<?php esc_attr_e( 'Generated prompt', 'bongo-world-ai-product-generator' ); ?>"></textarea>
					<p><label for="bwaipg-json-in"><strong><?php esc_html_e( 'Paste the JSON returned by the AI', 'bongo-world-ai-product-generator' ); ?></strong></label></p>
					<textarea id="bwaipg-json-in" class="large-text code" rows="10"></textarea>
					<p><button type="button" class="button button-primary" id="bwaipg-import-json"><?php esc_html_e( 'Import & Validate', 'bongo-world-ai-product-generator' ); ?></button></p>
				</div>

				<div class="bwaipg-card bwaipg-mode-api" hidden>
					<h3><?php esc_html_e( 'API Mode', 'bongo-world-ai-product-generator' ); ?></h3>
					<p class="description"><?php esc_html_e( 'The request is sent from your WordPress server (never from the browser). The API key is read from wp-config.php / environment and is never shown.', 'bongo-world-ai-product-generator' ); ?></p>
					<p><button type="button" class="button button-primary button-hero" id="bwaipg-generate"><?php esc_html_e( 'Generate', 'bongo-world-ai-product-generator' ); ?></button></p>
				</div>
			</div>

			<!-- 5. AI Result -->
			<div class="bwaipg-panel" id="bwaipg-panel-result" data-panel="result" role="tabpanel" aria-labelledby="bwaipg-tab-result" hidden>
				<h2><?php esc_html_e( 'AI Result (editable)', 'bongo-world-ai-product-generator' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Every field is editable. Fields you edit are marked "edited" and are kept when you regenerate, unless you tick the box below.', 'bongo-world-ai-product-generator' ); ?></p>
				<p>
					<button type="button" class="button" id="bwaipg-regenerate-all" hidden><?php esc_html_e( 'Regenerate All', 'bongo-world-ai-product-generator' ); ?></button>
					<label><input type="checkbox" id="bwaipg-replace-edited"> <?php esc_html_e( 'Replace my edited fields with the new AI result', 'bongo-world-ai-product-generator' ); ?></label>
				</p>
				<div id="bwaipg-result-root"></div>
				<p><button type="button" class="button button-primary bwaipg-goto" data-tab="validate"><?php esc_html_e( 'Next: Validation & Save', 'bongo-world-ai-product-generator' ); ?> →</button></p>
			</div>

			<!-- 6. Validation & Save -->
			<div class="bwaipg-panel" id="bwaipg-panel-validate" data-panel="validate" role="tabpanel" aria-labelledby="bwaipg-tab-validate" hidden>
				<h2><?php esc_html_e( 'Validation & Save', 'bongo-world-ai-product-generator' ); ?></h2>
				<p><button type="button" class="button" id="bwaipg-validate-btn"><?php esc_html_e( 'Validate Before Save', 'bongo-world-ai-product-generator' ); ?></button></p>
				<div id="bwaipg-validation" aria-live="polite"></div>
				<div id="bwaipg-dup"></div>
				<p class="bwaipg-save-row">
					<button type="button" class="button button-primary button-hero" id="bwaipg-save-draft"><?php esc_html_e( 'Save as Draft', 'bongo-world-ai-product-generator' ); ?></button>
					<button type="button" class="button button-hero" id="bwaipg-save-publish" <?php disabled( ! $can_publish ); ?>><?php esc_html_e( 'Save & Publish', 'bongo-world-ai-product-generator' ); ?></button>
				</p>
				<?php if ( ! $can_publish ) : ?>
					<p class="description"><?php esc_html_e( 'Your account cannot publish products. Save as Draft only.', 'bongo-world-ai-product-generator' ); ?></p>
				<?php endif; ?>
				<div id="bwaipg-save-output" aria-live="polite"></div>
			</div>
		</div>
		<?php
	}
}
