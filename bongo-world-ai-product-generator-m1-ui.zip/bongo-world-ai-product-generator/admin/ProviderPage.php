<?php
namespace BongoWorld\AIProductGenerator\Admin;

use BongoWorld\AIProductGenerator\AI\CostLimiter;
use BongoWorld\AIProductGenerator\AI\ProviderRepository;
use BongoWorld\AIProductGenerator\Includes\Capabilities;
use BongoWorld\AIProductGenerator\Includes\Settings;
use BongoWorld\AIProductGenerator\Security\KeyProvider;

defined( 'ABSPATH' ) || exit;

final class ProviderPage {
	const NONCE = 'bwaipg_provider_action';

	public function register_hooks(): void {
		add_action( 'admin_post_bwaipg_save_provider', array( $this, 'handle_save' ) );
		add_action( 'admin_post_bwaipg_delete_provider', array( $this, 'handle_delete' ) );
		add_action( 'admin_post_bwaipg_activate_provider', array( $this, 'handle_activate' ) );
	}

	public function handle_save(): void {
		if ( ! current_user_can( Capabilities::MANAGE ) ) {
			Ui::deny();
		}
		check_admin_referer( self::NONCE );
		$in       = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
		$repo     = new ProviderRepository();
		$existing = isset( $in['profile_id'] ) ? sanitize_key( (string) $in['profile_id'] ) : '';
		if ( '' !== $existing && ! $repo->get( $existing ) ) {
			$existing = '';
		}
		$res = $repo->save( $in, $existing );
		if ( $res['ok'] ) {
			Ui::flash( 'success', __( 'Provider saved.', 'bongo-world-ai-product-generator' ) );
			Ui::redirect( 'bwaipg-providers', array( 'edit' => $res['id'] ) );
		}
		set_transient( 'bwaipg_form_' . get_current_user_id(), $in, 120 ); // Keep what was typed.
		Ui::flash( 'error', implode( ' ', $res['errors'] ) );
		Ui::redirect( 'bwaipg-providers', '' !== $existing ? array( 'edit' => $existing ) : array( 'add' => 1 ) );
	}

	public function handle_delete(): void {
		if ( ! current_user_can( Capabilities::MANAGE ) ) {
			Ui::deny();
		}
		check_admin_referer( self::NONCE );
		$id   = isset( $_POST['profile_id'] ) ? sanitize_key( wp_unslash( $_POST['profile_id'] ) ) : ''; // phpcs:ignore
		$repo = new ProviderRepository();
		if ( $repo->delete( $id ) ) {
			if ( Settings::get( 'active_profile' ) === $id ) {
				Settings::update( array( 'active_profile' => 'manual' ) );
			}
			if ( Settings::get( 'fallback_profile' ) === $id ) {
				Settings::update( array( 'fallback_profile' => '', 'fallback_enabled' => false ) );
			}
			Ui::flash( 'success', __( 'Provider profile deleted. Products, images, SEO data and history were not touched.', 'bongo-world-ai-product-generator' ) );
		}
		Ui::redirect( 'bwaipg-providers' );
	}

	public function handle_activate(): void {
		if ( ! current_user_can( Capabilities::MANAGE ) ) {
			Ui::deny();
		}
		check_admin_referer( self::NONCE );
		$id = isset( $_POST['profile_id'] ) ? sanitize_key( wp_unslash( $_POST['profile_id'] ) ) : ''; // phpcs:ignore
		if ( 'manual' === $id || ( new ProviderRepository() )->get( $id ) ) {
			Settings::update( array( 'active_profile' => $id ) );
			Ui::flash( 'success', __( 'Active provider updated. Only future generations are affected.', 'bongo-world-ai-product-generator' ) );
		}
		Ui::redirect( 'bwaipg-providers' );
	}

	private function nonce_input(): void {
		echo '<input type="hidden" name="_wpnonce" value="' . esc_attr( wp_create_nonce( self::NONCE ) ) . '">';
	}

	private function status_label( array $p ): array {
		if ( 'enabled' !== ( $p['status'] ?? '' ) ) {
			return array( '⏸', __( 'Disabled', 'bongo-world-ai-product-generator' ) );
		}
		if ( ! KeyProvider::is_configured( (string) $p['id'] ) ) {
			return array( '⚠', __( 'Not Configured', 'bongo-world-ai-product-generator' ) );
		}
		$t = $p['last_test']['status'] ?? '';
		if ( 'pass' === $t ) {
			return array( '✔', __( 'Connection Tested', 'bongo-world-ai-product-generator' ) );
		}
		if ( 'fail' === $t ) {
			return array( '✖', __( 'Connection Failed', 'bongo-world-ai-product-generator' ) );
		}
		return array( '●', __( 'Configured', 'bongo-world-ai-product-generator' ) );
	}

	public function render(): void {
		if ( ! current_user_can( Capabilities::MANAGE ) ) {
			Ui::deny();
		}
		$repo     = new ProviderRepository();
		$profiles = $repo->all();
		$active   = (string) Settings::get( 'active_profile', 'manual' );
		$edit_id  = isset( $_GET['edit'] ) ? sanitize_key( wp_unslash( $_GET['edit'] ) ) : ''; // phpcs:ignore
		$editing  = '' !== $edit_id ? $repo->get( $edit_id ) : null;
		$adding   = isset( $_GET['add'] ) || null !== $editing; // phpcs:ignore
		$old      = get_transient( 'bwaipg_form_' . get_current_user_id() );
		if ( is_array( $old ) ) {
			delete_transient( 'bwaipg_form_' . get_current_user_id() );
		}
		$v = function ( string $key, $default = '' ) use ( $old, $editing ) {
			if ( is_array( $old ) && isset( $old[ $key ] ) && is_string( $old[ $key ] ) ) {
				return $old[ $key ];
			}
			if ( is_array( $editing ) && isset( $editing[ $key ] ) && is_scalar( $editing[ $key ] ) ) {
				return (string) $editing[ $key ];
			}
			return $default;
		};
		$caps = is_array( $editing ) ? ( $editing['capabilities'] ?? array() ) : array();
		$lim  = is_array( $editing ) ? ( $editing['limits'] ?? array() ) : array();
		$hdrs = is_array( $editing ) && ! empty( $editing['headers'] ) ? wp_json_encode( $editing['headers'], JSON_PRETTY_PRINT ) : '';
		$type = $v( 'connection_type', 'openai_compatible' );
		?>
		<div class="wrap bwaipg-wrap" id="bwaipg-providers">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'AI Providers', 'bongo-world-ai-product-generator' ); ?></h1>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=bwaipg-providers&add=1' ) ); ?>" class="page-title-action"><?php esc_html_e( 'Add Provider', 'bongo-world-ai-product-generator' ); ?></a>
			<hr class="wp-header-end">
			<?php Ui::render_flash(); ?>
			<p class="bwaipg-lead"><?php esc_html_e( 'You can use the plugin with no provider at all (Free / Manual JSON Mode). A provider profile never changes existing products. API keys are NOT stored in the database: define them in wp-config.php (or an environment variable).', 'bongo-world-ai-product-generator' ); ?></p>

			<table class="widefat striped bwaipg-table">
				<thead><tr>
					<th><?php esc_html_e( 'Provider', 'bongo-world-ai-product-generator' ); ?></th>
					<th><?php esc_html_e( 'Connection Type', 'bongo-world-ai-product-generator' ); ?></th>
					<th><?php esc_html_e( 'Model', 'bongo-world-ai-product-generator' ); ?></th>
					<th><?php esc_html_e( 'Status', 'bongo-world-ai-product-generator' ); ?></th>
					<th><?php esc_html_e( 'Requests today / month', 'bongo-world-ai-product-generator' ); ?></th>
					<th><?php esc_html_e( 'Active', 'bongo-world-ai-product-generator' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'bongo-world-ai-product-generator' ); ?></th>
				</tr></thead>
				<tbody>
					<tr>
						<td><strong><?php esc_html_e( 'Free / Manual JSON Mode', 'bongo-world-ai-product-generator' ); ?></strong></td>
						<td><?php esc_html_e( 'No API', 'bongo-world-ai-product-generator' ); ?></td><td>—</td>
						<td>✔ <?php esc_html_e( 'Always available', 'bongo-world-ai-product-generator' ); ?></td><td>—</td>
						<td><?php echo 'manual' === $active ? '<strong>● ' . esc_html__( 'Active', 'bongo-world-ai-product-generator' ) . '</strong>' : '—'; ?></td>
						<td>
							<?php if ( 'manual' !== $active ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<input type="hidden" name="action" value="bwaipg_activate_provider"><input type="hidden" name="profile_id" value="manual"><?php $this->nonce_input(); ?>
									<button class="button button-small"><?php esc_html_e( 'Set Active', 'bongo-world-ai-product-generator' ); ?></button>
								</form>
							<?php endif; ?>
						</td>
					</tr>
					<?php foreach ( $profiles as $pid => $p ) : ?>
						<?php
						list( $icon, $label ) = $this->status_label( $p );
						$usage                = ( new CostLimiter() )->usage( (string) $pid );
						?>
						<tr>
							<td><strong><?php echo esc_html( $p['display_name'] ); ?></strong><br><code class="bwaipg-const"><?php echo esc_html( KeyProvider::constant_name( (string) $pid ) ); ?></code></td>
							<td><?php echo 'custom_rest' === $p['connection_type'] ? esc_html__( 'Custom REST API', 'bongo-world-ai-product-generator' ) : esc_html__( 'OpenAI-Compatible API', 'bongo-world-ai-product-generator' ); ?></td>
							<td><code><?php echo esc_html( $p['model'] ); ?></code></td>
							<td>
								<?php echo esc_html( $icon . ' ' . $label ); ?>
								<?php if ( ! empty( $p['last_test']['time'] ) ) : ?>
									<br><span class="description"><?php echo esc_html( sprintf( /* translators: %s date */ __( 'Last test: %s', 'bongo-world-ai-product-generator' ), wp_date( 'Y-m-d H:i', (int) $p['last_test']['time'] ) ) ); ?></span>
									<?php if ( ! empty( $p['last_test']['message'] ) ) : ?><br><span class="description"><?php echo esc_html( $p['last_test']['message'] ); ?></span><?php endif; ?>
								<?php endif; ?>
								<span class="bwaipg-test-result" aria-live="polite"></span>
							</td>
							<td><?php echo esc_html( $usage['today'] . ' / ' . $usage['month'] ); ?></td>
							<td><?php echo $active === (string) $pid ? '<strong>● ' . esc_html__( 'Active', 'bongo-world-ai-product-generator' ) . '</strong>' : '—'; ?></td>
							<td class="bwaipg-actions">
								<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=bwaipg-providers&edit=' . rawurlencode( (string) $pid ) ) ); ?>"><?php esc_html_e( 'Edit', 'bongo-world-ai-product-generator' ); ?></a>
								<button type="button" class="button button-small bwaipg-test-provider" data-id="<?php echo esc_attr( (string) $pid ); ?>"><?php esc_html_e( 'Test Connection', 'bongo-world-ai-product-generator' ); ?></button>
								<?php if ( $active !== (string) $pid ) : ?>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bwaipg-inline">
										<input type="hidden" name="action" value="bwaipg_activate_provider"><input type="hidden" name="profile_id" value="<?php echo esc_attr( (string) $pid ); ?>"><?php $this->nonce_input(); ?>
										<button class="button button-small"><?php esc_html_e( 'Set Active', 'bongo-world-ai-product-generator' ); ?></button>
									</form>
								<?php endif; ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bwaipg-inline">
									<input type="hidden" name="action" value="bwaipg_delete_provider"><input type="hidden" name="profile_id" value="<?php echo esc_attr( (string) $pid ); ?>"><?php $this->nonce_input(); ?>
									<button class="button button-small button-link-delete bwaipg-confirm"><?php esc_html_e( 'Delete', 'bongo-world-ai-product-generator' ); ?></button>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( $adding ) : ?>
				<h2><?php echo $editing ? esc_html__( 'Edit Provider', 'bongo-world-ai-product-generator' ) : esc_html__( 'Add Provider', 'bongo-world-ai-product-generator' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bwaipg-card">
					<input type="hidden" name="action" value="bwaipg_save_provider">
					<?php $this->nonce_input(); ?>
					<?php if ( $editing ) : ?><input type="hidden" name="profile_id" value="<?php echo esc_attr( (string) $editing['id'] ); ?>"><?php endif; ?>
					<table class="form-table" role="presentation">
						<tr><th scope="row"><label for="bwaipg-display-name"><?php esc_html_e( 'Display Name', 'bongo-world-ai-product-generator' ); ?></label></th><td><input type="text" name="display_name" id="bwaipg-display-name" class="regular-text" value="<?php echo esc_attr( $v( 'display_name' ) ); ?>" required></td></tr>
						<tr><th scope="row"><label for="bwaipg-conn-type"><?php esc_html_e( 'Connection Type', 'bongo-world-ai-product-generator' ); ?></label></th><td>
							<select name="connection_type" id="bwaipg-conn-type">
								<option value="openai_compatible" <?php selected( $type, 'openai_compatible' ); ?>><?php esc_html_e( 'OpenAI-Compatible API', 'bongo-world-ai-product-generator' ); ?></option>
								<option value="custom_rest" <?php selected( $type, 'custom_rest' ); ?>><?php esc_html_e( 'Custom REST API', 'bongo-world-ai-product-generator' ); ?></option>
							</select>
						</td></tr>
						<tr class="bwaipg-only-openai"><th scope="row"><label for="bwaipg-base-url"><?php esc_html_e( 'Base URL', 'bongo-world-ai-product-generator' ); ?></label></th><td><input type="url" name="base_url" id="bwaipg-base-url" class="large-text" placeholder="https://…/v1" value="<?php echo esc_attr( $v( 'base_url' ) ); ?>"><p class="description"><?php esc_html_e( 'HTTPS only. The plugin appends /chat/completions. Do not assume every compatible endpoint supports every feature - use Test Connection.', 'bongo-world-ai-product-generator' ); ?></p></td></tr>
						<tr class="bwaipg-only-custom"><th scope="row"><label for="bwaipg-endpoint"><?php esc_html_e( 'Endpoint URL', 'bongo-world-ai-product-generator' ); ?></label></th><td><input type="url" name="endpoint" id="bwaipg-endpoint" class="large-text" placeholder="https://…" value="<?php echo esc_attr( $v( 'endpoint' ) ); ?>"></td></tr>
						<tr><th scope="row"><label for="bwaipg-model"><?php esc_html_e( 'Model', 'bongo-world-ai-product-generator' ); ?></label></th><td><input type="text" name="model" id="bwaipg-model" class="regular-text" value="<?php echo esc_attr( $v( 'model' ) ); ?>" required></td></tr>
						<tr class="bwaipg-only-custom"><th scope="row"><label for="bwaipg-auth-type"><?php esc_html_e( 'Authentication', 'bongo-world-ai-product-generator' ); ?></label></th><td>
							<select name="auth_type" id="bwaipg-auth-type">
								<option value="bearer" <?php selected( $v( 'auth_type', 'bearer' ), 'bearer' ); ?>>Bearer Token</option>
								<option value="header" <?php selected( $v( 'auth_type', 'bearer' ), 'header' ); ?>>API Key Header</option>
								<option value="basic" <?php selected( $v( 'auth_type', 'bearer' ), 'basic' ); ?>>Basic (key = user:pass)</option>
							</select>
							<input type="text" name="api_key_header" class="regular-text" placeholder="X-API-Key" value="<?php echo esc_attr( $v( 'api_key_header' ) ); ?>" aria-label="<?php esc_attr_e( 'API key header name', 'bongo-world-ai-product-generator' ); ?>">
							<p class="description"><?php esc_html_e( 'Query-string keys are disabled.', 'bongo-world-ai-product-generator' ); ?></p>
						</td></tr>
						<tr class="bwaipg-only-custom"><th scope="row"><label for="bwaipg-headers"><?php esc_html_e( 'Custom Headers (JSON)', 'bongo-world-ai-product-generator' ); ?></label></th><td><textarea name="headers" id="bwaipg-headers" rows="3" class="large-text code"><?php echo esc_textarea( is_array( $old ) && isset( $old['headers'] ) ? (string) $old['headers'] : (string) $hdrs ); ?></textarea><p class="description"><?php esc_html_e( 'Never put secrets here (Authorization is rejected).', 'bongo-world-ai-product-generator' ); ?></p></td></tr>
						<tr class="bwaipg-only-custom"><th scope="row"><label for="bwaipg-template"><?php esc_html_e( 'Request Template (JSON)', 'bongo-world-ai-product-generator' ); ?></label></th><td><textarea name="request_template" id="bwaipg-template" rows="8" class="large-text code" placeholder='{"model":"{{model}}","input":"{{user_prompt}}"}'><?php echo esc_textarea( $v( 'request_template' ) ); ?></textarea><p class="description">{{system_prompt}} {{user_prompt}} {{product_type}} {{product_data}} {{schema}} {{model}} {{images}} — <?php esc_html_e( 'data substitution only, nothing is executed.', 'bongo-world-ai-product-generator' ); ?></p></td></tr>
						<tr class="bwaipg-only-custom"><th scope="row"><label for="bwaipg-text-path"><?php esc_html_e( 'Response Text JSON Path', 'bongo-world-ai-product-generator' ); ?></label></th><td><input type="text" name="response_text_path" id="bwaipg-text-path" class="regular-text code" placeholder="choices.0.message.content" value="<?php echo esc_attr( $v( 'response_text_path' ) ); ?>"></td></tr>
						<tr class="bwaipg-only-custom"><th scope="row"><label for="bwaipg-error-path"><?php esc_html_e( 'Error JSON Path (optional)', 'bongo-world-ai-product-generator' ); ?></label></th><td><input type="text" name="error_path" id="bwaipg-error-path" class="regular-text code" value="<?php echo esc_attr( $v( 'error_path' ) ); ?>"></td></tr>
						<tr><th scope="row"><label for="bwaipg-so"><?php esc_html_e( 'Structured Output', 'bongo-world-ai-product-generator' ); ?></label></th><td>
							<select name="structured_output" id="bwaipg-so">
								<?php foreach ( array( 'none' => __( 'Not supported / unknown', 'bongo-world-ai-product-generator' ), 'json_schema' => 'JSON Schema (strict)', 'json_object' => 'JSON object mode' ) as $k => $l ) : ?>
									<option value="<?php echo esc_attr( $k ); ?>" <?php selected( (string) ( $caps['structured_output'] ?? 'none' ), $k ); ?>><?php echo esc_html( $l ); ?></option>
								<?php endforeach; ?>
							</select>
							<label><input type="checkbox" name="image_input" value="1" <?php checked( ! empty( $caps['image_input'] ) ); ?>> <?php esc_html_e( 'Image input supported', 'bongo-world-ai-product-generator' ); ?></label>
							<p class="description"><?php esc_html_e( 'Leave on "not supported" until you have verified it. Nothing is assumed from the provider name.', 'bongo-world-ai-product-generator' ); ?></p>
						</td></tr>
						<tr><th scope="row"><?php esc_html_e( 'Timeout / Retries', 'bongo-world-ai-product-generator' ); ?></th><td>
							<input type="number" name="timeout" min="5" max="120" class="small-text" value="<?php echo esc_attr( $v( 'timeout', '60' ) ); ?>"> s &nbsp;
							<input type="number" name="retries" min="0" max="2" class="small-text" value="<?php echo esc_attr( $v( 'retries', '2' ) ); ?>"> <?php esc_html_e( 'retries (max 2, transient errors only)', 'bongo-world-ai-product-generator' ); ?>
						</td></tr>
						<tr><th scope="row"><?php esc_html_e( 'Request limits (0 = unlimited)', 'bongo-world-ai-product-generator' ); ?></th><td>
							<input type="number" name="limit_daily" min="0" class="small-text" value="<?php echo esc_attr( (string) ( is_array( $old ) && isset( $old['limit_daily'] ) ? $old['limit_daily'] : ( $lim['daily'] ?? 0 ) ) ); ?>"> <?php esc_html_e( 'per day', 'bongo-world-ai-product-generator' ); ?> &nbsp;
							<input type="number" name="limit_monthly" min="0" class="small-text" value="<?php echo esc_attr( (string) ( is_array( $old ) && isset( $old['limit_monthly'] ) ? $old['limit_monthly'] : ( $lim['monthly'] ?? 0 ) ) ); ?>"> <?php esc_html_e( 'per month', 'bongo-world-ai-product-generator' ); ?> &nbsp;
							<input type="number" name="limit_images" min="0" class="small-text" value="<?php echo esc_attr( (string) ( is_array( $old ) && isset( $old['limit_images'] ) ? $old['limit_images'] : ( $lim['max_image_calls'] ?? 0 ) ) ); ?>"> <?php esc_html_e( 'max image calls (saved, not enforced yet)', 'bongo-world-ai-product-generator' ); ?>
						</td></tr>
						<tr><th scope="row"><label for="bwaipg-status"><?php esc_html_e( 'Status', 'bongo-world-ai-product-generator' ); ?></label></th><td>
							<select name="status" id="bwaipg-status">
								<option value="enabled" <?php selected( $v( 'status', 'enabled' ), 'enabled' ); ?>><?php esc_html_e( 'Enabled', 'bongo-world-ai-product-generator' ); ?></option>
								<option value="disabled" <?php selected( $v( 'status', 'enabled' ), 'disabled' ); ?>><?php esc_html_e( 'Disabled', 'bongo-world-ai-product-generator' ); ?></option>
							</select>
						</td></tr>
						<tr><th scope="row"><?php esc_html_e( 'API Key', 'bongo-world-ai-product-generator' ); ?></th><td>
							<?php if ( $editing ) : ?>
								<p><?php echo KeyProvider::is_configured( (string) $editing['id'] ) ? '✔ <strong>' . esc_html__( 'Configured', 'bongo-world-ai-product-generator' ) . '</strong>' : '⚠ <strong>' . esc_html__( 'Not Configured', 'bongo-world-ai-product-generator' ) . '</strong>'; ?></p>
								<p><?php esc_html_e( 'Add this line to wp-config.php (above the "stop editing" comment), or set the same name as a server environment variable:', 'bongo-world-ai-product-generator' ); ?></p>
								<pre class="bwaipg-pre">define( '<?php echo esc_html( KeyProvider::constant_name( (string) $editing['id'] ) ); ?>', 'YOUR_API_KEY' );</pre>
							<?php else : ?>
								<p class="description"><?php esc_html_e( 'Save the profile first - the exact wp-config.php constant name will be shown here. The key itself is never stored or displayed by this plugin.', 'bongo-world-ai-product-generator' ); ?></p>
							<?php endif; ?>
						</td></tr>
					</table>
					<p>
						<button type="submit" class="button button-primary"><?php esc_html_e( 'Save Provider', 'bongo-world-ai-product-generator' ); ?></button>
						<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=bwaipg-providers' ) ); ?>"><?php esc_html_e( 'Close', 'bongo-world-ai-product-generator' ); ?></a>
					</p>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}
}
