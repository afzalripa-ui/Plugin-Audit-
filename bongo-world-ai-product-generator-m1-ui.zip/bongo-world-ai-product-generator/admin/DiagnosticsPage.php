<?php
namespace BongoWorld\AIProductGenerator\Admin;

use BongoWorld\AIProductGenerator\AI\ProviderRepository;
use BongoWorld\AIProductGenerator\History\GenerationRepository;
use BongoWorld\AIProductGenerator\Includes\Capabilities;
use BongoWorld\AIProductGenerator\Includes\Rules;
use BongoWorld\AIProductGenerator\Includes\Settings;
use BongoWorld\AIProductGenerator\Logging\Logger;
use BongoWorld\AIProductGenerator\Security\KeyProvider;
use BongoWorld\AIProductGenerator\SEO\RankMathAdapter;
use BongoWorld\AIProductGenerator\WooCommerce\AttributeService;

defined( 'ABSPATH' ) || exit;

final class DiagnosticsPage {
	public function render(): void {
		if ( ! current_user_can( Capabilities::MANAGE ) ) {
			Ui::deny();
		}
		$checks = array();
		$add    = function ( string $label, string $status, string $detail = '' ) use ( &$checks ) {
			$checks[] = array( $label, $status, $detail );
		};

		$add( 'PHP ' . PHP_VERSION, version_compare( PHP_VERSION, '7.4', '>=' ) ? 'pass' : 'fail', __( 'Minimum 7.4', 'bongo-world-ai-product-generator' ) );
		$add( 'mbstring', extension_loaded( 'mbstring' ) ? 'pass' : 'fail', __( 'Required for Bangla text handling', 'bongo-world-ai-product-generator' ) );
		$add( 'WordPress ' . get_bloginfo( 'version' ), version_compare( get_bloginfo( 'version' ), '6.0', '>=' ) ? 'pass' : 'warn', __( 'Minimum 6.0', 'bongo-world-ai-product-generator' ) );
		$woo = class_exists( 'WooCommerce' );
		$add( 'WooCommerce', $woo ? 'pass' : 'fail', $woo && defined( 'WC_VERSION' ) ? 'v' . WC_VERSION : __( 'Not active', 'bongo-world-ai-product-generator' ) );
		$add( 'WC_Product_Simple (CRUD)', class_exists( 'WC_Product_Simple' ) ? 'pass' : 'fail', '' );
		$add( 'HTTPS', is_ssl() ? 'pass' : 'warn', __( 'Admin should run over HTTPS', 'bongo-world-ai-product-generator' ) );

		$hist = new GenerationRepository();
		$add( __( 'History table', 'bongo-world-ai-product-generator' ), $hist->table_exists() ? 'pass' : 'fail', (string) get_option( 'bwaipg_db_version', '' ) );

		$rm = new RankMathAdapter();
		$add( 'Rank Math (optional)', $rm->is_active() ? 'pass' : 'warn', $rm->is_active() ? 'v' . $rm->version() : __( 'Not active - SEO fields will be skipped on save', 'bongo-world-ai-product-generator' ) );

		if ( $woo ) {
			foreach ( ( new AttributeService() )->report() as $k => $tax ) {
				$add( sprintf( /* translators: %s attribute */ __( 'Attribute: %s', 'bongo-world-ai-product-generator' ), Rules::ATTRIBUTES[ $k ] ), $tax ? 'pass' : 'warn', $tax ? $tax : __( 'No global attribute - saved as custom attribute', 'bongo-world-ai-product-generator' ) );
			}
		}

		$profiles = ( new ProviderRepository() )->all();
		$active   = (string) Settings::get( 'active_profile', 'manual' );
		$add( __( 'Active provider', 'bongo-world-ai-product-generator' ), 'pass', 'manual' === $active ? __( 'Free / Manual JSON Mode', 'bongo-world-ai-product-generator' ) : ( $profiles[ $active ]['display_name'] ?? $active ) );
		foreach ( $profiles as $pid => $p ) {
			$ok = KeyProvider::is_configured( (string) $pid );
			$add( sprintf( /* translators: %s provider */ __( 'Provider key: %s', 'bongo-world-ai-product-generator' ), $p['display_name'] ), $ok ? 'pass' : 'warn', $ok ? __( 'Configured', 'bongo-world-ai-product-generator' ) : __( 'Not Configured', 'bongo-world-ai-product-generator' ) . ' (' . KeyProvider::constant_name( (string) $pid ) . ')' );
		}
		$add( __( 'Debug logging', 'bongo-world-ai-product-generator' ), 'pass', Settings::get( 'debug_logging' ) ? 'ON' : 'OFF' );
		$add( __( 'Automatic Publish', 'bongo-world-ai-product-generator' ), 'pass', 'OFF (locked)' );
		$icons = array( 'pass' => '✔ PASS', 'warn' => '⚠ WARNING', 'fail' => '✖ FAIL' );
		?>
		<div class="wrap bwaipg-wrap" id="bwaipg-diagnostics">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Diagnostics', 'bongo-world-ai-product-generator' ); ?></h1>
			<hr class="wp-header-end">
			<p class="description"><?php esc_html_e( 'Read-only checks. Nothing here calls an AI provider.', 'bongo-world-ai-product-generator' ); ?></p>
			<table class="widefat striped bwaipg-table">
				<thead><tr><th><?php esc_html_e( 'Check', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'Result', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'Detail', 'bongo-world-ai-product-generator' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $checks as $c ) : ?>
					<tr><td><?php echo esc_html( $c[0] ); ?></td><td><?php echo esc_html( $icons[ $c[1] ] ); ?></td><td><?php echo esc_html( $c[2] ); ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Recent plugin events', 'bongo-world-ai-product-generator' ); ?></h2>
			<table class="widefat striped bwaipg-table">
				<thead><tr><th><?php esc_html_e( 'Time', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'Level', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'Event', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'Details', 'bongo-world-ai-product-generator' ); ?></th></tr></thead>
				<tbody>
				<?php $log = Logger::recent( 50 ); ?>
				<?php if ( ! $log ) : ?><tr><td colspan="4"><?php esc_html_e( 'No events yet.', 'bongo-world-ai-product-generator' ); ?></td></tr><?php endif; ?>
				<?php foreach ( $log as $e ) : ?>
					<tr>
						<td><?php echo esc_html( wp_date( 'Y-m-d H:i:s', (int) $e['t'] ) ); ?></td>
						<td><?php echo esc_html( (string) $e['level'] ); ?></td>
						<td><code><?php echo esc_html( (string) $e['type'] ); ?></code></td>
						<td><?php echo esc_html( wp_json_encode( $e['ctx'], JSON_UNESCAPED_UNICODE ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
