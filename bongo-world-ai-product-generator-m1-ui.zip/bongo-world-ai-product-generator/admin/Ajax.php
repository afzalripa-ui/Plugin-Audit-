<?php
namespace BongoWorld\AIProductGenerator\Admin;

use BongoWorld\AIProductGenerator\AI\GenerationService;
use BongoWorld\AIProductGenerator\AI\PromptManager;
use BongoWorld\AIProductGenerator\AI\ProviderFactory;
use BongoWorld\AIProductGenerator\AI\ProviderRepository;
use BongoWorld\AIProductGenerator\AI\ResponseNormalizer;
use BongoWorld\AIProductGenerator\History\GenerationRepository;
use BongoWorld\AIProductGenerator\Includes\Capabilities;
use BongoWorld\AIProductGenerator\Includes\Helpers;
use BongoWorld\AIProductGenerator\Includes\QualityGate;
use BongoWorld\AIProductGenerator\Includes\Rules;
use BongoWorld\AIProductGenerator\Logging\Logger;
use BongoWorld\AIProductGenerator\Security\KeyProvider;
use BongoWorld\AIProductGenerator\Security\NonceManager;
use BongoWorld\AIProductGenerator\WooCommerce\ProductService;

defined( 'ABSPATH' ) || exit;

/** All endpoints: wp_ajax_bwaipg_* (logged-in only), nonce + capability on every call. No anonymous endpoint. */
final class Ajax {
	public function register(): void {
		foreach ( array( 'get_prompt', 'import_json', 'generate', 'validate', 'save', 'provider_test' ) as $action ) {
			add_action( 'wp_ajax_bwaipg_' . $action, array( $this, $action ) );
		}
	}

	private function guard( string $cap ): array {
		if ( ! NonceManager::verify_ajax() ) {
			wp_send_json_error( array( 'code' => 'bad_nonce', 'message' => __( 'Security check failed. Reload the page and try again.', 'bongo-world-ai-product-generator' ) ), 403 );
		}
		if ( ! current_user_can( $cap ) ) {
			wp_send_json_error( array( 'code' => 'forbidden', 'message' => __( 'You do not have permission to do this.', 'bongo-world-ai-product-generator' ) ), 403 );
		}
		$raw  = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
		$data = json_decode( is_string( $raw ) ? $raw : '', true );
		return is_array( $data ) ? $data : array();
	}

	private function context( array $p ): array {
		return array(
			'info'   => Helpers::clean_info( $p['info'] ?? array() ),
			'store'  => Helpers::clean_store( $p['store'] ?? array() ),
			'images' => Helpers::clean_images( $p['images'] ?? array() ),
			'edited' => Helpers::clean_paths( $p['edited'] ?? array() ),
		);
	}

	private function need_type( array $ctx ): void {
		if ( '' === $ctx['info']['product_type'] ) {
			wp_send_json_error( array( 'code' => 'input', 'message' => __( 'Enter the product type first.', 'bongo-world-ai-product-generator' ) ) );
		}
	}

	/** Free mode: build the copyable Bongo World prompt. No API call. */
	public function get_prompt(): void {
		$ctx = $this->context( $this->guard( Capabilities::GENERATE ) );
		$this->need_type( $ctx );
		wp_send_json_success( array( 'prompt' => PromptManager::free_mode_prompt( $ctx['info'] ) ) );
	}

	/** Free mode: import pasted JSON through the SAME normalizer + quality gate as API mode. */
	public function import_json(): void {
		$p    = $this->guard( Capabilities::GENERATE );
		$ctx  = $this->context( $p );
		$json = ( isset( $p['json'] ) && is_string( $p['json'] ) ) ? $p['json'] : '';
		if ( '' === trim( $json ) || strlen( $json ) > 300000 ) {
			wp_send_json_error( array( 'code' => 'input', 'message' => __( 'Paste the JSON (max 300 KB).', 'bongo-world-ai-product-generator' ) ) );
		}
		$norm = ResponseNormalizer::from_text( $json );
		if ( ! $norm['ok'] ) {
			Logger::event( 'validation_failed', array( 'code' => 'malformed_json' ) );
			wp_send_json_error( array( 'code' => 'malformed_json', 'message' => (string) $norm['error'] ) );
		}
		$gate = QualityGate::run( $norm['data'], array_merge( $ctx, array( 'mode' => 'draft' ) ) );
		$gid  = Helpers::uuid();
		( new GenerationRepository() )->create(
			array(
				'generation_id'   => $gid,
				'user_id'         => get_current_user_id(),
				'profile_id'      => 'manual',
				'provider_name'   => 'Manual JSON',
				'connection_type' => 'manual',
				'prompt_version'  => Rules::PROMPT_VERSION,
				'operation'       => 'import_json',
				'status'          => $gate['ready'] ? 'success' : 'validation_failed',
			)
		);
		wp_send_json_success( array( 'data' => $norm['data'], 'validation' => $gate, 'generation_id' => $gid ) );
	}

	/** API mode generation. Server-side only (browser never talks to the AI provider). */
	public function generate(): void {
		$p   = $this->guard( Capabilities::GENERATE );
		$ctx = $this->context( $p );
		$this->need_type( $ctx );

		$repo    = new ProviderRepository();
		$profile = $repo->get( sanitize_key( (string) ( $p['profile_id'] ?? '' ) ) );
		if ( ! $profile ) {
			wp_send_json_error( array( 'code' => 'no_provider', 'message' => __( 'Select a configured AI provider (or use Free / Manual JSON Mode).', 'bongo-world-ai-product-generator' ) ) );
		}
		$usable = $repo->usable( $profile );
		if ( ! $usable['ok'] ) {
			wp_send_json_error( array( 'code' => 'provider_unusable', 'message' => $usable['message'] ) );
		}

		// Double-submission protection (spec §74).
		$lock = 'bwaipg_lock_' . get_current_user_id();
		if ( get_transient( $lock ) ) {
			wp_send_json_error( array( 'code' => 'busy', 'message' => __( 'A generation is already running. Please wait.', 'bongo-world-ai-product-generator' ) ) );
		}
		set_transient( $lock, 1, 180 );
		try {
			$out = ( new GenerationService() )->generate_product( $profile, $ctx['info'], $ctx['store'], $ctx['images'], $ctx['edited'] );
		} catch ( \Throwable $e ) {
			Logger::event( 'api_error', array( 'code' => 'unexpected' ) );
			$out = array( 'ok' => false, 'error' => array( 'code' => 'unexpected', 'message' => __( 'Unexpected error while generating.', 'bongo-world-ai-product-generator' ) ) );
		}
		delete_transient( $lock );

		if ( empty( $out['ok'] ) ) {
			wp_send_json_error( $out['error'] );
		}
		wp_send_json_success( array( 'data' => $out['data'], 'validation' => $out['validation'], 'generation_id' => $out['generation_id'], 'provider' => $out['provider'] ) );
	}

	/** "Validate Before Save" (dry run). */
	public function validate(): void {
		$p      = $this->guard( Capabilities::GENERATE );
		$ctx    = $this->context( $p );
		$result = ( isset( $p['result'] ) && is_array( $p['result'] ) ) ? $p['result'] : array();
		$mode   = ( isset( $p['mode'] ) && 'publish' === $p['mode'] ) ? 'publish' : 'draft';
		$gate   = QualityGate::run( $result, array_merge( $ctx, array( 'mode' => $mode, 'product_id' => absint( $p['product_id'] ?? 0 ) ) ) );
		wp_send_json_success( array( 'validation' => $gate ) );
	}

	public function save(): void {
		$p    = $this->guard( Capabilities::SAVE );
		$ctx  = $this->context( $p );
		$mode = ( isset( $p['mode'] ) && 'publish' === $p['mode'] ) ? 'publish' : 'draft';
		if ( 'publish' === $mode && ! current_user_can( Capabilities::PUBLISH ) ) {
			wp_send_json_error( array( 'code' => 'publish_permission', 'message' => __( 'You do not have permission to publish products.', 'bongo-world-ai-product-generator' ) ), 403 );
		}
		$result     = ( isset( $p['result'] ) && is_array( $p['result'] ) ) ? $p['result'] : array();
		$product_id = absint( $p['product_id'] ?? 0 );

		$gate = QualityGate::run( $result, array_merge( $ctx, array( 'mode' => $mode, 'product_id' => $product_id ) ) );
		if ( ! $gate['ready'] ) {
			wp_send_json_error( array( 'code' => 'validation_failed', 'message' => __( 'Validation has errors. Fix them before saving.', 'bongo-world-ai-product-generator' ), 'validation' => $gate ) );
		}
		if ( $gate['duplicates'] && 0 === $product_id && empty( $p['confirm_duplicate'] ) ) {
			wp_send_json_error( array( 'code' => 'duplicate_found', 'message' => __( 'সম্ভাব্য একই product পাওয়া গেছে।', 'bongo-world-ai-product-generator' ), 'duplicates' => $gate['duplicates'], 'validation' => $gate ) );
		}

		$res = ( new ProductService() )->save(
			$result,
			$ctx['store'],
			$ctx['images'],
			array(
				'mode'          => $mode,
				'product_id'    => $product_id,
				'product_type'  => $ctx['info']['product_type'],
				'generation_id' => sanitize_text_field( (string) ( $p['generation_id'] ?? '' ) ),
			)
		);
		if ( ! $res['ok'] ) {
			wp_send_json_error( array( 'code' => $res['error']['code'], 'message' => $res['error']['message'] ) );
		}
		wp_send_json_success( $res );
	}

	public function provider_test(): void {
		$p       = $this->guard( Capabilities::MANAGE );
		$repo    = new ProviderRepository();
		$profile = $repo->get( sanitize_key( (string) ( $p['id'] ?? '' ) ) );
		if ( ! $profile ) {
			wp_send_json_error( array( 'code' => 'no_provider', 'message' => __( 'Provider not found.', 'bongo-world-ai-product-generator' ) ) );
		}
		$id = (string) $profile['id'];
		if ( ! KeyProvider::is_configured( $id ) ) {
			$repo->record_test( $id, 'not_configured', 'API key not configured' );
			wp_send_json_error( array( 'code' => 'key_missing', 'message' => __( 'Not Configured: define the API key constant in wp-config.php first.', 'bongo-world-ai-product-generator' ) ) );
		}
		$provider = ProviderFactory::make( $profile );
		$res      = $provider ? $provider->testConnection() : array( 'ok' => false, 'error' => array( 'message' => 'Unknown connection type.' ) );
		$repo->record_test( $id, $res['ok'] ? 'pass' : 'fail', $res['ok'] ? '' : (string) ( $res['error']['message'] ?? '' ) );
		( new GenerationRepository() )->create(
			array(
				'generation_id'   => Helpers::uuid(),
				'user_id'         => get_current_user_id(),
				'profile_id'      => $id,
				'provider_name'   => (string) $profile['display_name'],
				'connection_type' => (string) $profile['connection_type'],
				'model'           => (string) $profile['model'],
				'prompt_version'  => Rules::PROMPT_VERSION,
				'operation'       => 'test_connection',
				'status'          => $res['ok'] ? 'success' : 'failed',
				'error_type'      => $res['ok'] ? '' : (string) ( $res['error']['code'] ?? '' ),
			)
		);
		if ( ! $res['ok'] ) {
			wp_send_json_error( array( 'code' => (string) ( $res['error']['code'] ?? 'fail' ), 'message' => (string) ( $res['error']['message'] ?? '' ) ) );
		}
		wp_send_json_success( array( 'message' => __( 'PASS: the provider answered.', 'bongo-world-ai-product-generator' ) ) );
	}
}
