<?php
namespace BongoWorld\AIProductGenerator\Admin;

use BongoWorld\AIProductGenerator\Includes\Rules;
use BongoWorld\AIProductGenerator\Security\NonceManager;
use BongoWorld\AIProductGenerator\Security\PermissionManager;

defined( 'ABSPATH' ) || exit;

/** Loads CSS/JS only on this plugin's own admin pages. */
final class Assets {
	public function register(): void {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	public function enqueue( $hook ): void {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( 0 !== strpos( $page, 'bwaipg' ) ) {
			return;
		}
		wp_enqueue_style( 'bwaipg-admin', plugins_url( 'assets/css/admin.css', BWAIPG_FILE ), array(), BWAIPG_VERSION );
		wp_enqueue_script( 'bwaipg-admin', plugins_url( 'assets/js/admin.js', BWAIPG_FILE ), array( 'jquery' ), BWAIPG_VERSION, true );
		if ( 'bwaipg' === $page ) {
			wp_enqueue_media();
		}
		wp_add_inline_script( 'bwaipg-admin', 'window.bwaipgConfig = ' . wp_json_encode( $this->config() ) . ';', 'before' );
	}

	private function config(): array {
		return array(
			'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
			'nonce'      => NonceManager::create(),
			'canPublish' => PermissionManager::can_publish(),
			'attributes' => Rules::ATTRIBUTES,
			'slots'      => Rules::IMAGE_SLOTS,
			'sources'    => Rules::SOURCES,
			'labels'     => array(
				'name'                      => __( 'Product Name', 'bongo-world-ai-product-generator' ),
				'seo_title'                 => __( 'SEO Title', 'bongo-world-ai-product-generator' ),
				'focus_keyword'             => __( 'Focus Keyword', 'bongo-world-ai-product-generator' ),
				'focus_keyword_slug_source' => __( 'Focus Keyword (Latin letters, used for the slug)', 'bongo-world-ai-product-generator' ),
				'slug'                      => __( 'Slug', 'bongo-world-ai-product-generator' ),
				'short_description'         => __( 'Short Description', 'bongo-world-ai-product-generator' ),
				'meta_description'          => __( 'SEO Meta Description', 'bongo-world-ai-product-generator' ),
				'tags'                      => __( 'Product Tags', 'bongo-world-ai-product-generator' ),
				'words'                     => __( 'words', 'bongo-world-ai-product-generator' ),
				'alt'                       => __( 'Alt Text', 'bongo-world-ai-product-generator' ),
				'title'                     => __( 'Title', 'bongo-world-ai-product-generator' ),
				'caption'                   => __( 'Image Caption', 'bongo-world-ai-product-generator' ),
				'description'               => __( 'Description', 'bongo-world-ai-product-generator' ),
				'basis'                     => __( 'Basis', 'bongo-world-ai-product-generator' ),
				'source'                    => __( 'Source', 'bongo-world-ai-product-generator' ),
				'stepProduct'               => __( 'Product', 'bongo-world-ai-product-generator' ),
				'stepImage'                 => __( 'image metadata', 'bongo-world-ai-product-generator' ),
			),
			'i18n'       => array(
				'generating'     => __( 'Generating…', 'bongo-world-ai-product-generator' ),
				'working'        => __( 'Working…', 'bongo-world-ai-product-generator' ),
				'networkError'   => __( 'Network or server error. Nothing was lost - try again.', 'bongo-world-ai-product-generator' ),
				'noResult'       => __( 'No result yet. Generate or import one first.', 'bongo-world-ai-product-generator' ),
				'promptCopied'   => __( 'Prompt copied. Paste it into ChatGPT (or any AI), then paste the JSON it returns below.', 'bongo-world-ai-product-generator' ),
				'promptShown'    => __( 'Prompt ready below - select and copy it.', 'bongo-world-ai-product-generator' ),
				'pasteJson'      => __( 'Paste the JSON first.', 'bongo-world-ai-product-generator' ),
				'needType'       => __( 'Enter the product type first.', 'bongo-world-ai-product-generator' ),
				'edited'         => __( 'edited', 'bongo-world-ai-product-generator' ),
				'chars'          => __( 'characters', 'bongo-world-ai-product-generator' ),
				'productContent' => __( 'Product content', 'bongo-world-ai-product-generator' ),
				'description'    => __( 'Description sections', 'bongo-world-ai-product-generator' ),
				'attributes'     => __( 'Attributes (exactly 7)', 'bongo-world-ai-product-generator' ),
				'imageMeta'      => __( 'Image metadata (exactly 5 slots)', 'bongo-world-ai-product-generator' ),
				'addSection'     => __( 'Add section', 'bongo-world-ai-product-generator' ),
				'removeSection'  => __( 'Remove section', 'bongo-world-ai-product-generator' ),
				'heading'        => __( 'Section heading (optional)', 'bongo-world-ai-product-generator' ),
				'paragraphs'     => __( 'Paragraphs (blank line between)', 'bongo-world-ai-product-generator' ),
				'tagsHelp'       => __( 'Comma separated, 8-15 tags', 'bongo-world-ai-product-generator' ),
				'freeModeInfo'   => __( 'No API key needed. Copy the prompt, use any AI, paste the JSON back.', 'bongo-world-ai-product-generator' ),
				'selectImage'    => __( 'Select image', 'bongo-world-ai-product-generator' ),
				'pass'           => __( 'PASS', 'bongo-world-ai-product-generator' ),
				'warning'        => __( 'WARNING', 'bongo-world-ai-product-generator' ),
				'error'          => __( 'ERROR', 'bongo-world-ai-product-generator' ),
				'ready'          => __( 'READY TO SAVE', 'bongo-world-ai-product-generator' ),
				'notReady'       => __( 'NOT READY TO SAVE', 'bongo-world-ai-product-generator' ),
				'skuPreview'     => __( 'SKU (assigned on save)', 'bongo-world-ai-product-generator' ),
				'savedDraft'     => __( 'Product saved as draft.', 'bongo-world-ai-product-generator' ),
				'savedPublish'   => __( 'Product published.', 'bongo-world-ai-product-generator' ),
				'partial'        => __( 'Product saved, but some steps need attention. You can retry safely - the same product is updated, no duplicate is created.', 'bongo-world-ai-product-generator' ),
				'retrySave'      => __( 'Retry Save', 'bongo-world-ai-product-generator' ),
				'editProduct'    => __( 'Open product', 'bongo-world-ai-product-generator' ),
				'dupTitle'       => __( 'সম্ভাব্য একই product পাওয়া গেছে।', 'bongo-world-ai-product-generator' ),
				'reviewExisting' => __( 'Review Existing', 'bongo-world-ai-product-generator' ),
				'createNew'      => __( 'Create New', 'bongo-world-ai-product-generator' ),
				'cancel'         => __( 'Cancel', 'bongo-world-ai-product-generator' ),
				'confirmDelete'  => __( 'Delete this provider profile? Products, images, SEO data and history are NOT deleted.', 'bongo-world-ai-product-generator' ),
				'testing'        => __( 'Testing…', 'bongo-world-ai-product-generator' ),
				'stepOk'         => __( 'OK', 'bongo-world-ai-product-generator' ),
				'stepFailed'     => __( 'FAILED', 'bongo-world-ai-product-generator' ),
				'stepSkipped'    => __( 'SKIPPED', 'bongo-world-ai-product-generator' ),
			),
		);
	}
}
