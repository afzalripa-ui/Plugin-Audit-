<?php
namespace BongoWorld\AIProductGenerator\Admin;

use BongoWorld\AIProductGenerator\AI\ProviderRepository;
use BongoWorld\AIProductGenerator\Includes\Capabilities;
use BongoWorld\AIProductGenerator\Includes\Rules;
use BongoWorld\AIProductGenerator\Includes\Settings;
use BongoWorld\AIProductGenerator\WooCommerce\AttributeService;

defined( 'ABSPATH' ) || exit;

final class SettingsPage {
	const NONCE = 'bwaipg_save_settings';

	public function register_hooks(): void {
		add_action( 'admin_post_bwaipg_save_settings', array( $this, 'handle_save' ) );
	}

	public function handle_save(): void {
		if ( ! current_user_can( Capabilities::MANAGE ) ) {
			Ui::deny();
		}
		check_admin_referer( self::NONCE );
		$in     = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
		$errors = array();
		$new    = array();

		$pattern = isset( $in['sku_pattern'] ) ? trim( (string) $in['sku_pattern'] ) : '';
		if ( Settings::pattern_is_valid( $pattern ) ) {
			$new['sku_pattern'] = $pattern;
		} else {
			$errors[] = __( 'SKU pattern must contain {SEQUENCE} and may only use letters, numbers, - _ and the tokens {TYPE} {YYMM} {SEQUENCE}.', 'bongo-world-ai-product-generator' );
		}

		$codes = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $in['type_codes'] ?? '' ) ) as $line ) {
			$parts = array_map( 'trim', explode( '|', $line, 2 ) );
			if ( 2 === count( $parts ) && '' !== $parts[0] ) {
				$code = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', $parts[1] ) );
				if ( '' !== $code ) {
					$codes[ sanitize_text_field( $parts[0] ) ] = substr( $code, 0, 4 );
				}
			}
		}
		if ( $codes ) {
			$new['type_codes'] = $codes;
		} else {
			$errors[] = __( 'Add at least one product type in the form "Label|CODE".', 'bongo-world-ai-product-generator' );
		}

		$allowed = array( 'auto', 'local' );
		if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
			foreach ( wc_get_attribute_taxonomies() as $t ) {
				$allowed[] = $t->attribute_name;
			}
		}
		$map = array();
		foreach ( array_keys( Rules::ATTRIBUTES ) as $k ) {
			$choice      = isset( $in['attribute_map'][ $k ] ) ? (string) $in['attribute_map'][ $k ] : 'auto';
			$map[ $k ] = in_array( $choice, $allowed, true ) ? $choice : 'auto';
		}
		$new['attribute_map']        = $map;
		$new['create_missing_terms'] = ! empty( $in['create_missing_terms'] );
		$new['debug_logging']        = ! empty( $in['debug_logging'] );

		$fb_id = isset( $in['fallback_profile'] ) ? sanitize_key( (string) $in['fallback_profile'] ) : '';
		$new['fallback_profile'] = ( '' !== $fb_id && ( new ProviderRepository() )->get( $fb_id ) ) ? $fb_id : '';
		$new['fallback_enabled'] = ! empty( $in['fallback_enabled'] ) && '' !== $new['fallback_profile'];

		Settings::update( $new );
		if ( $errors ) {
			Ui::flash( 'error', implode( ' ', $errors ) . ' ' . __( 'Other settings were saved.', 'bongo-world-ai-product-generator' ) );
		} else {
			Ui::flash( 'success', __( 'Settings saved.', 'bongo-world-ai-product-generator' ) );
		}
		Ui::redirect( 'bwaipg-settings' );
	}

	public function render(): void {
		if ( ! current_user_can( Capabilities::MANAGE ) ) {
			Ui::deny();
		}
		$s        = Settings::all();
		$profiles = ( new ProviderRepository() )->all();
		$detected = function_exists( 'wc_get_attribute_taxonomies' ) ? ( new AttributeService() )->report() : array();
		$globals  = function_exists( 'wc_get_attribute_taxonomies' ) ? wc_get_attribute_taxonomies() : array();
		$lines    = '';
		foreach ( (array) $s['type_codes'] as $label => $code ) {
			$lines .= $label . '|' . $code . "\n";
		}
		?>
		<div class="wrap bwaipg-wrap" id="bwaipg-settings">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Settings', 'bongo-world-ai-product-generator' ); ?></h1>
			<hr class="wp-header-end">
			<?php Ui::render_flash(); ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="bwaipg_save_settings">
				<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( self::NONCE ) ); ?>">
				<table class="form-table" role="presentation">
					<tr><th scope="row"><?php esc_html_e( 'Automatic Publish', 'bongo-world-ai-product-generator' ); ?></th><td>
						<label><input type="checkbox" disabled> <?php esc_html_e( 'OFF (locked)', 'bongo-world-ai-product-generator' ); ?></label>
						<p class="description"><?php esc_html_e( 'Version 1 never publishes automatically. Publishing always needs your explicit click and the publish capability.', 'bongo-world-ai-product-generator' ); ?></p>
					</td></tr>
					<tr><th scope="row"><label for="bwaipg-sku-pattern"><?php esc_html_e( 'SKU Pattern', 'bongo-world-ai-product-generator' ); ?></label></th><td>
						<input type="text" name="sku_pattern" id="bwaipg-sku-pattern" class="regular-text code" value="<?php echo esc_attr( (string) $s['sku_pattern'] ); ?>">
						<p class="description"><?php esc_html_e( 'Tokens: {TYPE} {YYMM} {SEQUENCE}. Example result: BW-HIJ-2609-001. SKUs are generated by code, never by AI, and checked for uniqueness before save.', 'bongo-world-ai-product-generator' ); ?></p>
					</td></tr>
					<tr><th scope="row"><label for="bwaipg-type-codes"><?php esc_html_e( 'Product Types & SKU codes', 'bongo-world-ai-product-generator' ); ?></label></th><td>
						<textarea name="type_codes" id="bwaipg-type-codes" rows="7" class="regular-text code"><?php echo esc_textarea( $lines ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One per line: Label|CODE (max 4 letters/numbers).', 'bongo-world-ai-product-generator' ); ?></p>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Attribute mapping', 'bongo-world-ai-product-generator' ); ?></th><td>
						<table class="widefat striped bwaipg-table">
							<thead><tr><th><?php esc_html_e( 'Locked attribute', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'Use store attribute', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'Currently resolves to', 'bongo-world-ai-product-generator' ); ?></th></tr></thead>
							<tbody>
							<?php foreach ( Rules::ATTRIBUTES as $k => $label ) : ?>
								<tr>
									<td><?php echo esc_html( $label ); ?></td>
									<td>
										<select name="attribute_map[<?php echo esc_attr( $k ); ?>]" aria-label="<?php echo esc_attr( $label ); ?>">
											<option value="auto" <?php selected( $s['attribute_map'][ $k ], 'auto' ); ?>><?php esc_html_e( 'Auto-detect', 'bongo-world-ai-product-generator' ); ?></option>
											<option value="local" <?php selected( $s['attribute_map'][ $k ], 'local' ); ?>><?php esc_html_e( 'Custom (local) attribute', 'bongo-world-ai-product-generator' ); ?></option>
											<?php foreach ( $globals as $g ) : ?>
												<option value="<?php echo esc_attr( $g->attribute_name ); ?>" <?php selected( $s['attribute_map'][ $k ], $g->attribute_name ); ?>><?php echo esc_html( $g->attribute_label . ' (pa_' . $g->attribute_name . ')' ); ?></option>
											<?php endforeach; ?>
										</select>
									</td>
									<td><?php echo ! empty( $detected[ $k ] ) ? '✔ <code>' . esc_html( $detected[ $k ] ) . '</code>' : '⚠ ' . esc_html__( 'No global attribute - will be saved as a custom attribute', 'bongo-world-ai-product-generator' ); ?></td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
						<p class="description"><?php esc_html_e( 'The plugin reads your real store attributes; nothing is assumed. Review this table before the first save.', 'bongo-world-ai-product-generator' ); ?></p>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Attribute terms', 'bongo-world-ai-product-generator' ); ?></th><td>
						<label><input type="checkbox" name="create_missing_terms" value="1" <?php checked( ! empty( $s['create_missing_terms'] ) ); ?>> <?php esc_html_e( 'Create a missing term when the user has permission (existing terms are always reused, case-insensitive)', 'bongo-world-ai-product-generator' ); ?></label>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Automatic provider fallback', 'bongo-world-ai-product-generator' ); ?></th><td>
						<label><input type="checkbox" name="fallback_enabled" value="1" <?php checked( ! empty( $s['fallback_enabled'] ) ); ?>> <?php esc_html_e( 'Enable (default OFF). Only used for temporary errors, never for key/config errors.', 'bongo-world-ai-product-generator' ); ?></label><br>
						<select name="fallback_profile" aria-label="<?php esc_attr_e( 'Fallback provider', 'bongo-world-ai-product-generator' ); ?>">
							<option value=""><?php esc_html_e( '— none —', 'bongo-world-ai-product-generator' ); ?></option>
							<?php foreach ( $profiles as $pid => $p ) : ?>
								<option value="<?php echo esc_attr( (string) $pid ); ?>" <?php selected( (string) $s['fallback_profile'], (string) $pid ); ?>><?php echo esc_html( $p['display_name'] ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'This can spend money on a second provider, which is why it is off by default.', 'bongo-world-ai-product-generator' ); ?></p>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Debug logging', 'bongo-world-ai-product-generator' ); ?></th><td>
						<label><input type="checkbox" name="debug_logging" value="1" <?php checked( ! empty( $s['debug_logging'] ) ); ?>> <?php esc_html_e( 'Enable verbose debug entries (default OFF). Secrets, headers and prompts are never logged.', 'bongo-world-ai-product-generator' ); ?></label>
					</td></tr>
				</table>
				<?php submit_button( __( 'Save Settings', 'bongo-world-ai-product-generator' ) ); ?>
			</form>
		</div>
		<?php
	}
}
