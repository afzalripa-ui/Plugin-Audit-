<?php
namespace BongoWorld\AIProductGenerator\Admin;

use BongoWorld\AIProductGenerator\History\GenerationRepository;
use BongoWorld\AIProductGenerator\Includes\Capabilities;

defined( 'ABSPATH' ) || exit;

final class HistoryPage {
	public function render(): void {
		if ( ! current_user_can( Capabilities::MANAGE ) ) {
			Ui::deny();
		}
		$repo     = new GenerationRepository();
		$per_page = 20;
		$paged    = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore
		$rows     = $repo->table_exists() ? $repo->list( $paged, $per_page ) : array();
		$total    = $repo->table_exists() ? $repo->count() : 0;
		$pages    = max( 1, (int) ceil( $total / $per_page ) );
		?>
		<div class="wrap bwaipg-wrap" id="bwaipg-history">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Generation History', 'bongo-world-ai-product-generator' ); ?></h1>
			<hr class="wp-header-end">
			<p class="description"><?php esc_html_e( 'Audit trail only: no API keys, prompts or customer data are stored here.', 'bongo-world-ai-product-generator' ); ?></p>
			<table class="widefat striped bwaipg-table">
				<thead><tr>
					<th><?php esc_html_e( 'Date', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'User', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'Provider', 'bongo-world-ai-product-generator' ); ?></th>
					<th><?php esc_html_e( 'Model', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'Operation', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'Status', 'bongo-world-ai-product-generator' ); ?></th>
					<th><?php esc_html_e( 'Product', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'Error', 'bongo-world-ai-product-generator' ); ?></th><th><?php esc_html_e( 'Tokens', 'bongo-world-ai-product-generator' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="9"><?php esc_html_e( 'No generations yet.', 'bongo-world-ai-product-generator' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $rows as $r ) : ?>
					<?php
					$user   = get_userdata( (int) $r['user_id'] );
					$usage  = json_decode( (string) $r['usage_json'], true );
					$tokens = is_array( $usage ) ? ( $usage['total_tokens'] ?? ( ( $usage['prompt_tokens'] ?? 0 ) + ( $usage['completion_tokens'] ?? 0 ) ) ) : 0;
					$status = (string) $r['status'];
					$icon   = 'success' === $status ? '✔' : ( in_array( $status, array( 'failed', 'validation_failed' ), true ) ? '✖' : '●' );
					?>
					<tr>
						<td><?php echo esc_html( get_date_from_gmt( (string) $r['created_at'], 'Y-m-d H:i' ) ); ?></td>
						<td><?php echo esc_html( $user ? $user->display_name : '—' ); ?></td>
						<td><?php echo esc_html( (string) $r['provider_name'] ); ?></td>
						<td><code><?php echo esc_html( (string) $r['model'] ); ?></code></td>
						<td><?php echo esc_html( (string) $r['operation'] ); ?></td>
						<td><?php echo esc_html( $icon . ' ' . $status ); ?></td>
						<td><?php echo (int) $r['product_id'] > 0 ? '<a href="' . esc_url( (string) get_edit_post_link( (int) $r['product_id'], 'raw' ) ) . '">#' . (int) $r['product_id'] . '</a>' : '—'; ?></td>
						<td><?php echo esc_html( '' !== (string) $r['error_type'] ? (string) $r['error_type'] : '—' ); ?></td>
						<td><?php echo $tokens ? esc_html( (string) (int) $tokens ) : '—'; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php if ( $pages > 1 ) : ?>
				<div class="tablenav"><div class="tablenav-pages">
					<?php echo wp_kses_post( (string) paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $paged, 'total' => $pages ) ) ); ?>
				</div></div>
			<?php endif; ?>
		</div>
		<?php
	}
}
