<?php
namespace BongoWorld\AIProductGenerator\Admin;

use BongoWorld\AIProductGenerator\Includes\Capabilities;
use BongoWorld\AIProductGenerator\Includes\Rules;

defined( 'ABSPATH' ) || exit;

final class AboutPage {
	public function render(): void {
		if ( ! current_user_can( Capabilities::GENERATE ) ) {
			Ui::deny();
		}
		$done = array(
			__( 'Admin menu with 6 pages; all navigable with no API key', 'bongo-world-ai-product-generator' ),
			__( 'Generator UI: product info, store info, 5 image slots, provider selector, Free-mode prompt + JSON import, API generate button, editable result with edit tracking, validation panel, Save as Draft / Save & Publish', 'bongo-world-ai-product-generator' ),
			__( 'Provider profiles (OpenAI-Compatible / Custom REST), key status via wp-config constant, Test Connection, active provider, per-provider request limits', 'bongo-world-ai-product-generator' ),
			__( 'Validator / quality gate, SKU and slug services, duplicate warning', 'bongo-world-ai-product-generator' ),
			__( 'ProductService (WooCommerce CRUD), Attribute / Tag / Stock / Image services, image metadata writer, Rank Math adapter', 'bongo-world-ai-product-generator' ),
			__( 'Generation history table + page, plugin event log, optional provider fallback (OFF by default)', 'bongo-world-ai-product-generator' ),
		);
		$todo = array(
			__( 'Field-level regeneration and the previous / new / current difference view (only "Regenerate All" exists)', 'bongo-world-ai-product-generator' ),
			__( 'AI image-metadata generation from real images (vision) and per-slot image regeneration', 'bongo-world-ai-product-generator' ),
			__( 'Test Text Generation / Test Structured Output / Test Image Input buttons (only Test Connection exists)', 'bongo-world-ai-product-generator' ),
			__( 'Estimated-budget tracking, max-image-calls enforcement, model listing', 'bongo-world-ai-product-generator' ),
			__( 'Per-step retry (Retry Save re-runs the full save on the same product - no duplicate is created)', 'bongo-world-ai-product-generator' ),
			__( 'Bangla translation files (.po/.mo)', 'bongo-world-ai-product-generator' ),
			__( 'Automated tests. None of this code has been tested on a live site yet.', 'bongo-world-ai-product-generator' ),
		);
		?>
		<div class="wrap bwaipg-wrap" id="bwaipg-about">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'About', 'bongo-world-ai-product-generator' ); ?></h1>
			<hr class="wp-header-end">
			<table class="form-table" role="presentation">
				<tr><th scope="row"><?php esc_html_e( 'Plugin', 'bongo-world-ai-product-generator' ); ?></th><td>Bongo World AI Product Generator <?php echo esc_html( BWAIPG_VERSION ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Prompt version', 'bongo-world-ai-product-generator' ); ?></th><td><code><?php echo esc_html( Rules::PROMPT_VERSION ); ?></code></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Principle', 'bongo-world-ai-product-generator' ); ?></th><td><?php esc_html_e( 'AI proposes. Code validates. A human approves. WooCommerce saves.', 'bongo-world-ai-product-generator' ); ?></td></tr>
			</table>
			<h2><?php esc_html_e( 'Written in this build (not yet tested on a live site)', 'bongo-world-ai-product-generator' ); ?></h2>
			<ul class="bwaipg-list"><?php foreach ( $done as $d ) : ?><li>◐ <?php echo esc_html( $d ); ?></li><?php endforeach; ?></ul>
			<h2><?php esc_html_e( 'Not implemented yet', 'bongo-world-ai-product-generator' ); ?></h2>
			<ul class="bwaipg-list"><?php foreach ( $todo as $d ) : ?><li>✖ <?php echo esc_html( $d ); ?></li><?php endforeach; ?></ul>
		</div>
		<?php
	}
}
