<?php
namespace BongoWorld\AIProductGenerator\Admin;

use BongoWorld\AIProductGenerator\Includes\Capabilities;

defined( 'ABSPATH' ) || exit;

final class Menu {
	const TOP = 'bwaipg';

	public function register(): void {
		add_action( 'admin_menu', array( $this, 'add_menus' ) );
	}

	public function add_menus(): void {
		add_menu_page( __( 'Bongo World AI', 'bongo-world-ai-product-generator' ), __( 'Bongo World AI', 'bongo-world-ai-product-generator' ), Capabilities::GENERATE, self::TOP, array( new GeneratorPage(), 'render' ), 'dashicons-lightbulb', 56 );
		$subs = array(
			array( self::TOP, __( 'AI Product Generator', 'bongo-world-ai-product-generator' ), Capabilities::GENERATE, array( new GeneratorPage(), 'render' ) ),
			array( 'bwaipg-providers', __( 'AI Providers', 'bongo-world-ai-product-generator' ), Capabilities::MANAGE, array( new ProviderPage(), 'render' ) ),
			array( 'bwaipg-history', __( 'Generation History', 'bongo-world-ai-product-generator' ), Capabilities::MANAGE, array( new HistoryPage(), 'render' ) ),
			array( 'bwaipg-settings', __( 'Settings', 'bongo-world-ai-product-generator' ), Capabilities::MANAGE, array( new SettingsPage(), 'render' ) ),
			array( 'bwaipg-diagnostics', __( 'Diagnostics', 'bongo-world-ai-product-generator' ), Capabilities::MANAGE, array( new DiagnosticsPage(), 'render' ) ),
			array( 'bwaipg-about', __( 'About', 'bongo-world-ai-product-generator' ), Capabilities::GENERATE, array( new AboutPage(), 'render' ) ),
		);
		foreach ( $subs as $s ) {
			add_submenu_page( self::TOP, $s[1], $s[1], $s[2], $s[0], $s[3] );
		}
	}
}
