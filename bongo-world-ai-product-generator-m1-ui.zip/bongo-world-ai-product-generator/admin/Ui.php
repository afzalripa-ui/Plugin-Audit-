<?php
namespace BongoWorld\AIProductGenerator\Admin;

defined( 'ABSPATH' ) || exit;

/** Tiny shared admin-UI helpers (flash notices, redirects). */
final class Ui {
	public static function flash( string $type, string $message ): void {
		set_transient( 'bwaipg_flash_' . get_current_user_id(), array( 'type' => $type, 'msg' => $message ), 60 );
	}

	public static function render_flash(): void {
		$key   = 'bwaipg_flash_' . get_current_user_id();
		$flash = get_transient( $key );
		if ( ! is_array( $flash ) ) {
			return;
		}
		delete_transient( $key );
		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( 'error' === $flash['type'] ? 'error' : 'success' ),
			esc_html( (string) $flash['msg'] )
		);
	}

	public static function redirect( string $page, array $args = array() ): void {
		wp_safe_redirect( add_query_arg( array_merge( array( 'page' => $page ), $args ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function deny(): void {
		wp_die( esc_html__( 'You do not have permission to access this page.', 'bongo-world-ai-product-generator' ), '', array( 'response' => 403 ) );
	}
}
