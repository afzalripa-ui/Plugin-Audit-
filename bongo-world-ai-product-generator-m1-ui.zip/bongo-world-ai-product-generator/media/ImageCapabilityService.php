<?php
namespace BongoWorld\AIProductGenerator\Media;

defined( 'ABSPATH' ) || exit;

/** Capability gate + non-destructive image encoding for vision-capable providers (AI image flow is NOT wired yet). */
final class ImageCapabilityService {
	const MAX_BYTES = 4194304; // 4 MB.

	public function profile_supports_images( array $profile ): bool {
		return ! empty( $profile['capabilities']['image_input'] );
	}

	/** Reads the 'large' size when available; never modifies or replaces the original. */
	public function data_uri( int $attachment_id ): ?string {
		$path = get_attached_file( $attachment_id );
		$int  = image_get_intermediate_size( $attachment_id, 'large' );
		if ( is_array( $int ) && ! empty( $int['path'] ) && $path ) {
			$cand = trailingslashit( dirname( $path ) ) . basename( $int['path'] );
			if ( is_readable( $cand ) ) {
				$path = $cand;
			}
		}
		if ( ! $path || ! is_readable( $path ) || filesize( $path ) > self::MAX_BYTES ) {
			return null;
		}
		$type = wp_check_filetype( $path );
		if ( empty( $type['type'] ) || 0 !== strpos( $type['type'], 'image/' ) ) {
			return null;
		}
		$bin = file_get_contents( $path ); // phpcs:ignore
		return false === $bin ? null : 'data:' . $type['type'] . ';base64,' . base64_encode( $bin ); // phpcs:ignore
	}
}
