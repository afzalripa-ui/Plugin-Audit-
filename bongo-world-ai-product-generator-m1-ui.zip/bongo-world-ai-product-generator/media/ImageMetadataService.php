<?php
namespace BongoWorld\AIProductGenerator\Media;

defined( 'ABSPATH' ) || exit;

/** Writes alt/title/caption/description to ONE selected attachment. Touches no other media. */
final class ImageMetadataService {
	/** @return array{ok:bool,message:string} */
	public function apply( int $attachment_id, array $meta ): array {
		if ( $attachment_id <= 0 || ! wp_attachment_is_image( $attachment_id ) ) {
			return array( 'ok' => false, 'message' => __( 'Not a valid image attachment.', 'bongo-world-ai-product-generator' ) );
		}
		if ( ! current_user_can( 'edit_post', $attachment_id ) ) {
			return array( 'ok' => false, 'message' => __( 'No permission to edit this image.', 'bongo-world-ai-product-generator' ) );
		}
		$res = wp_update_post(
			array(
				'ID'           => $attachment_id,
				'post_title'   => sanitize_text_field( (string) ( $meta['title'] ?? '' ) ),
				'post_excerpt' => sanitize_textarea_field( (string) ( $meta['caption'] ?? '' ) ),
				'post_content' => sanitize_textarea_field( (string) ( $meta['description'] ?? '' ) ),
			),
			true
		);
		if ( is_wp_error( $res ) ) {
			return array( 'ok' => false, 'message' => __( 'Image metadata could not be saved.', 'bongo-world-ai-product-generator' ) );
		}
		update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( (string) ( $meta['alt'] ?? '' ) ) );
		return array( 'ok' => true, 'message' => '' );
	}
}
