<?php
namespace BongoWorld\AIProductGenerator\Logging;

use BongoWorld\AIProductGenerator\Includes\Helpers;
use BongoWorld\AIProductGenerator\Includes\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Small ring buffer in a non-autoloaded option. Never stores secrets, headers, prompts or product notes.
 * event() = allowed audit events (spec §76). debug() = only when Debug logging is ON (default OFF).
 */
final class Logger {
	const OPTION = 'bwaipg_log';
	const MAX    = 200;

	public static function event( string $type, array $context = array() ): void {
		self::push( 'event', $type, $context );
	}

	public static function debug( string $type, array $context = array() ): void {
		if ( Settings::get( 'debug_logging', false ) ) {
			self::push( 'debug', $type, $context );
		}
	}

	public static function recent( int $limit = 50 ): array {
		$log = get_option( self::OPTION, array() );
		$log = is_array( $log ) ? $log : array();
		return array_slice( array_reverse( $log ), 0, max( 1, $limit ) );
	}

	private static function push( string $level, string $type, array $context ): void {
		$clean = array();
		foreach ( $context as $k => $v ) {
			if ( ! is_string( $k ) || preg_match( '/key|secret|token|auth|password|header|prompt|note/i', $k ) || ! is_scalar( $v ) ) {
				continue;
			}
			$clean[ $k ] = Helpers::trunc( Helpers::redact( (string) $v ), 200 );
		}
		$log   = get_option( self::OPTION, array() );
		$log   = is_array( $log ) ? $log : array();
		$log[] = array(
			't'     => time(),
			'level' => $level,
			'type'  => sanitize_key( $type ),
			'user'  => get_current_user_id(),
			'ctx'   => $clean,
		);
		if ( count( $log ) > self::MAX ) {
			$log = array_slice( $log, -self::MAX );
		}
		update_option( self::OPTION, $log, false );
	}
}
