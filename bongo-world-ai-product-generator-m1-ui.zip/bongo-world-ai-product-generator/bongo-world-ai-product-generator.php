<?php
/**
 * Plugin Name: Bongo World AI Product Generator
 * Description: Private admin plugin. AI proposes, code validates, human approves, WooCommerce saves. Provider-agnostic (OpenAI-compatible / Custom REST / Free JSON mode).
 * Version: 0.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: bongo-world-ai-product-generator
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

use BongoWorld\AIProductGenerator\Includes\Activator;
use BongoWorld\AIProductGenerator\Includes\Plugin;

define( 'BWAIPG_VERSION', '0.1.0' );
define( 'BWAIPG_FILE', __FILE__ );
define( 'BWAIPG_DIR', plugin_dir_path( __FILE__ ) );

spl_autoload_register(
	function ( $class ) {
		$prefix = 'BongoWorld\\AIProductGenerator\\';
		if ( 0 !== strpos( $class, $prefix ) ) {
			return;
		}
		$map   = array(
			'Includes'    => 'includes',
			'Admin'       => 'admin',
			'AI'          => 'ai',
			'WooCommerce' => 'woocommerce',
			'SEO'         => 'seo',
			'Media'       => 'media',
			'Security'    => 'security',
			'Logging'     => 'logging',
			'History'     => 'history',
		);
		$parts = explode( '\\', substr( $class, strlen( $prefix ) ) );
		$first = array_shift( $parts );
		if ( ! isset( $map[ $first ] ) ) {
			return;
		}
		$file = BWAIPG_DIR . $map[ $first ] . '/' . implode( '/', $parts ) . '.php';
		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
);

register_activation_hook( __FILE__, array( Activator::class, 'activate' ) );

add_action(
	'plugins_loaded',
	function () {
		Plugin::instance()->boot();
	}
);
