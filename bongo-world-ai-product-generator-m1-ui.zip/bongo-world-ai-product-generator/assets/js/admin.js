/* Bongo World AI Product Generator - admin UI (jQuery, no build step) */
(function ($) {
	'use strict';

	var cfg = window.bwaipgConfig || {};
	var T = cfg.i18n || {};
	var LB = cfg.labels || {};

	function t(k) { return Object.prototype.hasOwnProperty.call(T, k) ? T[k] : k; }
	function L(k) { return Object.prototype.hasOwnProperty.call(LB, k) ? LB[k] : k; }

	/* Safe element builder: all dynamic text goes through .text()/.val(), never innerHTML. */
	function el(tag, props, kids) {
		var $e = $(document.createElement(tag));
		if (props) {
			$.each(props, function (k, v) {
				if (k === 'text') { $e.text(v); }
				else if (k === 'class') { $e.addClass(v); }
				else { $e.attr(k, v); }
			});
		}
		if (kids) {
			$.each(Array.isArray(kids) ? kids : [kids], function (_, c) { if (c) { $e.append(c); } });
		}
		return $e;
	}

	/* One promise shape for every AJAX call: resolves with data, rejects with {code,message,...}. */
	function call(action, payload) {
		var d = $.Deferred();
		$.ajax({
			url: cfg.ajaxUrl, type: 'POST', dataType: 'json',
			data: { action: action, _wpnonce: cfg.nonce, payload: JSON.stringify(payload || {}) }
		}).done(function (r) {
			if (r && r.success) { d.resolve(r.data); }
			else { d.reject((r && r.data) ? r.data : { message: t('networkError') }); }
		}).fail(function (x) {
			var data = (x && x.responseJSON && x.responseJSON.data) ? x.responseJSON.data : { message: t('networkError') };
			d.reject(data);
		});
		return d.promise();
	}

	function getPath(o, p) {
		var parts = p.split('.');
		for (var i = 0; i < parts.length; i++) {
			if (o === null || o === undefined) { return undefined; }
			o = o[parts[i]];
		}
		return o;
	}
	function setPath(o, p, v) {
		var parts = p.split('.'), last = parts.pop();
		for (var i = 0; i < parts.length; i++) {
			if (o[parts[i]] === null || o[parts[i]] === undefined || typeof o[parts[i]] !== 'object') { o[parts[i]] = {}; }
			o = o[parts[i]];
		}
		o[last] = v;
	}
	function clone(x) { return JSON.parse(JSON.stringify(x)); }

	/* ===================================================== GENERATOR ===== */
	function initGenerator() {
		var $g = $('#bwaipg-generator');
		if (!$g.length) { return; }

		var state = { result: null, original: null, edited: {}, productId: 0, generationId: '', busy: false };

		function notice(msg, type) {
			var $n = el('div', { 'class': 'notice notice-' + (type || 'info') + ' is-dismissible' }, el('p', { text: msg }));
			$('#bwaipg-notices').empty().append($n);
			$('html, body').animate({ scrollTop: Math.max(0, $g.offset().top - 40) }, 150);
		}

		function switchTab(name) {
			$g.find('.bwaipg-tab').each(function () {
				var on = $(this).data('tab') === name;
				$(this).toggleClass('is-active', on).attr({ 'aria-selected': on ? 'true' : 'false', tabindex: on ? '0' : '-1' });
			});
			$g.find('.bwaipg-panel').each(function () { $(this).prop('hidden', $(this).data('panel') !== name); });
		}
		$g.on('click', '.bwaipg-tab, .bwaipg-goto', function () { switchTab($(this).data('tab')); });

		/* ---- collectors (store data is kept apart from AI content) ---- */
		function collectInfo() {
			var info = { product_type: $.trim($('#bwaipg-product-type').val()), notes: $('#bwaipg-notes').val(), attributes: {} };
			$.each(cfg.attributes, function (k) { info.attributes[k] = $.trim($('#bwaipg-attr-' + k).val()); });
			return info;
		}
		function collectStore() {
			return {
				regular_price: $('#bwaipg-regular-price').val(), sale_price: $('#bwaipg-sale-price').val(),
				manage_stock: $('#bwaipg-manage-stock').is(':checked'), stock_quantity: $('#bwaipg-stock-qty').val(),
				stock_status: $('#bwaipg-stock-status').val(), categories: $('#bwaipg-categories').val() || [],
				shipping_class: $('#bwaipg-shipping-class').val(), weight: $('#bwaipg-weight').val(),
				length: $('#bwaipg-length').val(), width: $('#bwaipg-width').val(), height: $('#bwaipg-height').val()
			};
		}
		function collectImages() {
			var m = {};
			$g.find('.bwaipg-slot').each(function () { m[$(this).data('slot')] = parseInt($(this).find('.bwaipg-slot-id').val(), 10) || 0; });
			return m;
		}
		function editedPaths() {
			var out = [];
			$.each(state.edited, function (p, on) { if (on) { out.push(p); } });
			return out;
		}
		function basePayload() {
			return { info: collectInfo(), store: collectStore(), images: collectImages(), edited: editedPaths() };
		}

		function setBusy(on, $btn, label) {
			state.busy = on;
			$g.find('#bwaipg-generate, #bwaipg-regenerate-all, #bwaipg-import-json, #bwaipg-save-draft, #bwaipg-save-publish, #bwaipg-validate-btn').prop('disabled', on);
			if (!on && !cfg.canPublish) { $('#bwaipg-save-publish').prop('disabled', true); }
			$g.attr('aria-busy', on ? 'true' : 'false');
			if ($btn && $btn.length) {
				if (on) { $btn.data('label', $btn.text()).text(label || t('working')); }
				else if ($btn.data('label')) { $btn.text($btn.data('label')); }
			}
		}

		/* ---- image slots (WordPress media library) ---- */
		$g.on('click', '.bwaipg-slot-select', function (e) {
			e.preventDefault();
			if (typeof wp === 'undefined' || !wp.media) { return; }
			var $slot = $(this).closest('.bwaipg-slot');
			var frame = wp.media({ title: t('selectImage'), library: { type: 'image' }, multiple: false });
			frame.on('select', function () {
				var a = frame.state().get('selection').first().toJSON();
				var url = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
				$slot.find('.bwaipg-slot-id').val(a.id);
				$slot.find('.bwaipg-slot-preview').attr('src', url).prop('hidden', false);
				$slot.find('.bwaipg-slot-remove').prop('hidden', false);
			});
			frame.open();
		});
		$g.on('click', '.bwaipg-slot-remove', function () {
			var $slot = $(this).closest('.bwaipg-slot');
			$slot.find('.bwaipg-slot-id').val(0);
			$slot.find('.bwaipg-slot-preview').attr('src', '').prop('hidden', true);
			$(this).prop('hidden', true);
		});

		/* ---- provider selector ---- */
		function onProviderChange() {
			var $o = $('#bwaipg-provider-select option:selected');
			var manual = $o.val() === 'manual';
			$g.find('.bwaipg-mode-free').prop('hidden', !manual);
			$g.find('.bwaipg-mode-api').prop('hidden', manual);
			$('#bwaipg-regenerate-all').prop('hidden', manual);
			$('#bwaipg-provider-info').text(manual ? t('freeModeInfo') : ($o.data('info') || ''));
		}
		$('#bwaipg-provider-select').on('change', onProviderChange);

		/* ---- Free mode ---- */
		function copyText(text) {
			var $ta = $('#bwaipg-prompt-out');
			$ta.val(text).prop('hidden', false);
			if (navigator.clipboard && navigator.clipboard.writeText) {
				return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return false; });
			}
			$ta[0].select();
			var ok = false;
			try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
			return $.Deferred().resolve(ok).promise();
		}
		$('#bwaipg-copy-prompt').on('click', function () {
			var info = collectInfo();
			if (!info.product_type) { notice(t('needType'), 'error'); switchTab('info'); return; }
			call('bwaipg_get_prompt', { info: info }).done(function (d) {
				copyText(d.prompt).then(function (ok) { notice(ok ? t('promptCopied') : t('promptShown'), 'success'); });
			}).fail(function (e) { notice(e.message || t('networkError'), 'error'); });
		});
		$('#bwaipg-import-json').on('click', function () {
			if (state.busy) { return; }
			var json = $('#bwaipg-json-in').val();
			if ($.trim(json) === '') { notice(t('pasteJson'), 'error'); return; }
			var $b = $(this);
			setBusy(true, $b, t('working'));
			call('bwaipg_import_json', $.extend(basePayload(), { json: json }))
				.done(function (d) { state.generationId = d.generation_id || ''; acceptResult(d.data, d.validation); })
				.fail(function (e) { notice(e.message || t('networkError'), 'error'); })
				.always(function () { setBusy(false, $b); });
		});

		/* ---- API mode ---- */
		function runGenerate($btn) {
			if (state.busy) { return; }
			var p = basePayload();
			if (!p.info.product_type) { notice(t('needType'), 'error'); switchTab('info'); return; }
			p.profile_id = $('#bwaipg-provider-select').val();
			setBusy(true, $btn, t('generating'));
			call('bwaipg_generate', p)
				.done(function (d) { state.generationId = d.generation_id || ''; acceptResult(d.data, d.validation); })
				.fail(function (e) { notice(e.message || t('networkError'), 'error'); })
				.always(function () { setBusy(false, $btn); });
		}
		$('#bwaipg-generate').on('click', function () { runGenerate($(this)); });
		$('#bwaipg-regenerate-all').on('click', function () { runGenerate($(this)); });

		/* ---- result handling: edited fields survive regeneration unless told otherwise ---- */
		function acceptResult(data, validation) {
			var keep = [];
			if (state.result && !$('#bwaipg-replace-edited').is(':checked')) {
				$.each(state.edited, function (p, on) { if (on) { keep.push(p); } });
			}
			var next = clone(data);
			$.each(keep, function (_, p) { setPath(next, p, getPath(state.result, p)); });
			state.original = clone(data);
			state.result = next;
			state.edited = {};
			$.each(keep, function (_, p) { state.edited[p] = true; });
			renderResult();
			renderValidation(validation);
			switchTab('result');
		}

		function ensureShape(r) {
			r.product = r.product || {};
			r.attributes = r.attributes || {};
			r.images = r.images || {};
			$.each(cfg.attributes, function (k) {
				if (!r.attributes[k] || typeof r.attributes[k] !== 'object') { r.attributes[k] = { value: '', source: 'UNKNOWN' }; }
			});
			$.each(cfg.slots, function (k) {
				if (!r.images[k] || typeof r.images[k] !== 'object') { r.images[k] = { alt: '', title: '', caption: '', description: '', basis: 'TEMPLATE_BASED' }; }
			});
			if (!Array.isArray(r.product.tags)) { r.product.tags = []; }
			if (!Array.isArray(r.product.description_sections)) { r.product.description_sections = []; }
		}

		function badge(path) { return el('span', { 'class': 'bwaipg-badge', text: t('edited') }).prop('hidden', !state.edited[path]); }

		function markEdited(path, $input, $badge) {
			var changed = JSON.stringify(getPath(state.result, path)) !== JSON.stringify(getPath(state.original, path));
			state.edited[path] = changed;
			if ($input) { $input.toggleClass('bwaipg-edited', changed); }
			if ($badge) { $badge.prop('hidden', !changed); }
		}

		function fieldRow(path, label, multiline) {
			var id = 'bwaipg-f-' + path.replace(/\./g, '-');
			var $input = multiline ? el('textarea', { id: id, rows: 3, 'class': 'large-text' }) : el('input', { type: 'text', id: id, 'class': 'large-text' });
			var $badge = badge(path);
			var $count = el('span', { 'class': 'bwaipg-count' });
			$input.val(getPath(state.result, path) || '').toggleClass('bwaipg-edited', !!state.edited[path]);
			function upd() { $count.text($input.val().length + ' ' + t('chars')); }
			upd();
			$input.on('input', function () {
				setPath(state.result, path, $input.val());
				markEdited(path, $input, $badge);
				upd();
			});
			return el('div', { 'class': 'bwaipg-row' }, [el('label', { 'for': id, text: label }), $input, $badge, $count]);
		}

		function tagsRow() {
			var path = 'product.tags', id = 'bwaipg-f-product-tags';
			var $in = el('input', { type: 'text', id: id, 'class': 'large-text', 'aria-describedby': id + '-help' });
			var $badge = badge(path);
			var $count = el('span', { 'class': 'bwaipg-count' });
			$in.val((getPath(state.result, path) || []).join(', ')).toggleClass('bwaipg-edited', !!state.edited[path]);
			function upd() { $count.text(getPath(state.result, path).length + ' ' + L('tags')); }
			upd();
			$in.on('input', function () {
				var parts = $.grep($.map($in.val().split(/[,،]/), function (x) { return $.trim(x); }), function (x) { return x !== ''; });
				setPath(state.result, path, parts);
				markEdited(path, $in, $badge);
				upd();
			});
			return el('div', { 'class': 'bwaipg-row' }, [el('label', { 'for': id, text: L('tags') }), $in, $badge, $count, el('p', { id: id + '-help', 'class': 'description', text: t('tagsHelp') })]);
		}

		function sectionsBlock() {
			var path = 'product.description_sections';
			var $card = el('fieldset', { 'class': 'bwaipg-card' }, el('legend', { text: t('description') }));
			var $badge = badge(path);
			var $count = el('span', { 'class': 'bwaipg-count' });
			var $list = el('div', { 'class': 'bwaipg-sections' });

			function sectionRow(s) {
				var $h = el('input', { type: 'text', 'class': 'bwaipg-sec-h', placeholder: t('heading'), 'aria-label': t('heading') }).val(s.heading || '');
				var $p = el('textarea', { rows: 6, 'class': 'bwaipg-sec-p', placeholder: t('paragraphs'), 'aria-label': t('paragraphs') }).val((s.paragraphs || []).join('\n\n'));
				var $x = el('button', { type: 'button', 'class': 'button-link button-link-delete bwaipg-sec-del', text: t('removeSection') });
				return el('div', { 'class': 'bwaipg-section' }, [$h, $p, $x]);
			}
			function sync() {
				var arr = [], words = 0;
				$list.children('.bwaipg-section').each(function () {
					var h = $.trim($(this).find('.bwaipg-sec-h').val());
					var paras = $.map($(this).find('.bwaipg-sec-p').val().split(/\n\s*\n/), function (x) { x = $.trim(x); return x === '' ? null : x; });
					$.each(paras, function (_, x) { words += x.split(/\s+/).length; });
					arr.push({ heading: h, paragraphs: paras });
				});
				setPath(state.result, path, arr);
				var changed = JSON.stringify(arr) !== JSON.stringify(getPath(state.original, path));
				state.edited[path] = changed;
				$badge.prop('hidden', !changed);
				$count.text(words + ' ' + L('words'));
			}
			$.each(getPath(state.result, path) || [], function (_, s) { $list.append(sectionRow(s)); });
			$list.on('input', '.bwaipg-sec-h, .bwaipg-sec-p', sync);
			$list.on('click', '.bwaipg-sec-del', function () { $(this).closest('.bwaipg-section').remove(); sync(); });
			var $add = el('button', { type: 'button', 'class': 'button', text: t('addSection') }).on('click', function () {
				$list.append(sectionRow({ heading: '', paragraphs: [] })); sync();
			});
			var initialWords = 0;
			$.each(getPath(state.result, path) || [], function (_, s) {
				$.each(s.paragraphs || [], function (__, para) { initialWords += $.trim(String(para)).split(/\s+/).length; });
			});
			$count.text(initialWords + ' ' + L('words'));
			$card.append($list, $add, $badge, $count);
			return $card;
		}

		function attributesBlock() {
			var $card = el('fieldset', { 'class': 'bwaipg-card' }, el('legend', { text: t('attributes') }));
			$.each(cfg.attributes, function (key, label) {
				var vpath = 'attributes.' + key + '.value', spath = 'attributes.' + key + '.source';
				var vid = 'bwaipg-f-attr-' + key;
				var $val = el('input', { type: 'text', id: vid, 'class': 'regular-text' }).val(getPath(state.result, vpath) || '');
				var $src = el('select', { 'aria-label': label + ' - ' + L('source') });
				$.each(cfg.sources, function (_, s) { $src.append(el('option', { value: s, text: s })); });
				$src.val(getPath(state.result, spath) || 'UNKNOWN');
				var $badge = badge(vpath);
				$val.toggleClass('bwaipg-edited', !!state.edited[vpath]);
				$val.on('input', function () {
					var v = $val.val();
					setPath(state.result, vpath, v);
					var orig = getPath(state.original, vpath), origSrc = getPath(state.original, spath);
					var src = (orig !== undefined && v === orig) ? (origSrc || 'UNKNOWN') : ($.trim(v) === '' ? 'UNKNOWN' : 'USER_PROVIDED');
					setPath(state.result, spath, src);
					$src.val(src);
					markEdited(vpath, $val, $badge);
					state.edited[spath] = state.edited[vpath];
				});
				$src.on('change', function () {
					setPath(state.result, spath, $src.val());
					state.edited[spath] = JSON.stringify(getPath(state.original, spath)) !== JSON.stringify($src.val());
				});
				$card.append(el('div', { 'class': 'bwaipg-attr-row' }, [el('label', { 'for': vid, text: label }), $val, $src, $badge]));
			});
			return $card;
		}

		function imagesBlock() {
			var $card = el('fieldset', { 'class': 'bwaipg-card' }, el('legend', { text: t('imageMeta') }));
			$.each(cfg.slots, function (slot, label) {
				var $s = el('fieldset', { 'class': 'bwaipg-section' }, el('legend', { text: label }));
				$.each(['alt', 'title', 'caption', 'description'], function (_, f) {
					$s.append(fieldRow('images.' + slot + '.' + f, L(f), f === 'caption' || f === 'description'));
				});
				$s.append(el('p', { 'class': 'description', text: L('basis') + ': ' + (getPath(state.result, 'images.' + slot + '.basis') || '') }));
				$card.append($s);
			});
			return $card;
		}

		function renderResult() {
			var $root = $('#bwaipg-result-root').empty();
			if (!state.result) { $root.append(el('p', { text: t('noResult') })); return; }
			ensureShape(state.result);
			var $prod = el('fieldset', { 'class': 'bwaipg-card' }, el('legend', { text: t('productContent') }));
			$prod.append(fieldRow('product.name', L('name'), false));
			$prod.append(fieldRow('product.seo_title', L('seo_title'), false));
			$prod.append(fieldRow('product.focus_keyword', L('focus_keyword'), false));
			$prod.append(fieldRow('product.focus_keyword_slug_source', L('focus_keyword_slug_source'), false));
			$prod.append(fieldRow('product.slug', L('slug'), false));
			$prod.append(fieldRow('product.short_description', L('short_description'), true));
			$prod.append(fieldRow('product.meta_description', L('meta_description'), true));
			$prod.append(tagsRow());
			$root.append($prod, sectionsBlock(), attributesBlock(), imagesBlock());
		}

		/* ---- validation panel: text + icon, never colour alone ---- */
		function renderValidation(v) {
			var $box = $('#bwaipg-validation').empty();
			if (!v) { return; }
			$box.append(el('p', { 'class': 'bwaipg-banner ' + (v.ready ? 'is-ready' : 'is-blocked'), role: 'status', text: (v.ready ? '✔ ' + t('ready') : '✖ ' + t('notReady')) }));
			if (v.sku_preview) { $box.append(el('p', { 'class': 'description', text: t('skuPreview') + ': ' + v.sku_preview })); }
			var groups = [['errors', 'error', '✖', 'is-error'], ['warnings', 'warning', '⚠', 'is-warning'], ['passes', 'pass', '✔', 'is-pass']];
			$.each(groups, function (_, g) {
				var items = v[g[0]] || [];
				if (!items.length) { return; }
				var $ul = el('ul', { 'class': 'bwaipg-checks' });
				$.each(items, function (__, it) {
					$ul.append(el('li', { 'class': g[3] }, [el('strong', { text: g[2] + ' ' + t(g[1]) + ': ' }), document.createTextNode(it.message)]));
				});
				$box.append($ul);
			});
		}
		$('#bwaipg-validate-btn').on('click', function () {
			if (state.busy) { return; }
			if (!state.result) { notice(t('noResult'), 'error'); return; }
			var $b = $(this);
			setBusy(true, $b, t('working'));
			call('bwaipg_validate', $.extend(basePayload(), { result: state.result, product_id: state.productId, mode: 'draft' }))
				.done(function (d) { renderValidation(d.validation); })
				.fail(function (e) { notice(e.message || t('networkError'), 'error'); })
				.always(function () { setBusy(false, $b); });
		});

		/* ---- save ---- */
		function stepLabel(name) {
			if (name === 'product') { return L('stepProduct'); }
			if (name === 'rank_math') { return 'Rank Math'; }
			if (name.indexOf('image_') === 0) { var s = name.substring(6); return (cfg.slots[s] || s) + ' - ' + L('stepImage'); }
			return name;
		}
		function onSaved(d, mode) {
			state.productId = d.product_id;
			var $out = $('#bwaipg-save-output').empty();
			$out.append(el('p', null, [el('strong', { text: (mode === 'publish' ? t('savedPublish') : t('savedDraft')) + ' ' }), d.edit_link ? el('a', { href: d.edit_link, target: '_blank', rel: 'noopener', text: t('editProduct') }) : null]));
			if (d.sku) { $out.append(el('p', { 'class': 'description', text: 'SKU: ' + d.sku + '  |  Slug: ' + d.slug })); }
			var $ul = el('ul', { 'class': 'bwaipg-checks' });
			$.each(d.steps || {}, function (name, s) {
				var cls = s.status === 'ok' ? 'is-pass' : (s.status === 'failed' ? 'is-error' : 'is-warning');
				var icon = s.status === 'ok' ? '✔ ' + t('stepOk') : (s.status === 'failed' ? '✖ ' + t('stepFailed') : '⚠ ' + t('stepSkipped'));
				$ul.append(el('li', { 'class': cls }, [el('strong', { text: stepLabel(name) + ': ' + icon }), document.createTextNode(s.message ? ' - ' + s.message : '')]));
			});
			$out.append($ul);
			$.each(d.warnings || [], function (_, w) { $out.append(el('p', { 'class': 'bwaipg-note', text: '⚠ ' + w })); });
			if (d.partial) {
				$out.append(el('p', { text: t('partial') }));
				$out.append(el('button', { type: 'button', 'class': 'button bwaipg-retry', text: t('retrySave') }).data('mode', mode));
			}
			switchTab('validate');
		}
		function showDuplicates(list, mode) {
			var $d = $('#bwaipg-dup').empty();
			var $box = el('div', { 'class': 'notice notice-warning inline' });
			$box.append(el('p', null, el('strong', { text: t('dupTitle') })));
			var $ul = el('ul');
			$.each(list, function (_, it) {
				$ul.append(el('li', null, [document.createTextNode(it.title + ' (' + it.status + ') '), it.edit_link ? el('a', { href: it.edit_link, target: '_blank', rel: 'noopener', text: t('reviewExisting') }) : null]));
			});
			$box.append($ul);
			$box.append(el('p', null, [
				el('button', { type: 'button', 'class': 'button button-primary bwaipg-dup-new', text: t('createNew') }).data('mode', mode), ' ',
				el('button', { type: 'button', 'class': 'button bwaipg-dup-cancel', text: t('cancel') })
			]));
			$d.append($box);
		}
		function onSaveFail(e, mode) {
			if (e.validation) { renderValidation(e.validation); }
			if (e.code === 'duplicate_found') { showDuplicates(e.duplicates || [], mode); switchTab('validate'); return; }
			if (e.validation) { switchTab('validate'); }
			notice(e.message || t('networkError'), 'error');
			if (!e.validation) {
				$('#bwaipg-save-output').empty().append(el('p', null, el('button', { type: 'button', 'class': 'button bwaipg-retry', text: t('retrySave') }).data('mode', mode)));
			}
		}
		function save(mode, confirmDup) {
			if (state.busy) { return; }
			if (!state.result) { notice(t('noResult'), 'error'); return; }
			var $b = mode === 'publish' ? $('#bwaipg-save-publish') : $('#bwaipg-save-draft');
			$('#bwaipg-dup').empty();
			setBusy(true, $b, t('working'));
			call('bwaipg_save', $.extend(basePayload(), { result: state.result, mode: mode, product_id: state.productId, confirm_duplicate: !!confirmDup, generation_id: state.generationId }))
				.done(function (d) { onSaved(d, mode); })
				.fail(function (e) { onSaveFail(e, mode); })
				.always(function () { setBusy(false, $b); });
		}
		$('#bwaipg-save-draft').on('click', function () { save('draft', false); });
		$('#bwaipg-save-publish').on('click', function () { save('publish', false); });
		$g.on('click', '.bwaipg-dup-new', function () { save($(this).data('mode'), true); });
		$g.on('click', '.bwaipg-dup-cancel', function () { $('#bwaipg-dup').empty(); });
		$g.on('click', '.bwaipg-retry', function () { save($(this).data('mode'), true); });

		/* ---- init ---- */
		renderResult();
		onProviderChange();
		switchTab('info');
	}

	/* ===================================================== PROVIDERS ===== */
	function initProviders() {
		var $p = $('#bwaipg-providers');
		if (!$p.length) { return; }
		function toggleType() {
			var type = $('#bwaipg-conn-type').val();
			$p.find('.bwaipg-only-openai').prop('hidden', type !== 'openai_compatible');
			$p.find('.bwaipg-only-custom').prop('hidden', type !== 'custom_rest');
		}
		$('#bwaipg-conn-type').on('change', toggleType);
		toggleType();
		$p.on('click', '.bwaipg-test-provider', function () {
			var $b = $(this), $res = $b.closest('tr').find('.bwaipg-test-result');
			$b.prop('disabled', true);
			$res.text(' ' + t('testing'));
			call('bwaipg_provider_test', { id: $b.data('id') })
				.done(function (d) { $res.text(' ✔ ' + d.message); })
				.fail(function (e) { $res.text(' ✖ ' + (e.message || t('networkError'))); })
				.always(function () { $b.prop('disabled', false); });
		});
		$p.on('click', '.bwaipg-confirm', function (e) {
			if (!window.confirm(t('confirmDelete'))) { e.preventDefault(); }
		});
	}

	$(function () { initGenerator(); initProviders(); });
})(jQuery);
