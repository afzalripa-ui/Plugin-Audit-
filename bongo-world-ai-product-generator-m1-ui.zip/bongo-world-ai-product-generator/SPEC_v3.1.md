# Bongo World AI Product Generator — MASTER SPEC v3.1

v3.0-এর সব নিয়ম বহাল। v3.1-এ নিচের ফাঁকগুলো বন্ধ করা হয়েছে এবং সিদ্ধান্তগুলো চূড়ান্ত করা হয়েছে।

## ১. v3.0 → v3.1 পরিবর্তন (সিদ্ধান্ত)

| # | বিষয় | v3.1 সিদ্ধান্ত |
|---|---|---|
| 1 | Output JSON schema | নিচে §২-এ নির্দিষ্ট করা হলো। `ai/SchemaManager.php` একমাত্র source of truth। |
| 2 | বাংলা keyword ও slug | `focus_keyword` বাংলা/English মিশ্র হতে পারে। AI আলাদা `focus_keyword_slug_source` (Latin transliteration) দেবে। `slug` শুধু `a-z0-9-`, এবং slugified `focus_keyword_slug_source` অবশ্যই ধারণ করবে। |
| 3 | SKU race condition | Atomic DB increment (`LAST_INSERT_ID(option_value+1)`)। Counter key = type + YYMM। Save-এর সময় আবার uniqueness check। Gap গ্রহণযোগ্য। |
| 4 | API key storage | V1-এ শুধু wp-config constant বা environment variable (`BW_AIPG_API_KEY_PROFILE_{ID}`)। DB-তে key রাখা হবে না। Encrypted storage পরের version-এ। |
| 5 | SSRF | শুধু HTTPS ও port 443। DNS resolve করে private/loopback/reserved IP reject। URL-এ credential নিষেধ। `wp_safe_remote_request`, redirect = 0। |
| 6 | `OpenAIClient.php` | বাদ। HTTP transport জেনেরিক `HttpClient`, provider syntax শুধু provider class-এ। |
| 7 | Variable product | V1 = simple product, এক product = এক color। ইচ্ছাকৃত সীমা। |
| 8 | Capability default | সব provider-এ `structured_output=none`, `image_input=false`। Connection test PASS করার পরই চালু হবে। |
| 9 | Store data AI-তে যায় না | Price, stock, category, shipping ইত্যাদি prompt-এ পাঠানো হয় না (whitelist)। উত্তরে এলে validator ERROR দেয়। |
| 10 | Attribute UNKNOWN | `UNKNOWN` মানে value খালি। খালি attribute = ERROR, মানুষকে হাতে পূরণ করতে হবে। |
| 11 | Provider test | কমপক্ষে ২টি আলাদা provider + ১টি custom REST format লাগবে। আপনার দিক থেকে ২টি API key দরকার। |

## ২. AI Output JSON Schema (v3.1)

```json
{
  "schema_version": "3.1",
  "product": {
    "name": "", "seo_title": "",
    "description_sections": [ { "heading": "", "paragraphs": [""] } ],
    "short_description": "",
    "focus_keyword": "", "focus_keyword_slug_source": "", "slug": "",
    "meta_description": "", "tags": [""]
  },
  "attributes": {
    "color": {"value": "", "source": "USER_PROVIDED|IMAGE_OBSERVED|RULE_DERIVED|AI_WRITTEN|UNKNOWN"},
    "size": {}, "fabric": {}, "design": {}, "style": {}, "age_group": {}, "occasion": {}
  },
  "images": {
    "main": {"alt":"","title":"","caption":"","description":"","basis":"TEMPLATE_BASED|IMAGE_OBSERVED"},
    "back": {}, "side": {}, "fabric": {}, "front_zoom": {}
  }
}
```

- অতিরিক্ত key নিষিদ্ধ। Price, stock, category, shipping, sku কোথাও থাকলে ERROR।
- HTML ও Markdown heading (`#`) নিষিদ্ধ। Description শুধু sections হিসেবে আসবে, renderer পরে safe HTML বানাবে।
- Image `IMAGE_OBSERVED` দাবি করতে পারবে শুধু সত্যিকারের image পাঠানো হলে।

## ৩. Validator নিয়ম

**ERROR (save বন্ধ):** unknown key, খালি required field, focus keyword অনুপস্থিত (name / seo_title / short_description / meta_description), slug ফরম্যাট ভুল বা keyword-বিহীন, slug বা SKU conflict, ৭টি attribute-এর সেট ভুল বা মান খালি, user-provided fact বদলে যাওয়া, ৫টি image slot ভুল বা field খালি, raw HTML/Markdown, business data contamination।

**WARNING (দেখাতে হবে):** name 30–70 অক্ষরের বাইরে, SEO title 40–65 অক্ষরের বাইরে, meta description 110–160 অক্ষরের বাইরে, description 100–450 শব্দের বাইরে, tag 8–15 এর বাইরে বা duplicate।

কোনো field চুপচাপ "ঠিক" করা বা keyword inject করা হবে না। ব্যর্থ হলে Regenerate অথবা Manual Edit।

## ৪. স্থির নিয়ম (v3.0 থেকে অপরিবর্তিত)

- ৩টি mode: Free JSON, OpenAI-Compatible, Custom REST। তিনটিই একই Normalizer → Validator → Quality Gate → Human Review → ProductService pipeline ব্যবহার করবে।
- ৭টি attribute (Color, Size, Fabric/Material, Design, Style, Age Group, Occasion) এবং ৫টি image slot (Main, Back, Side, Fabric/Swatch, Front Zoom) লক করা।
- Price, Sale Price, Stock, Category, Shipping সবসময় মানুষের হাতে। Auto-publish ডিফল্ট OFF।
- SKU, slug sanitize, duplicate check, validation, save flow: সব code-driven।
- Hijab ও Niqab আলাদা। Chin cover থাকলে "with Chin Cover" ধরনের শব্দ, স্বয়ংক্রিয়ভাবে "Hijab & Niqab" নয়।
- Browser থেকে সরাসরি AI API call নিষেধ। API key কোথাও expose নয়। AI output untrusted data।
- Nonce + capability check, prepared query, `eval()` নিষেধ, template শুধু data substitution।
- Retry সর্বোচ্চ ২, শুধু transient failure-এ। Fallback provider ডিফল্ট OFF।
- Uninstall শুধু plugin-owned option ও table মোছে।

## ৫. Build পর্যায়

1. **Core skeleton** (এই delivery): bootstrap, Rules, Schema, Validator, Prompt, Providers, HttpClient, UrlGuard, KeyProvider, SKU, Slug।
2. **Admin UI:** Menu, Provider profiles page, Generator page, AJAX (nonce + capability + double-submit lock)।
3. **WooCommerce:** ProductService (CRUD), AttributeService, TagService, StockService, ImageService।
4. **SEO ও Media:** RankMathAdapter, ImageMetadataService।
5. **History, Cost limits, Diagnostics, Logger।**
6. **Testing:** §১১০-এর পূর্ণ তালিকা। রিপোর্টে TESTED / NOT TESTED / KNOWN LIMITATIONS আলাদা থাকবে।
