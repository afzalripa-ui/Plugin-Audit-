<?php
namespace BongoWorld\AIProductGenerator\SEO;

defined( 'ABSPATH' ) || exit;

/**
 * Optional Rank Math integration. All Rank Math knowledge lives here.
 * Uses Rank Math's post-meta keys (rank_math_title / rank_math_description / rank_math_focus_keyword).
 * Not verified against the installed Rank Math version yet - see Diagnostics.
 */
final class RankMathAdapter {
	public function is_active(): bool {
		return defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' );
	}

	public function version(): string {
		return defined( 'RANK_MATH_VERSION' ) ? (string) RANK_MATH_VERSION : '';
	}

	/** @return array{status:string,message:string} status = ok|failed|skipped */
	public function update( int $post_id, array $seo ): array {
		if ( ! $this->is_active() ) {
			return array( 'status' => 'skipped', 'message' => __( 'Rank Math is not active.', 'bongo-world-ai-product-generator' ) );
		}
		$map = array(
			'rank_math_title'         => sanitize_text_field( (string) ( $seo['seo_title'] ?? '' ) ),
			'rank_math_description'   => sanitize_text_field( (string) ( $seo['meta_description'] ?? '' ) ),
			'rank_math_focus_keyword' => sanitize_text_field( (string) ( $seo['focus_keyword'] ?? '' ) ),
		);
		foreach ( $map as $key => $val ) {
			update_post_meta( $post_id, $key, $val );
			if ( (string) get_post_meta( $post_id, $key, true ) !== $val ) {
				return array( 'status' => 'failed', 'message' => __( 'SEO metadata update needs attention.', 'bongo-world-ai-product-generator' ) );
			}
		}
		return array( 'status' => 'ok', 'message' => '' );
	}
}
