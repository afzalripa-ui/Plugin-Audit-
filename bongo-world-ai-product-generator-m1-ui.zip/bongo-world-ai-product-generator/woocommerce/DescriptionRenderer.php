<?php
namespace BongoWorld\AIProductGenerator\WooCommerce;

defined( 'ABSPATH' ) || exit;

/** Converts approved description sections into safe WordPress HTML. Empty sections are skipped. */
final class DescriptionRenderer {
	public static function render( array $sections ): string {
		$html = '';
		foreach ( $sections as $s ) {
			if ( ! is_array( $s ) ) {
				continue;
			}
			$paras = array();
			foreach ( (array) ( $s['paragraphs'] ?? array() ) as $p ) {
				$p = trim( (string) $p );
				if ( '' !== $p ) {
					$paras[] = '<p>' . esc_html( $p ) . '</p>';
				}
			}
			if ( ! $paras ) {
				continue;
			}
			$h = trim( (string) ( $s['heading'] ?? '' ) );
			if ( '' !== $h ) {
				$html .= '<h3>' . esc_html( $h ) . '</h3>' . "\n";
			}
			$html .= implode( "\n", $paras ) . "\n";
		}
		return wp_kses_post( $html );
	}
}
