<?php
namespace BongoWorld\AIProductGenerator\WooCommerce;

defined( 'ABSPATH' ) || exit;

/** Slug checks. Never silently alters or overwrites another product's slug. */
final class SlugService {
	public static function sanitize( string $s ): string {
		return sanitize_title( $s );
	}

	public static function is_available( string $slug, int $exclude_id = 0 ): bool {
		global $wpdb;
		$found = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'product' AND post_name = %s AND post_status <> 'trash' AND ID <> %d LIMIT 1", $slug, $exclude_id ) ); // phpcs:ignore
		return empty( $found );
	}
}
