<?php
namespace BongoWorld\AIProductGenerator\WooCommerce;

use BongoWorld\AIProductGenerator\Includes\Rules;
use BongoWorld\AIProductGenerator\Includes\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Maps the 7 locked attributes to the store's REAL global attributes (never assumed).
 * Heuristic auto-detect + manual override in Settings. Falls back to a local custom attribute with a warning.
 */
final class AttributeService {
	const CANDIDATES = array(
		'color'     => array( 'color', 'colour', 'রং', 'রঙ', 'কালার' ),
		'size'      => array( 'size', 'সাইজ' ),
		'fabric'    => array( 'fabric', 'material', 'fabric-material', 'fabric-and-material', 'fabric / material', 'কাপড়' ),
		'design'    => array( 'design', 'ডিজাইন' ),
		'style'     => array( 'style', 'স্টাইল' ),
		'age_group' => array( 'age-group', 'age_group', 'age group', 'age' ),
		'occasion'  => array( 'occasion', 'ওকেশন' ),
	);

	public function detect_taxonomy( string $key ): ?string {
		$map    = (array) Settings::get( 'attribute_map', array() );
		$choice = (string) ( $map[ $key ] ?? 'auto' );
		if ( 'local' === $choice || ! function_exists( 'wc_get_attribute_taxonomies' ) ) {
			return null;
		}
		$objs = wc_get_attribute_taxonomies();
		if ( 'auto' !== $choice ) {
			foreach ( $objs as $t ) {
				if ( $t->attribute_name === $choice ) {
					return wc_attribute_taxonomy_name( $t->attribute_name );
				}
			}
			return null;
		}
		$cands = self::CANDIDATES[ $key ] ?? array();
		$label = mb_strtolower( Rules::ATTRIBUTES[ $key ] ?? '', 'UTF-8' );
		foreach ( $objs as $t ) {
			$slug = mb_strtolower( (string) $t->attribute_name, 'UTF-8' );
			$lab  = mb_strtolower( (string) $t->attribute_label, 'UTF-8' );
			if ( in_array( $slug, $cands, true ) || in_array( $lab, $cands, true ) || $lab === $label ) {
				return wc_attribute_taxonomy_name( $t->attribute_name );
			}
		}
		return null;
	}

	/** @return array<string,?string> attribute key => taxonomy name or null (local). Used by Settings/Diagnostics. */
	public function report(): array {
		$out = array();
		foreach ( array_keys( Rules::ATTRIBUTES ) as $k ) {
			$out[ $k ] = $this->detect_taxonomy( $k );
		}
		return $out;
	}

	/** @return array{attributes:\WC_Product_Attribute[],warnings:string[]} */
	public function build( array $attrs ): array {
		$out    = array();
		$warn   = array();
		$pos    = 0;
		$create = (bool) Settings::get( 'create_missing_terms', true ) && current_user_can( 'manage_product_terms' );
		foreach ( Rules::ATTRIBUTES as $key => $label ) {
			$value = trim( (string) ( $attrs[ $key ]['value'] ?? '' ) );
			if ( '' === $value ) {
				continue;
			}
			$names = self::split( $value );
			$tax   = $this->detect_taxonomy( $key );
			$attr  = new \WC_Product_Attribute();
			if ( $tax && taxonomy_exists( $tax ) ) {
				$ids = $this->term_ids( $tax, $names, $create, $warn );
				if ( ! $ids ) {
					/* translators: %s attribute label */
					$warn[] = sprintf( __( 'No terms could be set for %s.', 'bongo-world-ai-product-generator' ), $label );
					continue;
				}
				$attr->set_id( (int) wc_attribute_taxonomy_id_by_name( $tax ) );
				$attr->set_name( $tax );
				$attr->set_options( $ids );
			} else {
				$attr->set_id( 0 );
				$attr->set_name( $label );
				$attr->set_options( $names );
				/* translators: %s attribute label */
				$warn[] = sprintf( __( 'No global attribute is mapped for %s; saved as a custom product attribute.', 'bongo-world-ai-product-generator' ), $label );
			}
			$attr->set_position( $pos++ );
			$attr->set_visible( true );
			$attr->set_variation( false );
			$out[] = $attr;
		}
		return array( 'attributes' => $out, 'warnings' => $warn );
	}

	private static function split( string $value ): array {
		$parts = preg_split( '/\s*[,،;\/|]\s*/u', $value, -1, PREG_SPLIT_NO_EMPTY );
		$out   = array();
		foreach ( (array) $parts as $p ) {
			$p = trim( sanitize_text_field( $p ) );
			if ( '' !== $p && ! in_array( mb_strtolower( $p, 'UTF-8' ), array_map( function ( $x ) { return mb_strtolower( $x, 'UTF-8' ); }, $out ), true ) ) {
				$out[] = $p;
			}
		}
		return $out;
	}

	/** Reuses existing terms (case-insensitive, slug-aware) to prevent Black / black / BLACK duplicates. */
	private function term_ids( string $tax, array $names, bool $create, array &$warn ): array {
		$by_name = array();
		$by_slug = array();
		$terms   = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => false ) );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$by_name[ mb_strtolower( $t->name, 'UTF-8' ) ] = (int) $t->term_id;
				$by_slug[ $t->slug ]                           = (int) $t->term_id;
			}
		}
		$ids = array();
		foreach ( $names as $n ) {
			$lk = mb_strtolower( $n, 'UTF-8' );
			$sk = sanitize_title( $n );
			if ( isset( $by_name[ $lk ] ) ) {
				$ids[] = $by_name[ $lk ];
			} elseif ( '' !== $sk && isset( $by_slug[ $sk ] ) ) {
				$ids[] = $by_slug[ $sk ];
			} elseif ( $create ) {
				$res = wp_insert_term( $n, $tax );
				if ( is_wp_error( $res ) ) {
					$tid = $res->get_error_data( 'term_exists' );
					if ( $tid ) {
						$ids[] = (int) $tid;
					} else {
						/* translators: %s term */
						$warn[] = sprintf( __( 'Term could not be created: %s', 'bongo-world-ai-product-generator' ), $n );
					}
				} else {
					$ids[]           = (int) $res['term_id'];
					$by_name[ $lk ] = (int) $res['term_id'];
				}
			} else {
				/* translators: %s term */
				$warn[] = sprintf( __( 'Term missing and creation not allowed: %s', 'bongo-world-ai-product-generator' ), $n );
			}
		}
		return array_values( array_unique( $ids ) );
	}
}
