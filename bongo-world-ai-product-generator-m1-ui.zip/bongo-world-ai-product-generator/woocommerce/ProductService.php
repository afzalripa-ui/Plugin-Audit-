<?php
namespace BongoWorld\AIProductGenerator\WooCommerce;

use BongoWorld\AIProductGenerator\History\GenerationRepository;
use BongoWorld\AIProductGenerator\Includes\Capabilities;
use BongoWorld\AIProductGenerator\Includes\Rules;
use BongoWorld\AIProductGenerator\Includes\Settings;
use BongoWorld\AIProductGenerator\Logging\Logger;
use BongoWorld\AIProductGenerator\Media\ImageMetadataService;
use BongoWorld\AIProductGenerator\SEO\RankMathAdapter;

defined( 'ABSPATH' ) || exit;

/** Saves an approved result via native WooCommerce CRUD (WC_Product_Simple). Never auto-publishes. */
final class ProductService {
	/** @return array<int,array{id:int,title:string,status:string,edit_link:string}> */
	public function find_duplicates( string $name, string $slug, int $exclude_id = 0 ): array {
		global $wpdb;
		$rows = $wpdb->get_results( // phpcs:ignore
			$wpdb->prepare(
				"SELECT ID, post_title, post_status FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status NOT IN ('trash','auto-draft') AND ID <> %d AND (LOWER(post_title) = %s OR post_name = %s) LIMIT 5",
				$exclude_id,
				mb_strtolower( trim( $name ), 'UTF-8' ),
				$slug
			)
		);
		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'id'        => (int) $r->ID,
				'title'     => (string) $r->post_title,
				'status'    => (string) $r->post_status,
				'edit_link' => (string) get_edit_post_link( (int) $r->ID, 'raw' ),
			);
		}
		return $out;
	}

	/**
	 * @param array $data   Validated result (product/attributes/images).
	 * @param array $store  Cleaned store data (price, stock, category, shipping...).
	 * @param array $images slot => attachment id.
	 * @param array $opts   mode, product_id, product_type, generation_id.
	 */
	public function save( array $data, array $store, array $images, array $opts ): array {
		$mode     = ( isset( $opts['mode'] ) && 'publish' === $opts['mode'] ) ? 'publish' : 'draft';
		$existing = (int) ( $opts['product_id'] ?? 0 );
		$gid      = (string) ( $opts['generation_id'] ?? '' );
		$out      = array( 'ok' => false, 'partial' => false, 'product_id' => $existing, 'status' => '', 'sku' => '', 'slug' => '', 'edit_link' => '', 'warnings' => array(), 'steps' => array(), 'error' => null );

		// Re-check permissions (spec §98).
		if ( ! current_user_can( Capabilities::SAVE ) ) {
			return $this->fail( $out, 'permission', __( 'You do not have permission to save products.', 'bongo-world-ai-product-generator' ) );
		}
		if ( 'publish' === $mode && ! current_user_can( Capabilities::PUBLISH ) ) {
			return $this->fail( $out, 'publish_permission', __( 'You do not have permission to publish products.', 'bongo-world-ai-product-generator' ) );
		}
		if ( ! class_exists( 'WC_Product_Simple' ) ) {
			return $this->fail( $out, 'woocommerce_missing', __( 'WooCommerce is not available.', 'bongo-world-ai-product-generator' ) );
		}

		$p    = (array) $data['product'];
		$slug = sanitize_title( (string) $p['slug'] );
		if ( ! SlugService::is_available( $slug, $existing ) ) {
			return $this->fail( $out, 'slug_conflict', __( 'Slug is already used by another product.', 'bongo-world-ai-product-generator' ) );
		}

		try {
			if ( $existing > 0 ) {
				$product = wc_get_product( $existing );
				if ( ! $product || 'simple' !== $product->get_type() || ! current_user_can( 'edit_post', $existing ) ) {
					return $this->fail( $out, 'product_not_editable', __( 'The previously saved product cannot be edited.', 'bongo-world-ai-product-generator' ) );
				}
			} else {
				$product = new \WC_Product_Simple();
				$product->set_sku( SKUService::generate( Settings::type_code( (string) ( $opts['product_type'] ?? '' ) ) ) );
			}

			$product->set_name( sanitize_text_field( (string) $p['name'] ) );
			$product->set_slug( $slug );
			$product->set_description( DescriptionRenderer::render( (array) $p['description_sections'] ) );
			$product->set_short_description( sanitize_textarea_field( (string) $p['short_description'] ) );

			$tags = ( new TagService() )->resolve( (array) $p['tags'] );
			$product->set_tag_ids( $tags['ids'] );

			$attrs = ( new AttributeService() )->build( (array) $data['attributes'] );
			$product->set_attributes( $attrs['attributes'] );

			$this->apply_store( $product, $store );
			StockService::apply( $product, $store );
			$out['warnings'] = array_merge( $tags['warnings'], $attrs['warnings'], ImageService::apply( $product, $images ) );

			$product->set_status( 'publish' === $mode ? 'publish' : 'draft' );
			$id = (int) $product->save();
		} catch ( \Throwable $e ) {
			Logger::event( 'product_save_failed', array( 'type' => get_class( $e ) ) );
			return $this->fail( $out, 'save_failed', __( 'WooCommerce could not save the product. Your generated content is kept - retry.', 'bongo-world-ai-product-generator' ) );
		}
		if ( $id <= 0 ) {
			return $this->fail( $out, 'save_failed', __( 'WooCommerce could not save the product. Your generated content is kept - retry.', 'bongo-world-ai-product-generator' ) );
		}

		$out['ok']         = true;
		$out['product_id'] = $id;
		$out['status']     = $product->get_status();
		$out['sku']        = $product->get_sku();
		$out['slug']       = $product->get_slug();
		$out['edit_link']  = (string) get_edit_post_link( $id, 'raw' );
		$out['steps']['product'] = array( 'status' => 'ok', 'message' => '' );
		if ( $out['slug'] !== $slug ) {
			$out['warnings'][] = __( 'WordPress adjusted the slug; please review it.', 'bongo-world-ai-product-generator' );
		}
		update_post_meta( $id, '_bwaipg_generation_id', sanitize_text_field( $gid ) );
		update_post_meta( $id, '_bwaipg_prompt_version', Rules::PROMPT_VERSION );
		Logger::event( 'product_saved', array( 'product_id' => $id, 'status' => $out['status'] ) );

		// Image metadata: only for the selected attachments, one result per slot (spec §69).
		$meta_svc = new ImageMetadataService();
		foreach ( array_keys( Rules::IMAGE_SLOTS ) as $slot ) {
			$aid = (int) ( $images[ $slot ] ?? 0 );
			if ( $aid <= 0 ) {
				$out['steps'][ 'image_' . $slot ] = array( 'status' => 'skipped', 'message' => __( 'No image selected.', 'bongo-world-ai-product-generator' ) );
				continue;
			}
			$res = $meta_svc->apply( $aid, (array) ( $data['images'][ $slot ] ?? array() ) );
			$out['steps'][ 'image_' . $slot ] = array( 'status' => $res['ok'] ? 'ok' : 'failed', 'message' => $res['message'] );
			if ( $res['ok'] ) {
				Logger::event( 'image_updated', array( 'attachment' => $aid, 'slot' => $slot ) );
			}
		}

		// Rank Math (optional): failure never deletes the product (spec §68).
		$rm  = ( new RankMathAdapter() )->update( $id, $p );
		$out['steps']['rank_math'] = $rm;
		if ( 'ok' === $rm['status'] ) {
			Logger::event( 'rank_math_updated', array( 'product_id' => $id ) );
		}

		foreach ( $out['steps'] as $s ) {
			if ( 'failed' === $s['status'] ) {
				$out['partial'] = true;
			}
		}
		if ( '' !== $gid ) {
			( new GenerationRepository() )->update( $gid, array( 'product_id' => $id ) );
		}
		return $out;
	}

	private function apply_store( \WC_Product $product, array $s ): void {
		if ( '' !== (string) ( $s['regular_price'] ?? '' ) ) {
			$product->set_regular_price( (string) $s['regular_price'] );
		}
		if ( '' !== (string) ( $s['sale_price'] ?? '' ) ) {
			$product->set_sale_price( (string) $s['sale_price'] );
		}
		if ( ! empty( $s['categories'] ) ) {
			$product->set_category_ids( array_map( 'intval', (array) $s['categories'] ) );
		}
		if ( ! empty( $s['shipping_class'] ) ) {
			$product->set_shipping_class_id( (int) $s['shipping_class'] );
		}
		foreach ( array( 'weight' => 'set_weight', 'length' => 'set_length', 'width' => 'set_width', 'height' => 'set_height' ) as $k => $setter ) {
			if ( '' !== (string) ( $s[ $k ] ?? '' ) ) {
				$product->$setter( (string) $s[ $k ] );
			}
		}
	}

	private function fail( array $out, string $code, string $message ): array {
		$out['error'] = array( 'code' => $code, 'message' => $message );
		return $out;
	}
}
