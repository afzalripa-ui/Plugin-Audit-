<?php
namespace BongoWorld\AIProductGenerator\WooCommerce;

defined( 'ABSPATH' ) || exit;

/** Maps the 5 slots to Featured image + Gallery (exact order, no duplicates). Never deletes media. */
final class ImageService {
	const GALLERY_ORDER = array( 'back', 'side', 'fabric', 'front_zoom' );

	/** @return string[] warnings */
	public static function apply( \WC_Product $product, array $images ): array {
		$warn    = array();
		$seen    = array();
		$gallery = array();
		$main    = (int) ( $images['main'] ?? 0 );
		if ( $main > 0 ) {
			if ( self::valid( $main ) ) {
				$product->set_image_id( $main );
				$seen[ $main ] = true;
			} else {
				$warn[] = __( 'Main image is not a valid image you can use.', 'bongo-world-ai-product-generator' );
			}
		}
		foreach ( self::GALLERY_ORDER as $slot ) {
			$id = (int) ( $images[ $slot ] ?? 0 );
			if ( $id <= 0 ) {
				continue;
			}
			if ( isset( $seen[ $id ] ) ) {
				/* translators: %s slot */
				$warn[] = sprintf( __( 'Duplicate image skipped in slot: %s', 'bongo-world-ai-product-generator' ), $slot );
				continue;
			}
			if ( ! self::valid( $id ) ) {
				/* translators: %s slot */
				$warn[] = sprintf( __( 'Invalid image in slot: %s', 'bongo-world-ai-product-generator' ), $slot );
				continue;
			}
			$seen[ $id ] = true;
			$gallery[]   = $id;
		}
		if ( $gallery ) { // Do not wipe an existing gallery when no gallery images were chosen.
			$product->set_gallery_image_ids( $gallery );
		}
		return $warn;
	}

	private static function valid( int $id ): bool {
		return wp_attachment_is_image( $id ) && current_user_can( 'edit_post', $id );
	}
}
