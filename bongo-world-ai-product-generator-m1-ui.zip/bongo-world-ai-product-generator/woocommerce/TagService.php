<?php
namespace BongoWorld\AIProductGenerator\WooCommerce;

defined( 'ABSPATH' ) || exit;

final class TagService {
	/** @return array{ids:int[],warnings:string[]} */
	public function resolve( array $tags ): array {
		$ids  = array();
		$warn = array();
		$seen = array();
		$can  = current_user_can( 'manage_product_terms' );
		foreach ( $tags as $t ) {
			$name = trim( sanitize_text_field( (string) $t ) );
			$key  = mb_strtolower( $name, 'UTF-8' );
			if ( '' === $name || isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$ex           = term_exists( $name, 'product_tag' );
			if ( is_array( $ex ) ) {
				$ids[] = (int) $ex['term_id'];
			} elseif ( $ex ) {
				$ids[] = (int) $ex;
			} elseif ( $can ) {
				$res = wp_insert_term( $name, 'product_tag' );
				if ( is_wp_error( $res ) ) {
					$tid = $res->get_error_data( 'term_exists' );
					if ( $tid ) {
						$ids[] = (int) $tid;
					} else {
						/* translators: %s tag */
						$warn[] = sprintf( __( 'Tag could not be created: %s', 'bongo-world-ai-product-generator' ), $name );
					}
				} else {
					$ids[] = (int) $res['term_id'];
				}
			} else {
				/* translators: %s tag */
				$warn[] = sprintf( __( 'No permission to create tag: %s', 'bongo-world-ai-product-generator' ), $name );
			}
		}
		return array( 'ids' => array_values( array_unique( $ids ) ), 'warnings' => $warn );
	}
}
