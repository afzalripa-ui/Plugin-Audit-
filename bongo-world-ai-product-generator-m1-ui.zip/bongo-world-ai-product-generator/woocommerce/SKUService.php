<?php
namespace BongoWorld\AIProductGenerator\WooCommerce;

use BongoWorld\AIProductGenerator\Includes\Settings;

defined( 'ABSPATH' ) || exit;

/** Deterministic SKU. Never AI-generated. Atomic per-(type,month) counter. */
final class SKUService {
	/** Non-consuming preview of the next SKU (used by the quality gate). */
	public static function preview( string $type_code ): string {
		list( $pattern, $type, $yymm ) = self::parts( $type_code );
		$current = (int) get_option( self::key( $type, $yymm ), 0 );
		return self::build( $pattern, $type, $yymm, $current + 1 );
	}

	/** Allocates a unique SKU (consumes a sequence number). */
	public static function generate( string $type_code ): string {
		list( $pattern, $type, $yymm ) = self::parts( $type_code );
		for ( $i = 0; $i < 10; $i++ ) {
			$sku = self::build( $pattern, $type, $yymm, self::next_sequence( self::key( $type, $yymm ) ) );
			if ( ! self::exists( $sku ) ) {
				return $sku;
			}
		}
		throw new \RuntimeException( 'Could not allocate a unique SKU.' );
	}

	public static function exists( string $sku ): bool {
		return function_exists( 'wc_get_product_id_by_sku' ) && wc_get_product_id_by_sku( $sku ) > 0;
	}

	private static function parts( string $type_code ): array {
		$pattern = (string) Settings::get( 'sku_pattern', 'BW-{TYPE}-{YYMM}-{SEQUENCE}' );
		if ( ! Settings::pattern_is_valid( $pattern ) ) {
			$pattern = 'BW-{TYPE}-{YYMM}-{SEQUENCE}';
		}
		$type = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', $type_code ) );
		$type = '' === $type ? 'GEN' : substr( $type, 0, 4 );
		return array( $pattern, $type, wp_date( 'ym' ) );
	}

	private static function key( string $type, string $yymm ): string {
		return 'bwaipg_seq_' . $type . '_' . $yymm;
	}

	private static function build( string $pattern, string $type, string $yymm, int $seq ): string {
		return str_replace( array( '{TYPE}', '{YYMM}', '{SEQUENCE}' ), array( $type, $yymm, str_pad( (string) $seq, 3, '0', STR_PAD_LEFT ) ), $pattern );
	}

	/** Atomic increment (no read-modify-write race). Gaps are possible and acceptable. */
	private static function next_sequence( string $key ): int {
		global $wpdb;
		add_option( $key, 0, '', false );
		$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = LAST_INSERT_ID(option_value + 1) WHERE option_name = %s", $key ) ); // phpcs:ignore
		wp_cache_delete( $key, 'options' );
		wp_cache_delete( 'notoptions', 'options' );
		return (int) $wpdb->get_var( 'SELECT LAST_INSERT_ID()' ); // phpcs:ignore
	}
}
