<?php
namespace BongoWorld\AIProductGenerator\WooCommerce;

defined( 'ABSPATH' ) || exit;

/** Stock comes ONLY from Store Data. AI never invents quantity. Blank = untouched. */
final class StockService {
	public static function apply( \WC_Product $product, array $store ): void {
		if ( ! empty( $store['manage_stock'] ) ) {
			$product->set_manage_stock( true );
			$q = (string) ( $store['stock_quantity'] ?? '' );
			if ( '' !== $q && ctype_digit( $q ) ) {
				$product->set_stock_quantity( (int) $q );
			}
		} else {
			$product->set_manage_stock( false );
			if ( ! empty( $store['stock_status'] ) ) {
				$product->set_stock_status( (string) $store['stock_status'] );
			}
		}
	}
}
