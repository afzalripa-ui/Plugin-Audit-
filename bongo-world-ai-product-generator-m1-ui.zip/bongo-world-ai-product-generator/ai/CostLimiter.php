<?php
namespace BongoWorld\AIProductGenerator\AI;

use BongoWorld\AIProductGenerator\History\GenerationRepository;

defined( 'ABSPATH' ) || exit;

/** Per-provider daily/monthly request limits (spec §73). Counted from the history table. */
final class CostLimiter {
	const COUNTED = array( 'generate_product', 'generate_product_fallback' );

	/** @return array{ok:bool,code?:string,message?:string} */
	public function check( array $profile ): array {
		$limits  = isset( $profile['limits'] ) && is_array( $profile['limits'] ) ? $profile['limits'] : array();
		$daily   = (int) ( $limits['daily'] ?? 0 );
		$monthly = (int) ( $limits['monthly'] ?? 0 );
		$repo    = new GenerationRepository();
		$id      = (string) ( $profile['id'] ?? '' );

		if ( $daily > 0 && $repo->count_since( $id, $this->day_start_gmt(), self::COUNTED ) >= $daily ) {
			return array( 'ok' => false, 'code' => 'daily_limit', 'message' => __( 'Daily request limit reached for this provider.', 'bongo-world-ai-product-generator' ) );
		}
		if ( $monthly > 0 && $repo->count_since( $id, $this->month_start_gmt(), self::COUNTED ) >= $monthly ) {
			return array( 'ok' => false, 'code' => 'monthly_limit', 'message' => __( 'Monthly request limit reached for this provider.', 'bongo-world-ai-product-generator' ) );
		}
		return array( 'ok' => true );
	}

	public function usage( string $profile_id ): array {
		$repo = new GenerationRepository();
		return array(
			'today' => $repo->count_since( $profile_id, $this->day_start_gmt(), self::COUNTED ),
			'month' => $repo->count_since( $profile_id, $this->month_start_gmt(), self::COUNTED ),
		);
	}

	private function day_start_gmt(): string {
		return get_gmt_from_date( wp_date( 'Y-m-d' ) . ' 00:00:00' );
	}

	private function month_start_gmt(): string {
		return get_gmt_from_date( wp_date( 'Y-m' ) . '-01 00:00:00' );
	}
}
