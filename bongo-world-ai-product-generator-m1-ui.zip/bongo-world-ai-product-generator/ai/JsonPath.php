<?php
namespace BongoWorld\AIProductGenerator\AI;

defined( 'ABSPATH' ) || exit;

/** Safe dotted-path reader, e.g. "choices.0.message.content". Never executes anything. */
final class JsonPath {
	public static function is_valid( string $path ): bool {
		return (bool) preg_match( '/^[A-Za-z0-9_\-]+(\.[A-Za-z0-9_\-]+)*$/', $path );
	}

	/** @return mixed|null */
	public static function get( $data, string $path ) {
		if ( ! self::is_valid( $path ) ) {
			return null;
		}
		foreach ( explode( '.', $path ) as $seg ) {
			if ( is_array( $data ) && array_key_exists( $seg, $data ) ) {
				$data = $data[ $seg ];
			} else {
				return null;
			}
		}
		return $data;
	}
}
