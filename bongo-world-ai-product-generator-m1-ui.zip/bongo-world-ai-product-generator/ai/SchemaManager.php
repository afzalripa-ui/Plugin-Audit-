<?php
namespace BongoWorld\AIProductGenerator\AI;

use BongoWorld\AIProductGenerator\Includes\Rules;

defined( 'ABSPATH' ) || exit;

/** Single source of truth for the AI output contract (v3.1). Strict-mode friendly. */
final class SchemaManager {
	public static function json_schema(): array {
		$str = array( 'type' => 'string' );

		$attr = array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'required'             => array( 'value', 'source' ),
			'properties'           => array(
				'value'  => $str,
				'source' => array( 'type' => 'string', 'enum' => Rules::SOURCES ),
			),
		);
		$attrs = array();
		foreach ( array_keys( Rules::ATTRIBUTES ) as $k ) {
			$attrs[ $k ] = $attr;
		}

		$img = array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'required'             => array_merge( Rules::IMAGE_FIELDS, array( 'basis' ) ),
			'properties'           => array(
				'alt'         => $str,
				'title'       => $str,
				'caption'     => $str,
				'description' => $str,
				'basis'       => array( 'type' => 'string', 'enum' => Rules::IMAGE_BASIS ),
			),
		);
		$imgs = array();
		foreach ( array_keys( Rules::IMAGE_SLOTS ) as $k ) {
			$imgs[ $k ] = $img;
		}

		return array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'required'             => array( 'schema_version', 'product', 'attributes', 'images' ),
			'properties'           => array(
				'schema_version' => array( 'type' => 'string', 'enum' => array( Rules::SCHEMA_VERSION ) ),
				'product'        => array(
					'type'                 => 'object',
					'additionalProperties' => false,
					'required'             => Rules::PRODUCT_FIELDS,
					'properties'           => array(
						'name'                      => $str,
						'seo_title'                 => $str,
						'description_sections'      => array(
							'type'  => 'array',
							'items' => array(
								'type'                 => 'object',
								'additionalProperties' => false,
								'required'             => array( 'heading', 'paragraphs' ),
								'properties'           => array(
									'heading'    => $str,
									'paragraphs' => array( 'type' => 'array', 'items' => $str ),
								),
							),
						),
						'short_description'         => $str,
						'focus_keyword'             => $str,
						'focus_keyword_slug_source' => $str,
						'slug'                      => $str,
						'meta_description'          => $str,
						'tags'                      => array( 'type' => 'array', 'items' => $str ),
					),
				),
				'attributes'     => array(
					'type'                 => 'object',
					'additionalProperties' => false,
					'required'             => array_keys( Rules::ATTRIBUTES ),
					'properties'           => $attrs,
				),
				'images'         => array(
					'type'                 => 'object',
					'additionalProperties' => false,
					'required'             => array_keys( Rules::IMAGE_SLOTS ),
					'properties'           => $imgs,
				),
			),
		);
	}
}
