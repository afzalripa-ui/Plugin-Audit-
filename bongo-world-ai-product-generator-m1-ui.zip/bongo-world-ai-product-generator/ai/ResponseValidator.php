<?php
namespace BongoWorld\AIProductGenerator\AI;

use BongoWorld\AIProductGenerator\Includes\Rules;

defined( 'ABSPATH' ) || exit;

/**
 * Quality gate. Pure validation: never mutates or "fixes" the data.
 * $ctx (all optional): user_facts[attr=>value], images_supplied[slot=>bool],
 *                      slug_available(bool), sku_unique(bool).
 * Any entry in ['errors'] blocks saving. ['warnings'] must be shown.
 */
final class ResponseValidator {
	public static function validate( array $d, array $ctx = array() ): array {
		$r   = array( 'errors' => array(), 'warnings' => array(), 'passes' => array() );
		$add = function ( string $lvl, string $code, string $msg ) use ( &$r ) {
			$r[ $lvl ][] = array( 'code' => $code, 'message' => $msg );
		};

		// 1. Structure.
		foreach ( array_diff( array_keys( $d ), array( 'schema_version', 'product', 'attributes', 'images' ) ) as $k ) {
			$add( 'errors', 'unknown_key', sprintf( __( 'Unexpected top-level key: %s', 'bongo-world-ai-product-generator' ), $k ) );
		}
		foreach ( array( 'product', 'attributes', 'images' ) as $k ) {
			if ( ! isset( $d[ $k ] ) || ! is_array( $d[ $k ] ) ) {
				$add( 'errors', 'missing_section', sprintf( __( 'Missing section: %s', 'bongo-world-ai-product-generator' ), $k ) );
			}
		}
		if ( ( $d['schema_version'] ?? '' ) !== Rules::SCHEMA_VERSION ) {
			$add( 'errors', 'schema_version', __( 'Wrong schema_version.', 'bongo-world-ai-product-generator' ) );
		}
		if ( $r['errors'] ) {
			return $r;
		}

		// 2. Business-data contamination (price/stock/category/shipping/sku) anywhere.
		$hits = array();
		self::scan_forbidden( $d, $hits );
		if ( $hits ) {
			$add( 'errors', 'business_data', sprintf( __( 'AI returned store-controlled fields: %s', 'bongo-world-ai-product-generator' ), implode( ', ', array_unique( $hits ) ) ) );
		} else {
			$add( 'passes', 'business_data', __( 'No AI-generated price/stock/category/shipping/SKU.', 'bongo-world-ai-product-generator' ) );
		}

		// 3. Product fields.
		$err_before = count( $r['errors'] );
		$p          = $d['product'];
		foreach ( array_diff( array_keys( $p ), Rules::PRODUCT_FIELDS ) as $k ) {
			$add( 'errors', 'unknown_key', sprintf( __( 'Unexpected product key: %s', 'bongo-world-ai-product-generator' ), $k ) );
		}
		foreach ( array( 'name', 'seo_title', 'short_description', 'focus_keyword', 'focus_keyword_slug_source', 'slug', 'meta_description' ) as $f ) {
			if ( ! isset( $p[ $f ] ) || ! is_string( $p[ $f ] ) || '' === trim( $p[ $f ] ) ) {
				$add( 'errors', 'empty_' . $f, sprintf( __( 'Required field is empty: %s', 'bongo-world-ai-product-generator' ), $f ) );
			}
		}
		if ( count( $r['errors'] ) > $err_before ) {
			return $r;
		}
		$add( 'passes', 'required_fields', __( 'Required fields present.', 'bongo-world-ai-product-generator' ) );

		// 4. Focus keyword placement (each checked independently; nothing is auto-injected).
		$kw = trim( $p['focus_keyword'] );
		foreach ( array( 'name', 'seo_title', 'short_description', 'meta_description' ) as $f ) {
			if ( self::has( $p[ $f ], $kw ) ) {
				$add( 'passes', 'kw_' . $f, sprintf( __( 'Focus keyword found in %s.', 'bongo-world-ai-product-generator' ), $f ) );
			} else {
				$add( 'errors', 'kw_' . $f, sprintf( __( 'Focus keyword missing in %s.', 'bongo-world-ai-product-generator' ), $f ) );
			}
		}
		$slug_src = self::slugify( $p['focus_keyword_slug_source'] );
		if ( ! preg_match( '/^[a-z0-9]+(-[a-z0-9]+)*$/', $p['slug'] ) ) {
			$add( 'errors', 'slug_format', __( 'Slug must be lowercase a-z, 0-9 and hyphens.', 'bongo-world-ai-product-generator' ) );
		} elseif ( '' === $slug_src || false === strpos( $p['slug'], $slug_src ) ) {
			$add( 'errors', 'kw_slug', __( 'Slug does not contain the slugified focus keyword.', 'bongo-world-ai-product-generator' ) );
		} else {
			$add( 'passes', 'kw_slug', __( 'Slug contains the focus keyword.', 'bongo-world-ai-product-generator' ) );
		}
		if ( isset( $ctx['slug_available'] ) ) {
			$ctx['slug_available'] ? $add( 'passes', 'slug_available', __( 'Slug available.', 'bongo-world-ai-product-generator' ) ) : $add( 'errors', 'slug_conflict', __( 'Slug already in use.', 'bongo-world-ai-product-generator' ) );
		}
		if ( isset( $ctx['sku_unique'] ) ) {
			$ctx['sku_unique'] ? $add( 'passes', 'sku_unique', __( 'SKU unique.', 'bongo-world-ai-product-generator' ) ) : $add( 'errors', 'sku_duplicate', __( 'Duplicate SKU.', 'bongo-world-ai-product-generator' ) );
		}

		// 5. Lengths (warnings only).
		self::range( $add, 'name_length', $p['name'], 30, 70 );
		self::range( $add, 'seo_title_length', $p['seo_title'], 40, 65 );
		self::range( $add, 'meta_length', $p['meta_description'], 110, 160 );

		// 6. No HTML / Markdown headings in any string.
		$bad = array();
		self::scan_markup( $d, $bad );
		if ( $bad ) {
			$add( 'errors', 'raw_markup', sprintf( __( 'HTML or Markdown headings found in: %s', 'bongo-world-ai-product-generator' ), implode( ', ', array_unique( $bad ) ) ) );
		}

		// 7. Description sections.
		$words = 0;
		$secs  = $p['description_sections'] ?? null;
		if ( ! is_array( $secs ) || ! $secs ) {
			$add( 'errors', 'description', __( 'Description has no sections.', 'bongo-world-ai-product-generator' ) );
		} else {
			foreach ( $secs as $s ) {
				if ( ! is_array( $s ) || ! isset( $s['paragraphs'] ) || ! is_array( $s['paragraphs'] ) ) {
					$add( 'errors', 'description', __( 'Malformed description section.', 'bongo-world-ai-product-generator' ) );
					break;
				}
				foreach ( $s['paragraphs'] as $para ) {
					$words += is_string( $para ) ? count( preg_split( '/\s+/u', trim( $para ), -1, PREG_SPLIT_NO_EMPTY ) ) : 0;
				}
			}
			if ( $words < 100 || $words > 450 ) {
				$add( 'warnings', 'description_words', sprintf( __( 'Description is %d words (target ~150-300).', 'bongo-world-ai-product-generator' ), $words ) );
			}
		}

		// 8. Tags.
		$tags = is_array( $p['tags'] ?? null ) ? $p['tags'] : array();
		$norm = array_map( function ( $t ) { return is_string( $t ) ? mb_strtolower( trim( $t ), 'UTF-8' ) : ''; }, $tags );
		if ( ! $norm || in_array( '', $norm, true ) ) {
			$add( 'errors', 'tags', __( 'Tags missing or contain empty items.', 'bongo-world-ai-product-generator' ) );
		} else {
			count( array_unique( $norm ) ) !== count( $norm ) && $add( 'warnings', 'tags_duplicate', __( 'Duplicate tags found.', 'bongo-world-ai-product-generator' ) );
			( count( $norm ) < Rules::TAGS_MIN || count( $norm ) > Rules::TAGS_MAX ) && $add( 'warnings', 'tags_count', sprintf( __( 'Tag count is %d (target 8-15).', 'bongo-world-ai-product-generator' ), count( $norm ) ) );
		}

		// 9. Attributes: exactly 7.
		$a = $d['attributes'];
		if ( array_keys( $a ) !== array_keys( Rules::ATTRIBUTES ) && ( array_diff( array_keys( $a ), array_keys( Rules::ATTRIBUTES ) ) || array_diff( array_keys( Rules::ATTRIBUTES ), array_keys( $a ) ) ) ) {
			$add( 'errors', 'attributes_set', __( 'Attributes must be exactly the 7 locked keys.', 'bongo-world-ai-product-generator' ) );
		} else {
			$ok = true;
			foreach ( array_keys( Rules::ATTRIBUTES ) as $k ) {
				$val = $a[ $k ]['value'] ?? null;
				$src = $a[ $k ]['source'] ?? null;
				if ( ! is_string( $val ) || ! in_array( $src, Rules::SOURCES, true ) ) {
					$add( 'errors', 'attr_' . $k, sprintf( __( 'Attribute %s is malformed.', 'bongo-world-ai-product-generator' ), $k ) );
					$ok = false;
				} elseif ( '' === trim( $val ) ) {
					$add( 'errors', 'attr_' . $k, sprintf( __( 'Attribute %s is missing - fill it in manually.', 'bongo-world-ai-product-generator' ), Rules::ATTRIBUTES[ $k ] ) );
					$ok = false;
				} elseif ( 'UNKNOWN' === $src ) {
					$add( 'errors', 'attr_' . $k, sprintf( __( 'Attribute %s is UNKNOWN but has a value.', 'bongo-world-ai-product-generator' ), $k ) );
					$ok = false;
				}
				if ( isset( $ctx['user_facts'][ $k ] ) && is_string( $val ) && 0 !== strcasecmp( trim( $ctx['user_facts'][ $k ] ), trim( $val ) ) ) {
					$add( 'errors', 'user_fact_changed', sprintf( __( 'AI changed the user-provided %s.', 'bongo-world-ai-product-generator' ), $k ) );
					$ok = false;
				}
			}
			$ok && $add( 'passes', 'attributes', __( '7 attributes valid.', 'bongo-world-ai-product-generator' ) );
		}

		// 10. Images: exactly 5 slots, 4 fields + basis, no fake "observed".
		$im = $d['images'];
		if ( array_diff( array_keys( $im ), array_keys( Rules::IMAGE_SLOTS ) ) || array_diff( array_keys( Rules::IMAGE_SLOTS ), array_keys( $im ) ) ) {
			$add( 'errors', 'image_slots', __( 'Images must be exactly the 5 locked slots.', 'bongo-world-ai-product-generator' ) );
		} else {
			$ok = true;
			foreach ( array_keys( Rules::IMAGE_SLOTS ) as $slot ) {
				foreach ( Rules::IMAGE_FIELDS as $f ) {
					if ( ! isset( $im[ $slot ][ $f ] ) || ! is_string( $im[ $slot ][ $f ] ) || '' === trim( $im[ $slot ][ $f ] ) ) {
						$add( 'errors', "img_{$slot}_{$f}", sprintf( __( 'Image %1$s is missing %2$s.', 'bongo-world-ai-product-generator' ), $slot, $f ) );
						$ok = false;
					}
				}
				$basis = $im[ $slot ]['basis'] ?? '';
				if ( ! in_array( $basis, Rules::IMAGE_BASIS, true ) ) {
					$add( 'errors', "img_{$slot}_basis", sprintf( __( 'Image %s has an invalid basis.', 'bongo-world-ai-product-generator' ), $slot ) );
					$ok = false;
				} elseif ( 'IMAGE_OBSERVED' === $basis && empty( $ctx['images_supplied'][ $slot ] ) ) {
					$add( 'errors', "img_{$slot}_claim", sprintf( __( 'Image %s claims IMAGE_OBSERVED but no image was supplied.', 'bongo-world-ai-product-generator' ), $slot ) );
					$ok = false;
				}
			}
			$ok && $add( 'passes', 'images', __( '5 image metadata groups valid.', 'bongo-world-ai-product-generator' ) );
		}

		return $r;
	}

	public static function is_ready( array $result ): bool {
		return empty( $result['errors'] );
	}

	private static function has( string $text, string $kw ): bool {
		return '' !== $kw && false !== mb_stripos( $text, $kw, 0, 'UTF-8' );
	}

	private static function slugify( string $s ): string {
		return function_exists( 'sanitize_title' ) ? sanitize_title( $s ) : trim( preg_replace( '/[^a-z0-9]+/', '-', strtolower( $s ) ), '-' );
	}

	private static function range( callable $add, string $code, string $text, int $min, int $max ): void {
		$len = mb_strlen( $text, 'UTF-8' );
		if ( $len < $min || $len > $max ) {
			$add( 'warnings', $code, sprintf( __( '%1$s is %2$d characters (suggested %3$d-%4$d).', 'bongo-world-ai-product-generator' ), $code, $len, $min, $max ) );
		}
	}

	private static function scan_forbidden( $node, array &$hits ): void {
		if ( ! is_array( $node ) ) {
			return;
		}
		foreach ( $node as $k => $v ) {
			if ( is_string( $k ) && in_array( strtolower( $k ), Rules::FORBIDDEN_KEYS, true ) ) {
				$hits[] = $k;
			}
			self::scan_forbidden( $v, $hits );
		}
	}

	private static function scan_markup( $node, array &$bad, string $path = '' ): void {
		if ( is_string( $node ) ) {
			if ( preg_match( '/<\/?[a-z][^>]*>/i', $node ) || preg_match( '/^\s*#{1,6}\s/m', $node ) ) {
				$bad[] = $path;
			}
			return;
		}
		if ( is_array( $node ) ) {
			foreach ( $node as $k => $v ) {
				self::scan_markup( $v, $bad, $path . '/' . $k );
			}
		}
	}
}
