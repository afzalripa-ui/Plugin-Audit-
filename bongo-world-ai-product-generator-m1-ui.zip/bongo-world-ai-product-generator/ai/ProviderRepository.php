<?php
namespace BongoWorld\AIProductGenerator\AI;

use BongoWorld\AIProductGenerator\Security\KeyProvider;

defined( 'ABSPATH' ) || exit;

/** Provider profiles (spec §6-7). Secrets are NEVER stored here; keys come from wp-config/env. */
final class ProviderRepository {
	const OPTION = 'bwaipg_profiles';
	const TYPES  = array( 'openai_compatible', 'custom_rest' );

	public function all(): array {
		$p = get_option( self::OPTION, array() );
		return is_array( $p ) ? $p : array();
	}

	public function get( string $id ): ?array {
		$all = $this->all();
		return ( '' !== $id && isset( $all[ $id ] ) && is_array( $all[ $id ] ) ) ? $all[ $id ] : null;
	}

	/** @return array{ok:bool,id:string,errors:array} */
	public function save( array $in, string $existing_id = '' ): array {
		$all    = $this->all();
		$old    = ( '' !== $existing_id && isset( $all[ $existing_id ] ) ) ? $all[ $existing_id ] : array();
		$errors = array();

		$name = sanitize_text_field( (string) ( $in['display_name'] ?? '' ) );
		if ( '' === $name ) {
			$errors[] = __( 'Display name is required.', 'bongo-world-ai-product-generator' );
		}
		$type = (string) ( $in['connection_type'] ?? '' );
		if ( ! in_array( $type, self::TYPES, true ) ) {
			$errors[] = __( 'Choose a connection type.', 'bongo-world-ai-product-generator' );
		}
		$base_url = esc_url_raw( trim( (string) ( $in['base_url'] ?? '' ) ) );
		$endpoint = esc_url_raw( trim( (string) ( $in['endpoint'] ?? '' ) ) );
		if ( 'openai_compatible' === $type && ! self::https( $base_url ) ) {
			$errors[] = __( 'Base URL must be a valid https:// URL.', 'bongo-world-ai-product-generator' );
		}
		if ( 'custom_rest' === $type && ! self::https( $endpoint ) ) {
			$errors[] = __( 'Endpoint URL must be a valid https:// URL.', 'bongo-world-ai-product-generator' );
		}
		$model = trim( (string) ( $in['model'] ?? '' ) );
		if ( ! preg_match( '/^[A-Za-z0-9._:\/\-]{1,128}$/', $model ) ) {
			$errors[] = __( 'Model ID is required (letters, numbers, . _ : / -).', 'bongo-world-ai-product-generator' );
		}

		$auth = 'bearer';
		$hdr  = '';
		if ( 'custom_rest' === $type ) {
			$auth = (string) ( $in['auth_type'] ?? 'bearer' );
			if ( ! in_array( $auth, array( 'bearer', 'basic', 'header' ), true ) ) {
				$auth     = 'bearer';
				$errors[] = __( 'Unsupported authentication type.', 'bongo-world-ai-product-generator' );
			}
			if ( 'header' === $auth ) {
				$hdr = trim( (string) ( $in['api_key_header'] ?? '' ) );
				if ( ! preg_match( '/^[A-Za-z0-9\-]{1,64}$/', $hdr ) ) {
					$errors[] = __( 'API key header name is invalid.', 'bongo-world-ai-product-generator' );
				}
			}
		}

		$headers = array();
		$hraw    = trim( (string) ( $in['headers'] ?? '' ) );
		if ( '' !== $hraw ) {
			$dec = json_decode( $hraw, true );
			if ( ! is_array( $dec ) ) {
				$errors[] = __( 'Custom headers must be a JSON object.', 'bongo-world-ai-product-generator' );
			} else {
				foreach ( $dec as $k => $v ) {
					$ok = is_string( $k ) && preg_match( '/^[A-Za-z0-9\-]+$/', $k ) && is_scalar( $v ) && ! preg_match( '/[\r\n]/', (string) $v );
					if ( $ok && in_array( strtolower( $k ), array( 'authorization', 'proxy-authorization' ), true ) ) {
						$ok = false; // Secrets must not be stored in the database.
					}
					if ( $ok ) {
						$headers[ $k ] = (string) $v;
					} else {
						/* translators: %s header name */
						$errors[] = sprintf( __( 'Header not allowed: %s (never put secrets here).', 'bongo-world-ai-product-generator' ), (string) $k );
					}
				}
			}
		}

		$template  = '';
		$text_path = trim( (string) ( $in['response_text_path'] ?? '' ) );
		$err_path  = trim( (string) ( $in['error_path'] ?? '' ) );
		if ( 'custom_rest' === $type ) {
			$traw = trim( (string) ( $in['request_template'] ?? '' ) );
			$tdec = json_decode( $traw, true );
			if ( '' === $traw || ! is_array( $tdec ) ) {
				$errors[] = __( 'Request template must be valid JSON.', 'bongo-world-ai-product-generator' );
			} else {
				if ( preg_match_all( '/\{\{(\w+)\}\}/', $traw, $m ) ) {
					foreach ( array_unique( $m[1] ) as $ph ) {
						if ( ! in_array( $ph, TemplateRenderer::ALLOWED, true ) ) {
							/* translators: %s placeholder */
							$errors[] = sprintf( __( 'Unknown placeholder: {{%s}}', 'bongo-world-ai-product-generator' ), $ph );
						}
					}
				}
				$template = (string) wp_json_encode( $tdec, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
			}
			if ( ! JsonPath::is_valid( $text_path ) ) {
				$errors[] = __( 'Response text JSON path is required (example: choices.0.message.content).', 'bongo-world-ai-product-generator' );
			}
			if ( '' !== $err_path && ! JsonPath::is_valid( $err_path ) ) {
				$errors[] = __( 'Error JSON path is invalid.', 'bongo-world-ai-product-generator' );
			}
		}

		$so = (string) ( $in['structured_output'] ?? 'none' );
		$so = in_array( $so, array( 'none', 'json_schema', 'json_object' ), true ) ? $so : 'none';

		if ( $errors ) {
			return array( 'ok' => false, 'id' => $existing_id, 'errors' => $errors );
		}

		$id = $existing_id;
		if ( '' === $id ) {
			$id = $this->new_id( $name, $all );
		}
		$now = time();
		$all[ $id ] = array(
			'id'                 => $id,
			'display_name'       => $name,
			'connection_type'    => $type,
			'base_url'           => $base_url,
			'endpoint'           => $endpoint,
			'method'             => 'POST',
			'model'              => $model,
			'auth_type'          => $auth,
			'api_key_header'     => $hdr,
			'headers'            => $headers,
			'request_template'   => $template,
			'response_text_path' => $text_path,
			'error_path'         => $err_path,
			'capabilities'       => array(
				'text'              => true,
				'structured_output' => $so,
				'image_input'       => ! empty( $in['image_input'] ),
				'model_listing'     => false,
			),
			'timeout'            => max( 5, min( 120, absint( $in['timeout'] ?? 60 ) ) ),
			'retries'            => min( 2, absint( $in['retries'] ?? 2 ) ),
			'limits'             => array(
				'daily'           => absint( $in['limit_daily'] ?? 0 ),
				'monthly'         => absint( $in['limit_monthly'] ?? 0 ),
				'max_image_calls' => absint( $in['limit_images'] ?? 0 ),
			),
			'status'             => ( isset( $in['status'] ) && 'disabled' === $in['status'] ) ? 'disabled' : 'enabled',
			'last_test'          => $old['last_test'] ?? array(),
			'last_used'          => $old['last_used'] ?? 0,
			'created_at'         => $old['created_at'] ?? $now,
			'updated_at'         => $now,
		);
		update_option( self::OPTION, $all, false );
		return array( 'ok' => true, 'id' => $id, 'errors' => array() );
	}

	/** Deleting a profile never touches products, images, SEO data or history (spec §117). */
	public function delete( string $id ): bool {
		$all = $this->all();
		if ( ! isset( $all[ $id ] ) ) {
			return false;
		}
		unset( $all[ $id ] );
		update_option( self::OPTION, $all, false );
		return true;
	}

	public function record_test( string $id, string $status, string $message ): void {
		$all = $this->all();
		if ( isset( $all[ $id ] ) ) {
			$all[ $id ]['last_test'] = array( 'status' => $status, 'time' => time(), 'message' => substr( $message, 0, 200 ) );
			update_option( self::OPTION, $all, false );
		}
	}

	public function touch_used( string $id ): void {
		$all = $this->all();
		if ( isset( $all[ $id ] ) ) {
			$all[ $id ]['last_used'] = time();
			update_option( self::OPTION, $all, false );
		}
	}

	/** @return array{ok:bool,message:string} */
	public function usable( array $profile ): array {
		if ( 'enabled' !== ( $profile['status'] ?? '' ) ) {
			return array( 'ok' => false, 'message' => __( 'This provider is disabled.', 'bongo-world-ai-product-generator' ) );
		}
		if ( ! KeyProvider::is_configured( (string) ( $profile['id'] ?? '' ) ) ) {
			return array( 'ok' => false, 'message' => __( 'API key is not configured for this provider.', 'bongo-world-ai-product-generator' ) );
		}
		return array( 'ok' => true, 'message' => '' );
	}

	private function new_id( string $name, array $all ): string {
		$base = trim( str_replace( '-', '_', sanitize_title( $name ) ), '_' );
		$base = preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) $base ) );
		$base = substr( '' === $base ? 'profile' : $base, 0, 32 );
		if ( 'manual' === $base ) {
			$base = 'manual_profile';
		}
		$id = $base;
		$n  = 2;
		while ( isset( $all[ $id ] ) ) {
			$id = $base . '_' . $n++;
		}
		return $id;
	}

	private static function https( string $url ): bool {
		$parts = wp_parse_url( $url );
		return is_array( $parts ) && ! empty( $parts['host'] ) && isset( $parts['scheme'] ) && 'https' === strtolower( $parts['scheme'] );
	}
}
