<?php
namespace BongoWorld\AIProductGenerator\AI;

use BongoWorld\AIProductGenerator\Security\KeyProvider;

defined( 'ABSPATH' ) || exit;

/**
 * Mode A. Only this class (and CustomRestProvider) may know provider HTTP syntax.
 * Verify against the provider's CURRENT official docs before relying on a feature (spec §113).
 */
final class OpenAICompatibleProvider implements AIProviderInterface {
	private $p;

	public function __construct( array $profile ) {
		$this->p = $profile;
	}

	public function getCapabilities(): array {
		$c = isset( $this->p['capabilities'] ) && is_array( $this->p['capabilities'] ) ? $this->p['capabilities'] : array();
		return array_merge(
			array( 'text' => true, 'structured_output' => 'none', 'image_input' => false, 'model_listing' => false ),
			$c
		); // structured_output: json_schema | json_object | none. Defaults are pessimistic until tested.
	}

	public function generateProductContent( array $request ): array {
		$messages = array(
			array( 'role' => 'system', 'content' => (string) $request['system'] ),
			array( 'role' => 'user', 'content' => (string) $request['user'] ),
		);
		return $this->call( $messages, true );
	}

	public function generateImageMetadata( array $request ): array {
		if ( empty( $this->getCapabilities()['image_input'] ) ) {
			return array( 'ok' => false, 'text' => '', 'usage' => array(), 'error' => array( 'code' => 'unsupported_capability', 'message' => 'This provider does not support image analysis.', 'retryable' => false ) );
		}
		$parts = array( array( 'type' => 'text', 'text' => (string) $request['user'] ) );
		foreach ( (array) ( $request['images'] ?? array() ) as $img ) {
			if ( ! empty( $img['data_uri'] ) ) {
				$parts[] = array( 'type' => 'image_url', 'image_url' => array( 'url' => $img['data_uri'] ) );
			}
		}
		return $this->call(
			array(
				array( 'role' => 'system', 'content' => (string) $request['system'] ),
				array( 'role' => 'user', 'content' => $parts ),
			),
			true
		);
	}

	public function testConnection(): array {
		return $this->call(
			array( array( 'role' => 'user', 'content' => 'Reply with the single word: OK' ) ),
			false
		);
	}

	private function call( array $messages, bool $structured ): array {
		$id  = (string) ( $this->p['id'] ?? '' );
		$key = KeyProvider::get( $id );
		if ( null === $key ) {
			return array( 'ok' => false, 'text' => '', 'usage' => array(), 'error' => array( 'code' => 'key_missing', 'message' => 'API key is not configured for this profile.', 'retryable' => false ) );
		}
		$body = array( 'model' => (string) ( $this->p['model'] ?? '' ), 'messages' => $messages );
		if ( $structured ) {
			$so = $this->getCapabilities()['structured_output'];
			if ( 'json_schema' === $so ) {
				$body['response_format'] = array(
					'type'        => 'json_schema',
					'json_schema' => array( 'name' => 'bw_product', 'strict' => true, 'schema' => SchemaManager::json_schema() ),
				);
			} elseif ( 'json_object' === $so ) {
				$body['response_format'] = array( 'type' => 'json_object' );
			}
		}
		$res = HttpClient::request(
			'POST',
			rtrim( (string) ( $this->p['base_url'] ?? '' ), '/' ) . '/chat/completions',
			array( 'Authorization' => 'Bearer ' . $key, 'Content-Type' => 'application/json' ),
			wp_json_encode( $body ),
			(int) ( $this->p['timeout'] ?? 60 ),
			(int) ( $this->p['retries'] ?? 2 ),
			$key
		);
		if ( ! $res['ok'] ) {
			return array( 'ok' => false, 'text' => '', 'usage' => array(), 'error' => $this->normalizeError( $res['error'] ) );
		}
		$decoded = json_decode( $res['body'], true );
		if ( ! is_array( $decoded ) ) {
			return array( 'ok' => false, 'text' => '', 'usage' => array(), 'error' => array( 'code' => 'invalid_response', 'message' => 'Provider returned a non-JSON response.', 'retryable' => false ) );
		}
		return $this->normalizeResponse( $decoded );
	}

	public function normalizeResponse( array $raw ): array {
		$choice = $raw['choices'][0] ?? array();
		if ( ! empty( $choice['message']['refusal'] ) ) {
			return array( 'ok' => false, 'text' => '', 'usage' => (array) ( $raw['usage'] ?? array() ), 'error' => array( 'code' => 'refusal', 'message' => 'Provider refused the request.', 'retryable' => false ) );
		}
		if ( 'length' === ( $choice['finish_reason'] ?? '' ) ) {
			return array( 'ok' => false, 'text' => '', 'usage' => (array) ( $raw['usage'] ?? array() ), 'error' => array( 'code' => 'incomplete_output', 'message' => 'Output was cut off by the token limit.', 'retryable' => false ) );
		}
		$text = $choice['message']['content'] ?? '';
		if ( ! is_string( $text ) || '' === trim( $text ) ) {
			return array( 'ok' => false, 'text' => '', 'usage' => (array) ( $raw['usage'] ?? array() ), 'error' => array( 'code' => 'empty_output', 'message' => 'Provider returned no text.', 'retryable' => false ) );
		}
		return array( 'ok' => true, 'text' => $text, 'usage' => (array) ( $raw['usage'] ?? array() ), 'error' => null );
	}

	public function normalizeError( array $raw ): array {
		return array(
			'code'      => (string) ( $raw['code'] ?? 'unknown' ),
			'message'   => (string) ( $raw['message'] ?? 'Unknown error.' ),
			'retryable' => ! empty( $raw['retryable'] ),
		);
	}
}
