<?php
namespace BongoWorld\AIProductGenerator\AI;

defined( 'ABSPATH' ) || exit;

/** The ONLY place that maps a connection type to an adapter class. */
final class ProviderFactory {
	public static function make( array $profile ): ?AIProviderInterface {
		switch ( (string) ( $profile['connection_type'] ?? '' ) ) {
			case 'openai_compatible':
				return new OpenAICompatibleProvider( $profile );
			case 'custom_rest':
				return new CustomRestProvider( $profile );
		}
		return null;
	}
}
