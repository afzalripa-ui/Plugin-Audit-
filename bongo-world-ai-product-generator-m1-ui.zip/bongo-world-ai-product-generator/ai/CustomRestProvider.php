<?php
namespace BongoWorld\AIProductGenerator\AI;

use BongoWorld\AIProductGenerator\Security\KeyProvider;

defined( 'ABSPATH' ) || exit;

/** Mode B. Config-driven request template + response JSON path. No code execution. */
final class CustomRestProvider implements AIProviderInterface {
	private $p;

	public function __construct( array $profile ) {
		$this->p = $profile;
	}

	public function getCapabilities(): array {
		$c = isset( $this->p['capabilities'] ) && is_array( $this->p['capabilities'] ) ? $this->p['capabilities'] : array();
		return array_merge( array( 'text' => true, 'structured_output' => 'none', 'image_input' => false, 'model_listing' => false ), $c );
	}

	public function generateProductContent( array $request ): array {
		return $this->call(
			array(
				'system_prompt' => (string) $request['system'],
				'user_prompt'   => (string) $request['user'],
				'product_type'  => (string) ( $request['product_type'] ?? '' ),
				'product_data'  => $request['product_data'] ?? array(),
				'schema'        => SchemaManager::json_schema(),
				'images'        => array(),
			)
		);
	}

	public function generateImageMetadata( array $request ): array {
		if ( empty( $this->getCapabilities()['image_input'] ) ) {
			return array( 'ok' => false, 'text' => '', 'usage' => array(), 'error' => array( 'code' => 'unsupported_capability', 'message' => 'This provider does not support image analysis.', 'retryable' => false ) );
		}
		return $this->call(
			array(
				'system_prompt' => (string) $request['system'],
				'user_prompt'   => (string) $request['user'],
				'product_type'  => (string) ( $request['product_type'] ?? '' ),
				'product_data'  => $request['product_data'] ?? array(),
				'schema'        => SchemaManager::json_schema(),
				'images'        => $request['images'] ?? array(),
			)
		);
	}

	public function testConnection(): array {
		return $this->call( array( 'system_prompt' => '', 'user_prompt' => 'Reply with the single word: OK', 'product_type' => '', 'product_data' => array(), 'schema' => array(), 'images' => array() ) );
	}

	private function call( array $vars ): array {
		$fail = function ( string $code, string $msg ) {
			return array( 'ok' => false, 'text' => '', 'usage' => array(), 'error' => array( 'code' => $code, 'message' => $msg, 'retryable' => false ) );
		};
		$id  = (string) ( $this->p['id'] ?? '' );
		$key = KeyProvider::get( $id );
		if ( null === $key ) {
			return $fail( 'key_missing', 'API key is not configured for this profile.' );
		}
		$template = json_decode( (string) ( $this->p['request_template'] ?? '' ), true );
		if ( ! is_array( $template ) ) {
			return $fail( 'invalid_request', 'Request template is not valid JSON.' );
		}
		$text_path = (string) ( $this->p['response_text_path'] ?? '' );
		if ( ! JsonPath::is_valid( $text_path ) ) {
			return $fail( 'invalid_request', 'Response text path is invalid.' );
		}
		$vars['model'] = (string) ( $this->p['model'] ?? '' );
		$body          = TemplateRenderer::render( $template, $vars );

		$headers = array( 'Content-Type' => 'application/json' );
		foreach ( (array) ( $this->p['headers'] ?? array() ) as $hn => $hv ) {
			if ( preg_match( '/^[A-Za-z0-9\-]+$/', (string) $hn ) && is_string( $hv ) && ! preg_match( '/[\r\n]/', $hv ) ) {
				$headers[ $hn ] = $hv;
			}
		}
		switch ( (string) ( $this->p['auth_type'] ?? 'bearer' ) ) {
			case 'bearer':
				$headers['Authorization'] = 'Bearer ' . $key;
				break;
			case 'basic': // constant holds "user:pass".
				$headers['Authorization'] = 'Basic ' . base64_encode( $key ); // phpcs:ignore
				break;
			case 'header':
				$hn = (string) ( $this->p['api_key_header'] ?? '' );
				if ( ! preg_match( '/^[A-Za-z0-9\-]+$/', $hn ) ) {
					return $fail( 'invalid_request', 'API key header name is invalid.' );
				}
				$headers[ $hn ] = $key;
				break;
			default:
				return $fail( 'invalid_request', 'Unsupported auth type.' ); // Query-string keys disabled.
		}
		$method = 'GET' === strtoupper( (string) ( $this->p['method'] ?? 'POST' ) ) ? 'GET' : 'POST';
		$res    = HttpClient::request( $method, (string) ( $this->p['endpoint'] ?? '' ), $headers, 'POST' === $method ? wp_json_encode( $body ) : null, (int) ( $this->p['timeout'] ?? 60 ), (int) ( $this->p['retries'] ?? 2 ), $key );
		if ( ! $res['ok'] ) {
			return array( 'ok' => false, 'text' => '', 'usage' => array(), 'error' => $this->normalizeError( $res['error'] ) );
		}
		$decoded = json_decode( $res['body'], true );
		if ( ! is_array( $decoded ) ) {
			return $fail( 'invalid_response', 'Provider returned a non-JSON response.' );
		}
		return $this->normalizeResponse( $decoded );
	}

	public function normalizeResponse( array $raw ): array {
		$text = JsonPath::get( $raw, (string) ( $this->p['response_text_path'] ?? '' ) );
		if ( ! is_string( $text ) || '' === trim( $text ) ) {
			$err_path = (string) ( $this->p['error_path'] ?? '' );
			$msg      = $err_path ? JsonPath::get( $raw, $err_path ) : null;
			return array( 'ok' => false, 'text' => '', 'usage' => array(), 'error' => array( 'code' => 'empty_output', 'message' => is_string( $msg ) ? HttpClient::safe_excerpt( $msg ) : 'No text found at the configured response path.', 'retryable' => false ) );
		}
		return array( 'ok' => true, 'text' => $text, 'usage' => array(), 'error' => null );
	}

	public function normalizeError( array $raw ): array {
		return array( 'code' => (string) ( $raw['code'] ?? 'unknown' ), 'message' => (string) ( $raw['message'] ?? 'Unknown error.' ), 'retryable' => ! empty( $raw['retryable'] ) );
	}
}
