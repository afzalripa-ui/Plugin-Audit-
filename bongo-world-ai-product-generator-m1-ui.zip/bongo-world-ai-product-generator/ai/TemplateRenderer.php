<?php
namespace BongoWorld\AIProductGenerator\AI;

defined( 'ABSPATH' ) || exit;

/**
 * Data substitution ONLY. Operates on the decoded JSON structure, so values can never
 * break out of the JSON (no injection) and nothing is ever evaluated.
 */
final class TemplateRenderer {
	const ALLOWED = array( 'system_prompt', 'user_prompt', 'product_type', 'product_data', 'schema', 'model', 'images' );

	public static function render( $node, array $vars ) {
		if ( is_array( $node ) ) {
			$out = array();
			foreach ( $node as $k => $v ) {
				$out[ $k ] = self::render( $v, $vars );
			}
			return $out;
		}
		if ( ! is_string( $node ) ) {
			return $node;
		}
		if ( preg_match( '/^\{\{(\w+)\}\}$/', $node, $m ) && in_array( $m[1], self::ALLOWED, true ) ) {
			return $vars[ $m[1] ] ?? '';
		}
		return preg_replace_callback(
			'/\{\{(\w+)\}\}/',
			function ( $m ) use ( $vars ) {
				if ( ! in_array( $m[1], self::ALLOWED, true ) ) {
					return $m[0];
				}
				$v = $vars[ $m[1] ] ?? '';
				return is_scalar( $v ) ? (string) $v : wp_json_encode( $v, JSON_UNESCAPED_UNICODE );
			},
			$node
		);
	}
}
