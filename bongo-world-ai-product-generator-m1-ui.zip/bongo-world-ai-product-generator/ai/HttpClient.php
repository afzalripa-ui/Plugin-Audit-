<?php
namespace BongoWorld\AIProductGenerator\AI;

use BongoWorld\AIProductGenerator\Security\UrlGuard;

defined( 'ABSPATH' ) || exit;

/** Generic transport only (no provider syntax). Bounded retry, no redirects, secrets redacted. */
final class HttpClient {
	/** @return array{ok:bool,status?:int,body?:string,error?:array} */
	public static function request( string $method, string $url, array $headers, ?string $body, int $timeout, int $max_retries, string $secret = '' ): array {
		$guard = UrlGuard::validate( $url );
		if ( ! $guard['ok'] ) {
			return array( 'ok' => false, 'error' => self::err( 'invalid_endpoint', $guard['message'], false ) );
		}
		$max_retries = max( 0, min( 2, $max_retries ) );
		$attempt     = 0;
		while ( true ) {
			$resp = wp_safe_remote_request(
				$url,
				array(
					'method'      => $method,
					'timeout'     => max( 5, min( 120, $timeout ) ),
					'redirection' => 0,
					'headers'     => $headers,
					'body'        => $body,
				)
			);
			if ( is_wp_error( $resp ) ) {
				$error = self::err( 'timeout_or_network', 'Network error or timeout.', true );
			} else {
				$status = (int) wp_remote_retrieve_response_code( $resp );
				$raw    = (string) wp_remote_retrieve_body( $resp );
				if ( $status >= 200 && $status < 300 ) {
					return array( 'ok' => true, 'status' => $status, 'body' => $raw );
				}
				$error = self::map_status( $status, $raw, $secret );
			}
			if ( empty( $error['retryable'] ) || $attempt >= $max_retries ) {
				return array( 'ok' => false, 'error' => $error );
			}
			++$attempt;
			usleep( (int) ( min( 4.0, 0.5 * ( 2 ** $attempt ) ) * 1000000 ) );
		}
	}

	private static function map_status( int $status, string $raw, string $secret ): array {
		switch ( true ) {
			case 401 === $status || 403 === $status:
				return self::err( 'invalid_key', 'API key invalid, expired or not permitted.', false, $status );
			case 402 === $status:
				return self::err( 'billing', 'Billing or credit problem at the provider.', false, $status );
			case 404 === $status:
				return self::err( 'invalid_endpoint_or_model', 'Endpoint or model not found.', false, $status );
			case 408 === $status:
				return self::err( 'timeout_or_network', 'Provider timeout.', true, $status );
			case 429 === $status:
				return self::err( 'rate_limit', 'Rate limit reached.', true, $status );
			case $status >= 500:
				return self::err( 'server_error', 'Provider server error.', true, $status );
			default:
				return self::err( 'invalid_request', 'Provider rejected the request. ' . self::safe_excerpt( $raw, $secret ), false, $status );
		}
	}

	public static function safe_excerpt( string $text, string $secret = '' ): string {
		if ( '' !== $secret ) {
			$text = str_replace( $secret, '[redacted]', $text );
		}
		$text = preg_replace( '/(sk-|AIza|Bearer\s+)[A-Za-z0-9_\-\.]{6,}/', '[redacted]', $text );
		return function_exists( 'mb_substr' ) ? mb_substr( wp_strip_all_tags( $text ), 0, 200 ) : substr( wp_strip_all_tags( $text ), 0, 200 );
	}

	private static function err( string $code, string $message, bool $retryable, int $http = 0 ): array {
		return array( 'code' => $code, 'message' => $message, 'retryable' => $retryable, 'http_status' => $http );
	}
}
