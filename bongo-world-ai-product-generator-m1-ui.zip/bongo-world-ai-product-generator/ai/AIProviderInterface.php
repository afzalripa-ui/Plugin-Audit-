<?php
namespace BongoWorld\AIProductGenerator\AI;

defined( 'ABSPATH' ) || exit;

/**
 * Result shape for generate*(): ['ok'=>bool, 'text'=>string, 'usage'=>array, 'error'=>?array]
 * Error shape: ['code'=>string,'message'=>string,'retryable'=>bool]
 */
interface AIProviderInterface {
	public function generateProductContent( array $request ): array;
	/** $request['images'] = list of [slot=>..., data_uri=>...]; requires image_input capability. */
	public function generateImageMetadata( array $request ): array;
	public function testConnection(): array;
	/** @return array{text:bool,structured_output:string,image_input:bool,model_listing:bool} */
	public function getCapabilities(): array;
	public function normalizeResponse( array $raw ): array;
	public function normalizeError( array $raw ): array;
}
