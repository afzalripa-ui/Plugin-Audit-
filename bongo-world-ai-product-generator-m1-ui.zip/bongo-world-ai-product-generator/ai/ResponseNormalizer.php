<?php
namespace BongoWorld\AIProductGenerator\AI;

defined( 'ABSPATH' ) || exit;

/** Turns raw provider/pasted text into a PHP array. Output is still UNTRUSTED until validated. */
final class ResponseNormalizer {
	/** @return array{ok:bool,data:?array,error:?string} */
	public static function from_text( string $text ): array {
		$text = trim( $text );
		$text = preg_replace( '/^\xEF\xBB\xBF/', '', $text );
		if ( preg_match( '/^```(?:json)?\s*(.*?)\s*```$/s', $text, $m ) ) {
			$text = $m[1];
		}
		$data = json_decode( $text, true );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $data ) ) {
			return array( 'ok' => false, 'data' => null, 'error' => 'Malformed JSON: ' . json_last_error_msg() );
		}
		return array( 'ok' => true, 'data' => $data, 'error' => null );
	}
}
