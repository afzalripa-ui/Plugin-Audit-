<?php
namespace BongoWorld\AIProductGenerator\AI;

use BongoWorld\AIProductGenerator\History\GenerationRepository;
use BongoWorld\AIProductGenerator\Includes\Helpers;
use BongoWorld\AIProductGenerator\Includes\QualityGate;
use BongoWorld\AIProductGenerator\Includes\Rules;
use BongoWorld\AIProductGenerator\Includes\Settings;
use BongoWorld\AIProductGenerator\Logging\Logger;

defined( 'ABSPATH' ) || exit;

/** Orchestrates: prompt -> provider -> normalize -> quality gate, with history + cost limits. Provider-independent. */
final class GenerationService {
	/** @return array{ok:bool,data:?array,validation:?array,error:?array,generation_id:string,provider:string} */
	public function generate_product( array $profile, array $info, array $store, array $images, array $edited = array() ): array {
		$cost = ( new CostLimiter() )->check( $profile );
		if ( ! $cost['ok'] ) {
			return $this->fail( (string) $cost['code'], (string) $cost['message'] );
		}

		$neutral = PromptManager::neutral_request( $info );
		$request = array(
			'system'       => PromptManager::system_prompt(),
			'user'         => PromptManager::user_prompt( $neutral ),
			'product_type' => $neutral['product_type'],
			'product_data' => $neutral['product_data'],
		);

		$res = $this->attempt( $profile, 'generate_product', $request );
		if ( ! $res['ok'] ) {
			$fb = $this->fallback_profile( $profile, (array) $res['error'] );
			if ( $fb ) {
				$res = $this->attempt( $fb, 'generate_product_fallback', $request );
			}
		}
		if ( ! $res['ok'] ) {
			return $this->fail( (string) $res['error']['code'], (string) $res['error']['message'], (string) $res['generation_id'] );
		}

		$repo = new GenerationRepository();
		$norm = ResponseNormalizer::from_text( (string) $res['text'] );
		if ( ! $norm['ok'] ) {
			$repo->update( $res['generation_id'], array( 'status' => 'failed', 'error_type' => 'malformed_json' ) );
			Logger::event( 'validation_failed', array( 'profile' => $res['profile_id'], 'code' => 'malformed_json' ) );
			return $this->fail( 'malformed_json', (string) $norm['error'], (string) $res['generation_id'] );
		}

		$validation = QualityGate::run( $norm['data'], array( 'info' => $info, 'store' => $store, 'images' => $images, 'mode' => 'draft', 'edited' => $edited ) );
		$repo->update( $res['generation_id'], array( 'status' => $validation['ready'] ? 'success' : 'validation_failed' ) );
		if ( ! $validation['ready'] ) {
			Logger::event( 'validation_failed', array( 'profile' => $res['profile_id'], 'errors' => count( $validation['errors'] ) ) );
		}
		return array(
			'ok'            => true,
			'data'          => $norm['data'],
			'validation'    => $validation,
			'error'         => null,
			'generation_id' => (string) $res['generation_id'],
			'provider'      => (string) $res['provider_name'],
		);
	}

	private function attempt( array $profile, string $operation, array $request ): array {
		$repo = new GenerationRepository();
		$gid  = Helpers::uuid();
		$repo->create(
			array(
				'generation_id'   => $gid,
				'user_id'         => get_current_user_id(),
				'profile_id'      => (string) ( $profile['id'] ?? '' ),
				'provider_name'   => (string) ( $profile['display_name'] ?? '' ),
				'connection_type' => (string) ( $profile['connection_type'] ?? '' ),
				'model'           => (string) ( $profile['model'] ?? '' ),
				'prompt_version'  => Rules::PROMPT_VERSION,
				'operation'       => $operation,
				'status'          => 'started',
			)
		);
		Logger::event( 'generation_started', array( 'profile' => $profile['id'] ?? '', 'operation' => $operation ) );

		$provider = ProviderFactory::make( $profile );
		if ( ! $provider ) {
			$res = array( 'ok' => false, 'text' => '', 'usage' => array(), 'error' => array( 'code' => 'invalid_profile', 'message' => 'Unknown connection type.', 'retryable' => false ) );
		} else {
			$res = $provider->generateProductContent( $request );
		}
		$repo->update(
			$gid,
			array(
				'status'     => $res['ok'] ? 'success' : 'failed',
				'error_type' => $res['ok'] ? '' : (string) $res['error']['code'],
				'usage_json' => (array) ( $res['usage'] ?? array() ),
			)
		);
		( new ProviderRepository() )->touch_used( (string) ( $profile['id'] ?? '' ) );
		if ( ! $res['ok'] ) {
			Logger::event( 'api_error', array( 'profile' => $profile['id'] ?? '', 'code' => $res['error']['code'] ) );
		} else {
			Logger::event( 'generation_completed', array( 'profile' => $profile['id'] ?? '' ) );
		}
		$res['generation_id'] = $gid;
		$res['profile_id']    = (string) ( $profile['id'] ?? '' );
		$res['provider_name'] = (string) ( $profile['display_name'] ?? '' );
		return $res;
	}

	/** Fallback only when explicitly enabled, only for transient errors, only to a configured, usable profile. */
	private function fallback_profile( array $primary, array $error ): ?array {
		if ( ! Settings::get( 'fallback_enabled', false ) || empty( $error['retryable'] ) ) {
			return null;
		}
		$repo = new ProviderRepository();
		$fb   = $repo->get( (string) Settings::get( 'fallback_profile', '' ) );
		if ( ! $fb || ( $fb['id'] ?? '' ) === ( $primary['id'] ?? '' ) || ! $repo->usable( $fb )['ok'] ) {
			return null;
		}
		return ( new CostLimiter() )->check( $fb )['ok'] ? $fb : null;
	}

	private function fail( string $code, string $message, string $gid = '' ): array {
		return array( 'ok' => false, 'data' => null, 'validation' => null, 'error' => array( 'code' => $code, 'message' => $message ), 'generation_id' => $gid, 'provider' => '' );
	}
}
