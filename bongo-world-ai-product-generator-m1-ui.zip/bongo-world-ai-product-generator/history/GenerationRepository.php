<?php
namespace BongoWorld\AIProductGenerator\History;

defined( 'ABSPATH' ) || exit;

/** Audit trail (spec §75). Stores NO secrets, NO prompts, NO product notes. */
final class GenerationRepository {
	private const FIELDS = array(
		'generation_id' => '%s', 'user_id' => '%d', 'profile_id' => '%s', 'provider_name' => '%s',
		'connection_type' => '%s', 'model' => '%s', 'prompt_version' => '%s', 'operation' => '%s',
		'status' => '%s', 'product_id' => '%d', 'usage_json' => '%s', 'error_type' => '%s', 'created_at' => '%s',
	);

	private function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'bwaipg_generations';
	}

	public function create( array $row ): bool {
		global $wpdb;
		$data = array();
		$fmt  = array();
		foreach ( self::FIELDS as $f => $format ) {
			if ( array_key_exists( $f, $row ) ) {
				$data[ $f ] = is_array( $row[ $f ] ) ? wp_json_encode( $row[ $f ] ) : $row[ $f ];
				$fmt[]      = $format;
			}
		}
		if ( ! isset( $data['created_at'] ) ) {
			$data['created_at'] = gmdate( 'Y-m-d H:i:s' );
			$fmt[]              = '%s';
		}
		return false !== $wpdb->insert( $this->table(), $data, $fmt ); // phpcs:ignore
	}

	public function update( string $generation_id, array $changes ): void {
		global $wpdb;
		$data = array();
		$fmt  = array();
		foreach ( self::FIELDS as $f => $format ) {
			if ( 'generation_id' !== $f && array_key_exists( $f, $changes ) ) {
				$data[ $f ] = is_array( $changes[ $f ] ) ? wp_json_encode( $changes[ $f ] ) : $changes[ $f ];
				$fmt[]      = $format;
			}
		}
		if ( $data && '' !== $generation_id ) {
			$wpdb->update( $this->table(), $data, array( 'generation_id' => $generation_id ), $fmt, array( '%s' ) ); // phpcs:ignore
		}
	}

	public function list( int $page, int $per_page = 20 ): array {
		global $wpdb;
		$offset = max( 0, ( $page - 1 ) * $per_page );
		$table  = $this->table();
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset ), ARRAY_A ); // phpcs:ignore
	}

	public function count(): int {
		global $wpdb;
		$table = $this->table();
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore
	}

	/** Counts API attempts for a profile since a GMT datetime, for the given operations. */
	public function count_since( string $profile_id, string $since_gmt, array $operations ): int {
		global $wpdb;
		if ( ! $operations ) {
			return 0;
		}
		$table        = $this->table();
		$placeholders = implode( ',', array_fill( 0, count( $operations ), '%s' ) );
		$args         = array_merge( array( $profile_id, $since_gmt ), $operations );
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE profile_id = %s AND created_at >= %s AND operation IN ({$placeholders})", $args ) ); // phpcs:ignore
	}

	public function table_exists(): bool {
		global $wpdb;
		return $this->table() === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $this->table() ) ) ); // phpcs:ignore
	}
}
