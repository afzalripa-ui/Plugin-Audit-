<?php
namespace BongoWorld\AIProductGenerator\Includes;

use BongoWorld\AIProductGenerator\AI\ResponseValidator;
use BongoWorld\AIProductGenerator\WooCommerce\ProductService;
use BongoWorld\AIProductGenerator\WooCommerce\SKUService;
use BongoWorld\AIProductGenerator\WooCommerce\SlugService;

defined( 'ABSPATH' ) || exit;

/**
 * Quality gate: response validation + store data + SKU/slug/duplicate checks.
 * ctx: info, store, images, mode(draft|publish), product_id, edited[] (dotted paths the human edited).
 */
final class QualityGate {
	public static function run( array $data, array $ctx = array() ): array {
		$info       = ( isset( $ctx['info'] ) && is_array( $ctx['info'] ) ) ? $ctx['info'] : array();
		$store      = ( isset( $ctx['store'] ) && is_array( $ctx['store'] ) ) ? $ctx['store'] : array();
		$images     = ( isset( $ctx['images'] ) && is_array( $ctx['images'] ) ) ? $ctx['images'] : array();
		$edited     = ( isset( $ctx['edited'] ) && is_array( $ctx['edited'] ) ) ? $ctx['edited'] : array();
		$mode       = ( isset( $ctx['mode'] ) && 'publish' === $ctx['mode'] ) ? 'publish' : 'draft';
		$product_id = isset( $ctx['product_id'] ) ? (int) $ctx['product_id'] : 0;

		// User facts are protected from AI changes, but a human edit in the editor is allowed (human = final authority).
		$facts = array();
		foreach ( (array) ( $info['attributes'] ?? array() ) as $k => $v ) {
			if ( is_string( $v ) && '' !== trim( $v ) && ! in_array( 'attributes.' . $k . '.value', $edited, true ) ) {
				$facts[ $k ] = $v;
			}
		}
		$supplied = array();
		foreach ( array_keys( Rules::IMAGE_SLOTS ) as $slot ) {
			$supplied[ $slot ] = ! empty( $images[ $slot ] );
		}
		$v_ctx = array( 'user_facts' => $facts, 'images_supplied' => $supplied );

		$slug = ( isset( $data['product']['slug'] ) && is_string( $data['product']['slug'] ) ) ? $data['product']['slug'] : '';
		if ( '' !== $slug && preg_match( '/^[a-z0-9]+(-[a-z0-9]+)*$/', $slug ) ) {
			$v_ctx['slug_available'] = SlugService::is_available( $slug, $product_id );
		}
		$sku_preview = '';
		if ( 0 === $product_id ) {
			$sku_preview         = SKUService::preview( Settings::type_code( (string) ( $info['product_type'] ?? '' ) ) );
			$v_ctx['sku_unique'] = ! SKUService::exists( $sku_preview );
		}

		$r = ResponseValidator::validate( $data, $v_ctx );
		self::check_store( $store, $mode, $r );

		$dups = array();
		if ( isset( $data['product']['name'] ) && is_string( $data['product']['name'] ) ) {
			$dups = ( new ProductService() )->find_duplicates( $data['product']['name'], $slug, $product_id );
			if ( $dups ) {
				$r['warnings'][] = array( 'code' => 'possible_duplicate', 'message' => __( 'সম্ভাব্য একই product পাওয়া গেছে।', 'bongo-world-ai-product-generator' ) );
			}
		}
		$r['ready']       = empty( $r['errors'] );
		$r['sku_preview'] = $sku_preview;
		$r['duplicates']  = $dups;
		return $r;
	}

	private static function check_store( array $s, string $mode, array &$r ): void {
		$add = function ( $lvl, $code, $msg ) use ( &$r ) {
			$r[ $lvl ][] = array( 'code' => $code, 'message' => $msg );
		};
		$num = function ( $v ) {
			return '' === $v || ( is_numeric( $v ) && (float) $v >= 0 );
		};
		$reg = (string) ( $s['regular_price'] ?? '' );
		$sal = (string) ( $s['sale_price'] ?? '' );
		$bad = false;

		if ( ! $num( $reg ) ) {
			$add( 'errors', 'price_invalid', __( 'Regular price is not a valid number.', 'bongo-world-ai-product-generator' ) );
			$bad = true;
		} elseif ( '' === $reg ) {
			'publish' === $mode ? $add( 'errors', 'price_missing', __( 'Regular price is required to publish.', 'bongo-world-ai-product-generator' ) ) : $add( 'warnings', 'price_missing', __( 'Regular price is empty (set it before publishing).', 'bongo-world-ai-product-generator' ) );
			$bad = 'publish' === $mode;
		}
		if ( ! $num( $sal ) ) {
			$add( 'errors', 'sale_price_invalid', __( 'Sale price is not a valid number.', 'bongo-world-ai-product-generator' ) );
			$bad = true;
		} elseif ( '' !== $sal && ( '' === $reg || (float) $sal >= (float) $reg ) ) {
			$add( 'errors', 'sale_price_invalid', __( 'Sale price must be lower than the regular price.', 'bongo-world-ai-product-generator' ) );
			$bad = true;
		}
		if ( ! empty( $s['manage_stock'] ) ) {
			$q = (string) ( $s['stock_quantity'] ?? '' );
			if ( '' === $q || ! ctype_digit( $q ) ) {
				$add( 'errors', 'stock_quantity_missing', __( 'Stock is managed: enter a whole-number quantity (never invented by AI).', 'bongo-world-ai-product-generator' ) );
				$bad = true;
			}
		}
		foreach ( (array) ( $s['categories'] ?? array() ) as $cid ) {
			if ( ! term_exists( (int) $cid, 'product_cat' ) ) {
				$add( 'errors', 'category_invalid', __( 'A selected category no longer exists.', 'bongo-world-ai-product-generator' ) );
				$bad = true;
			}
		}
		if ( empty( $s['categories'] ) ) {
			$add( 'warnings', 'category_missing', __( 'No category selected (category is always chosen by you).', 'bongo-world-ai-product-generator' ) );
		}
		if ( ! empty( $s['shipping_class'] ) && ! term_exists( (int) $s['shipping_class'], 'product_shipping_class' ) ) {
			$add( 'errors', 'shipping_invalid', __( 'Selected shipping class does not exist.', 'bongo-world-ai-product-generator' ) );
			$bad = true;
		}
		foreach ( array( 'weight', 'length', 'width', 'height' ) as $f ) {
			if ( ! $num( (string) ( $s[ $f ] ?? '' ) ) ) {
				$add( 'errors', $f . '_invalid', sprintf( __( '%s is not a valid number.', 'bongo-world-ai-product-generator' ), ucfirst( $f ) ) );
				$bad = true;
			}
		}
		if ( ! $bad ) {
			$add( 'passes', 'store_data', __( 'Store data valid and kept separate from AI content.', 'bongo-world-ai-product-generator' ) );
		}
	}
}
