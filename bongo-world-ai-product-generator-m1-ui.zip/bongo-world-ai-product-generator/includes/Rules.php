<?php
namespace BongoWorld\AIProductGenerator\Includes;

defined( 'ABSPATH' ) || exit;

/** Locked Bongo World rules. Provider-independent. */
final class Rules {
	const PROMPT_VERSION = 'BW-AIPG-3.1.0';
	const SCHEMA_VERSION = '3.1';

	/** Exactly 7 default attributes (key => label). */
	const ATTRIBUTES = array(
		'color'     => 'Color',
		'size'      => 'Size',
		'fabric'    => 'Fabric / Material',
		'design'    => 'Design',
		'style'     => 'Style',
		'age_group' => 'Age Group',
		'occasion'  => 'Occasion',
	);

	/** Exactly 5 image slots, fixed order. */
	const IMAGE_SLOTS = array(
		'main'       => 'Main Product Image',
		'back'       => 'Gallery Back View',
		'side'       => 'Gallery Close Side View',
		'fabric'     => 'Gallery Fabric / Swatch',
		'front_zoom' => 'Gallery Front Zoom View',
	);

	const IMAGE_FIELDS   = array( 'alt', 'title', 'caption', 'description' );
	const IMAGE_BASIS    = array( 'TEMPLATE_BASED', 'IMAGE_OBSERVED' );
	const SOURCES        = array( 'USER_PROVIDED', 'IMAGE_OBSERVED', 'RULE_DERIVED', 'AI_WRITTEN', 'UNKNOWN' );
	const PRODUCT_FIELDS = array( 'name', 'seo_title', 'description_sections', 'short_description', 'focus_keyword', 'focus_keyword_slug_source', 'slug', 'meta_description', 'tags' );
	const TAGS_MIN       = 8;
	const TAGS_MAX       = 15;

	/** Keys AI must never return anywhere in its output (store-controlled). */
	const FORBIDDEN_KEYS = array(
		'price', 'regular_price', 'sale_price', 'cost_price', 'stock', 'stock_quantity', 'stock_status',
		'manage_stock', 'category', 'categories', 'shipping', 'shipping_class', 'weight', 'dimensions',
		'supplier_cost', 'sku',
	);
}
