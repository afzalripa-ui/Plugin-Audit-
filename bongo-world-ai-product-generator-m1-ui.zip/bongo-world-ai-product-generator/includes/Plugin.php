<?php
namespace BongoWorld\AIProductGenerator\Includes;

use BongoWorld\AIProductGenerator\Admin\Ajax;
use BongoWorld\AIProductGenerator\Admin\Assets;
use BongoWorld\AIProductGenerator\Admin\Menu;
use BongoWorld\AIProductGenerator\Admin\ProviderPage;
use BongoWorld\AIProductGenerator\Admin\SettingsPage;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	private static $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function boot(): void {
		load_plugin_textdomain( 'bongo-world-ai-product-generator', false, dirname( plugin_basename( BWAIPG_FILE ) ) . '/languages' );
		if ( ! is_admin() ) {
			return; // No public-facing code. No AI on public pages (spec §99).
		}
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p>' . esc_html__( 'Bongo World AI Product Generator requires WooCommerce.', 'bongo-world-ai-product-generator' ) . '</p></div>';
				}
			);
			return;
		}
		( new Menu() )->register();
		( new Assets() )->register();
		( new Ajax() )->register();
		( new ProviderPage() )->register_hooks();
		( new SettingsPage() )->register_hooks();
	}
}
