<?php
namespace BongoWorld\AIProductGenerator\Includes;

defined( 'ABSPATH' ) || exit;

final class Activator {
	public static function activate(): void {
		if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
			wp_die( esc_html__( 'PHP 7.4 or newer is required.', 'bongo-world-ai-product-generator' ) );
		}
		if ( ! class_exists( 'WooCommerce' ) ) {
			wp_die( esc_html__( 'WooCommerce must be active first.', 'bongo-world-ai-product-generator' ) );
		}
		if ( ! extension_loaded( 'mbstring' ) ) {
			wp_die( esc_html__( 'The PHP mbstring extension is required.', 'bongo-world-ai-product-generator' ) );
		}
		add_option( Settings::OPTION, Settings::defaults(), '', false );
		add_option( 'bwaipg_profiles', array(), '', false );
		self::create_tables();
		update_option( 'bwaipg_db_version', '1', false );
		// No products created, no API calls on activation.
	}

	private static function create_tables(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = $wpdb->prefix . 'bwaipg_generations';
		$charset = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				generation_id varchar(36) NOT NULL,
				user_id bigint(20) unsigned NOT NULL DEFAULT 0,
				profile_id varchar(64) NOT NULL DEFAULT '',
				provider_name varchar(128) NOT NULL DEFAULT '',
				connection_type varchar(32) NOT NULL DEFAULT '',
				model varchar(128) NOT NULL DEFAULT '',
				prompt_version varchar(32) NOT NULL DEFAULT '',
				operation varchar(48) NOT NULL DEFAULT '',
				status varchar(24) NOT NULL DEFAULT '',
				product_id bigint(20) unsigned NOT NULL DEFAULT 0,
				usage_json text NULL,
				error_type varchar(48) NOT NULL DEFAULT '',
				created_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY generation_id (generation_id),
				KEY created_at (created_at)
			) {$charset};"
		);
	}
}
