<?php
namespace BongoWorld\AIProductGenerator\Includes;

defined( 'ABSPATH' ) || exit;

final class Helpers {
	public static function uuid(): string {
		return wp_generate_uuid4();
	}

	public static function now_gmt(): string {
		return gmdate( 'Y-m-d H:i:s' );
	}

	/** Accepts Bangla digits, commas, spaces and the taka sign. Returns '' if empty. */
	public static function normalize_number( $v ): string {
		$v = is_scalar( $v ) ? (string) $v : '';
		$v = strtr(
			$v,
			array(
				'০' => '0', '১' => '1', '২' => '2', '৩' => '3', '৪' => '4',
				'৫' => '5', '৬' => '6', '৭' => '7', '৮' => '8', '৯' => '9',
				'৳' => '', ',' => '', ' ' => '',
			)
		);
		return trim( $v );
	}

	public static function clean_info( $raw ): array {
		$raw   = is_array( $raw ) ? $raw : array();
		$attrs = array();
		foreach ( array_keys( Rules::ATTRIBUTES ) as $k ) {
			$attrs[ $k ] = ( isset( $raw['attributes'][ $k ] ) && is_string( $raw['attributes'][ $k ] ) ) ? sanitize_text_field( $raw['attributes'][ $k ] ) : '';
		}
		return array(
			'product_type' => ( isset( $raw['product_type'] ) && is_string( $raw['product_type'] ) ) ? sanitize_text_field( $raw['product_type'] ) : '',
			'attributes'   => $attrs,
			'notes'        => ( isset( $raw['notes'] ) && is_string( $raw['notes'] ) ) ? sanitize_textarea_field( $raw['notes'] ) : '',
		);
	}

	/** Store-controlled data. Never sent to AI. */
	public static function clean_store( $raw ): array {
		$raw    = is_array( $raw ) ? $raw : array();
		$status = ( isset( $raw['stock_status'] ) && is_string( $raw['stock_status'] ) ) ? $raw['stock_status'] : '';
		$cats   = isset( $raw['categories'] ) ? (array) $raw['categories'] : array();
		return array(
			'regular_price'  => self::normalize_number( $raw['regular_price'] ?? '' ),
			'sale_price'     => self::normalize_number( $raw['sale_price'] ?? '' ),
			'manage_stock'   => ! empty( $raw['manage_stock'] ),
			'stock_quantity' => self::normalize_number( $raw['stock_quantity'] ?? '' ),
			'stock_status'   => in_array( $status, array( 'instock', 'outofstock', 'onbackorder' ), true ) ? $status : '',
			'categories'     => array_values( array_unique( array_filter( array_map( 'absint', $cats ) ) ) ),
			'shipping_class' => absint( $raw['shipping_class'] ?? 0 ),
			'weight'         => self::normalize_number( $raw['weight'] ?? '' ),
			'length'         => self::normalize_number( $raw['length'] ?? '' ),
			'width'          => self::normalize_number( $raw['width'] ?? '' ),
			'height'         => self::normalize_number( $raw['height'] ?? '' ),
		);
	}

	public static function clean_images( $raw ): array {
		$raw = is_array( $raw ) ? $raw : array();
		$out = array();
		foreach ( array_keys( Rules::IMAGE_SLOTS ) as $slot ) {
			$out[ $slot ] = absint( $raw[ $slot ] ?? 0 );
		}
		return $out;
	}

	/** List of dotted paths the human edited in the result editor. */
	public static function clean_paths( $raw ): array {
		$out = array();
		foreach ( (array) $raw as $p ) {
			if ( is_string( $p ) && preg_match( '/^[A-Za-z0-9_.]{1,80}$/', $p ) ) {
				$out[] = $p;
			}
			if ( count( $out ) >= 200 ) {
				break;
			}
		}
		return $out;
	}

	public static function redact( string $text ): string {
		return (string) preg_replace( '/(sk-|AIza|Bearer\s+)[A-Za-z0-9_\-\.]{6,}/', '[redacted]', $text );
	}

	public static function trunc( string $text, int $len ): string {
		return function_exists( 'mb_substr' ) ? mb_substr( $text, 0, $len, 'UTF-8' ) : substr( $text, 0, $len );
	}
}
