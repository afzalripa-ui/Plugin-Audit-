<?php
namespace BongoWorld\AIProductGenerator\Includes;

defined( 'ABSPATH' ) || exit;

final class Settings {
	const OPTION = 'bwaipg_settings';

	public static function defaults(): array {
		return array(
			'active_profile'       => 'manual', // 'manual' = Free / Manual JSON mode.
			'sku_pattern'          => 'BW-{TYPE}-{YYMM}-{SEQUENCE}',
			'type_codes'           => array(
				'Buk Kuci Hijab' => 'HIJ',
				'Hijab'          => 'HIJ',
				'Khimar'         => 'KHM',
				'Abaya'          => 'ABY',
				'Niqab'          => 'NQB',
				'Other'          => 'GEN',
			),
			'attribute_map'        => array_fill_keys( array_keys( Rules::ATTRIBUTES ), 'auto' ),
			'create_missing_terms' => true,
			'fallback_enabled'     => false, // Spec §72: default OFF.
			'fallback_profile'     => '',
			'debug_logging'        => false, // Spec §76: default OFF.
		);
	}

	public static function all(): array {
		$saved = get_option( self::OPTION, array() );
		$saved = is_array( $saved ) ? $saved : array();
		$all   = array_merge( self::defaults(), $saved );
		$defmap = self::defaults()['attribute_map'];
		$all['attribute_map'] = array_merge( $defmap, is_array( $all['attribute_map'] ) ? $all['attribute_map'] : array() );
		if ( ! is_array( $all['type_codes'] ) || ! $all['type_codes'] ) {
			$all['type_codes'] = self::defaults()['type_codes'];
		}
		return $all;
	}

	/** @return mixed */
	public static function get( string $key, $default = null ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	public static function update( array $changes ): void {
		$all = self::all();
		foreach ( $changes as $k => $v ) {
			if ( array_key_exists( $k, self::defaults() ) ) {
				$all[ $k ] = $v;
			}
		}
		update_option( self::OPTION, $all, false );
	}

	public static function type_codes(): array {
		return (array) self::get( 'type_codes', array() );
	}

	public static function type_code( string $label ): string {
		foreach ( self::type_codes() as $l => $c ) {
			if ( 0 === strcasecmp( (string) $l, trim( $label ) ) ) {
				return (string) $c;
			}
		}
		return 'GEN';
	}

	public static function pattern_is_valid( string $p ): bool {
		if ( false === strpos( $p, '{SEQUENCE}' ) ) {
			return false;
		}
		if ( ! preg_match( '/^[A-Za-z0-9_\-{}]+$/', $p ) ) {
			return false;
		}
		$rest = str_replace( array( '{TYPE}', '{YYMM}', '{SEQUENCE}' ), '', $p );
		return ! preg_match( '/[{}]/', $rest );
	}
}
