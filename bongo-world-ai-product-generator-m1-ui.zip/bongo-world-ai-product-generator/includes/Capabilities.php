<?php
namespace BongoWorld\AIProductGenerator\Includes;

defined( 'ABSPATH' ) || exit;

/** Capability map (spec §81). Always check capabilities, never rely on roles alone. */
final class Capabilities {
	const GENERATE = 'edit_products';
	const SAVE     = 'edit_products';
	const PUBLISH  = 'publish_products';
	const MANAGE   = 'manage_options';
}
